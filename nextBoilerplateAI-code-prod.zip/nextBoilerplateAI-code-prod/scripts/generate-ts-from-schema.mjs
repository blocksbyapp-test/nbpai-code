import { generate } from '@graphql-codegen/cli';
import path from 'path';
import fs from 'fs';
import { UrlLoader } from '@graphql-tools/url-loader';
import { loadSchema } from '@graphql-tools/load';
import { generateOperationsForFeature, tryLoadSchema } from './generate-all-operations.mjs';

const featuresFilePath = path.join(process.cwd(), 'src/features/index.ts');
const fileContent = fs.readFileSync(featuresFilePath, 'utf-8');

const match = fileContent.match(/export\s+const\s+SUPPORTED_FEATURES\s*=\s*\[([^\]]+)\]/);
if (!match) {
    throw new Error('Could not extract SUPPORTED_FEATURES from the file.');
}
const featuresArrayString = match[1];
const SUPPORTED_FEATURES = featuresArrayString
    .split(',')
    .map((item) => item.trim().replace(/['"`]/g, ''))
    .filter(Boolean);

// tiny helper: does dir contain at least one .graphql doc?
function hasGraphqlDocs(dir) {
    try {
        const files = fs.readdirSync(dir);
        return files.some((f) => f.endsWith('.graphql'));
    } catch {
        return false;
    }
}

async function isSchemaReachable(url, headers) {
    // Prefer the shared helper; fall back to a direct attempt if needed.
    const schema = await tryLoadSchema(url, headers);
    if (schema) return true;

    try {
        await loadSchema(url, { loaders: [new UrlLoader()], headers: headers ?? undefined });
        return true;
    } catch {
        return false;
    }
}

for (const feature of SUPPORTED_FEATURES) {
    await generateOperationsForFeature(feature);

    const base = `http://127.0.0.1:${process.env.PORT}/${feature}`;
    const privUrl = `${base}/api`;
    const pubUrl = `${base}/public/api`;

    // PRIVATE (requires auth). Documents: src/features/<feature>/generated/operations/*.graphql
    const privateDocsDir = path.join(process.cwd(), `src/features/${feature}/generated/operations`);
    const privateTypesOut = path.join(process.cwd(), `src/features/${feature}/generated/types.ts`);

    if (hasGraphqlDocs(privateDocsDir)) {
        const reachable = await isSchemaReachable(privUrl, {
            Authorization: `Bearer ${process.env.API_KEY_LOCAL_GENERATION}`,
        });
        if (!reachable) {
            console.log(
                `  • Skipping codegen (private) for '${feature}' — endpoint not available: ${privUrl}`
            );
        } else {
            try {
                await generate(
                    {
                        schema: {
                            [privUrl]: {
                                headers: { Authorization: `Bearer ${process.env.API_KEY_LOCAL_GENERATION}` },
                            },
                        },
                        documents: [path.join(privateDocsDir, '*.graphql')],
                        generates: {
                            [privateTypesOut]: {
                                plugins: ['typescript', 'typescript-operations', 'typescript-react-apollo'],
                                config: {
                                    skipTypename: true,
                                    withHooks: true,
                                    withHOC: false,
                                    disableDescriptions: true,
                                    addDocBlocks: false,
                                },
                            },
                        },
                    },
                    true
                );
            } catch (err) {
                console.log(
                    `  • Skipping codegen (private) for '${feature}' — codegen failed: ${String(err)}`
                );
            }
        }
    } else {
        console.log(`  • Skipping codegen (private) for '${feature}' — no operations found.`);
    }

    // PUBLIC (no auth). Documents: src/features/<feature>/generated/public/operations/*.graphql
    const publicDocsDir = path.join(
        process.cwd(),
        `src/features/${feature}/generated/public/operations`
    );
    const publicTypesOut = path.join(
        process.cwd(),
        `src/features/${feature}/generated/public/types.ts`
    );

    if (hasGraphqlDocs(publicDocsDir)) {
        const reachable = await isSchemaReachable(pubUrl, null);
        if (!reachable) {
            console.log(`  • Skipping codegen (public) for '${feature}' — endpoint not available: ${pubUrl}`);
        } else {
            try {
                await generate(
                    {
                        schema: {
                            [pubUrl]: {}, // no headers/auth
                        },
                        documents: [path.join(publicDocsDir, '*.graphql')],
                        generates: {
                            [publicTypesOut]: {
                                plugins: ['typescript', 'typescript-operations', 'typescript-react-apollo'],
                                config: {
                                    skipTypename: true,
                                    withHooks: true,
                                    withHOC: false,
                                    disableDescriptions: true,
                                    addDocBlocks: false,
                                },
                            },
                        },
                    },
                    true
                );
            } catch (err) {
                console.log(
                    `  • Skipping codegen (public) for '${feature}' — codegen failed: ${String(err)}`
                );
            }
        }
    } else {
        console.log(`  • Skipping codegen (public) for '${feature}' — no operations found.`);
    }
}
