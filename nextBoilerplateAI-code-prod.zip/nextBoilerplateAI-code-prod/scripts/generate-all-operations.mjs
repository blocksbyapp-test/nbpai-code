import fs from 'fs';
import path from 'path';
import {
    isObjectType,
    isScalarType,
    isEnumType,
    isInterfaceType,
    isUnionType,
    getNamedType,
} from 'graphql';
import { loadSchema } from '@graphql-tools/load';
import { UrlLoader } from '@graphql-tools/url-loader';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MAX_DEPTH = Number(process.env.GQL_MAX_DEPTH ?? 5);
const INCLUDE_TYPENAME = (process.env.GQL_INCLUDE_TYPENAME ?? 'false') === 'true';

function findImplementations(schema, iface) {
    return Object.values(schema.getTypeMap()).filter(
        (t) => isObjectType(t) && t.getInterfaces().some((i) => i.name === iface.name)
    );
}

function isLeafNamedType(namedType) {
    return isScalarType(namedType) || isEnumType(namedType);
}

function isErrorInterfaceType(t) {
    const nt = getNamedType(t)
    return isInterfaceType(nt) && nt.name === 'ErrorInterface'
}

function shouldSkipField(f) {
    if (f.name === 'error') return true
    if (isErrorInterfaceType(f.type)) return true
    return false
}

function buildSelectionSet(type, schema, depth = 0, visited = new Set()) {
    if (depth > MAX_DEPTH) {
        return '__typename';
    }

    const namedType = getNamedType(type);

    if (isLeafNamedType(namedType)) {
        return '';
    }

    if (isObjectType(namedType)) {
        const typeName = namedType.name;
        if (visited.has(typeName)) {
            return '__typename';
        }

        const nextVisited = new Set(visited);
        nextVisited.add(typeName);

        const fieldStrings = [];

        if (INCLUDE_TYPENAME) fieldStrings.push('__typename');

        // ⬇️ filter out the error field / ErrorInterface-typed fields
        // const fields = Object.values(namedType.getFields()).filter((f) => !shouldSkipField(f))

        const fields = Object.values(namedType.getFields()).filter((f) => !shouldSkipField(f))
        for (const field of fields) {
            const sub = buildSelectionSet(field.type, schema, depth + 1, nextVisited);

            if (sub) {
                fieldStrings.push(`${field.name} { ${sub} }`);
            } else {
                fieldStrings.push(field.name);
            }
        }

        return fieldStrings.length ? fieldStrings.join('\n') : '__typename';
    }

    if (isInterfaceType(namedType)) {
        // ⬇️ don't generate selections for ErrorInterface at all
        if (namedType.name === 'ErrorInterface') {
            return '' // returning empty prevents parent from adding a selection set for it
        }
        // ...rest of your interface handling...
    }

    if (isInterfaceType(namedType)) {
        const impls = findImplementations(schema, namedType);

        if (impls.length > 0) {
            const parts = impls.map((objType) => {
                const sub = buildSelectionSet(objType, schema, depth + 1, new Set(visited));
                const safeSub = sub && sub.trim().length ? sub : '__typename';
                return `... on ${objType.name} { ${safeSub} }`;
            });
            return INCLUDE_TYPENAME ? ['__typename', ...parts].join('\n') : parts.join('\n');
        } else {
            // No known impls — directly select interface's own fields
            const typeName = namedType.name;
            if (visited.has(typeName)) {
                return '__typename';
            }
            const nextVisited = new Set(visited);
            nextVisited.add(typeName);

            const fieldStrings = [];
            if (INCLUDE_TYPENAME) fieldStrings.push('__typename');

            const fields = Object.values(namedType.getFields());
            for (const field of fields) {
                const sub = buildSelectionSet(field.type, schema, depth + 1, nextVisited);
                if (sub) {
                    fieldStrings.push(`${field.name} { ${sub} }`);
                } else {
                    fieldStrings.push(field.name);
                }
            }
            return fieldStrings.length ? fieldStrings.join('\n') : '__typename';
        }
    }

    if (isUnionType(namedType)) {
        const types = namedType.getTypes();
        if (!types.length) {
            return '__typename';
        }

        const parts = types.map((objType) => {
            const sub = buildSelectionSet(objType, schema, depth + 1, new Set(visited));
            const safeSub = sub && sub.trim().length ? sub : '__typename';
            return `... on ${objType.name} { ${safeSub} }`;
        });

        return INCLUDE_TYPENAME ? ['__typename', ...parts].join('\n') : parts.join('\n');
    }

    return '__typename';
}

function renderVarDefs(args) {
    if (!args?.length) return '';
    const defs = args.map((a) => `$${a.name}: ${String(a.type)}`).join(', ');
    return `(${defs})`;
}

function renderVarPass(args) {
    if (!args?.length) return '';
    const defs = args.map((a) => `${a.name}: $${a.name}`).join(', ');
    return `(${defs})`;
}

function writeOperationFile(dir, opName, opKind, field) {
    const selectionSet = buildSelectionSet(field.type, field.schema, 0, new Set());
    const hasSelection = selectionSet && selectionSet.trim().length > 0;
    const body = hasSelection ? `{\n    ${selectionSet}\n  }` : '';

    const varDefs = renderVarDefs(field.args);
    const varPass = renderVarPass(field.args);

    const sdl =
        `${opKind} ${opName} ${varDefs ? varDefs + ' ' : ''}{\n` +
        `  ${opName}${varPass ? ' ' + varPass : ''} ${body}\n` +
        `}`;

    fs.writeFileSync(path.join(dir, `${opName}.graphql`), sdl);
}

// ⬇️ Exported so other scripts can check reachability without throwing.
export async function tryLoadSchema(url, headers) {
    try {
        const schema = await loadSchema(url, {
            loaders: [new UrlLoader()],
            headers: headers ?? undefined,
        });
        return schema;
    } catch {
        return null;
    }
}

async function generateForEndpoint(feature, endpointLabel, url, headers) {
    const outRoot = path
        .join(
            process.cwd(),
            'src',
            'features',
            feature,
            'generated',
            endpointLabel === 'public' ? 'public' : ''
        )
        .replace(/[\\\/]+$/, ''); // trim trailing slash if any

    const GENERATED_DIR = path.join(outRoot, 'operations');

    // Always clear stale operations first to avoid stale docs triggering codegen later.
    fs.rmSync(GENERATED_DIR, { recursive: true, force: true });

    const schema = await tryLoadSchema(url, headers);
    if (!schema) {
        console.log(`  • Skipping ${endpointLabel} for '${feature}' — endpoint not available: ${url}`);
        return false;
    }

    console.log(`  • Generating operations for '${feature}' (${endpointLabel}) from ${url} ...`);

    fs.mkdirSync(GENERATED_DIR, { recursive: true });

    const withSchema = (f) => Object.assign(f, { schema });

    const queryType = schema.getQueryType();
    if (queryType) {
        const fields = Object.entries(queryType.getFields());
        for (const [name, field] of fields) {
            writeOperationFile(GENERATED_DIR, name, 'query', withSchema(field));
        }
    }

    const mutationType = schema.getMutationType();
    if (mutationType) {
        const fields = Object.entries(mutationType.getFields());
        for (const [name, field] of fields) {
            writeOperationFile(GENERATED_DIR, name, 'mutation', withSchema(field));
        }
    }

    console.log(`  ✓ Wrote operations to ${GENERATED_DIR}`);
    return true;
}

// NOTE: same exported name; now generates for BOTH private and public (when available)
export async function generateOperationsForFeature(feature) {
    console.log(`- Generating GraphQL operations for feature: '${feature}'...`);

    const base = `http://127.0.0.1:${process.env.PORT}/${feature}`;
    const privUrl = `${base}/api`;
    const pubUrl = `${base}/public/api`;

    // Try public first (no auth), then private (with auth header)
    const anyPublic = await generateForEndpoint(feature, 'public', pubUrl, null);
    const anyPrivate = await generateForEndpoint(feature, 'private', privUrl, {
        Authorization: `Bearer ${process.env.API_KEY_LOCAL_GENERATION}`,
    });

    if (!anyPublic && !anyPrivate) {
        console.log(`  ⚠ No API available for '${feature}'. Skipped both public and private.`);
    }
}

async function runIfInvokedDirectly() {
    const invoked = process.argv[1] && path.resolve(process.argv[1]) === __filename;
    if (!invoked) return;

    const feature = process.argv[2] || process.env.FEATURE;
    if (!feature) {
        console.error('Usage: node scripts/generate-all-operations.mjs <feature>');
        process.exit(1);
    }
    await generateOperationsForFeature(feature);
}

await runIfInvokedDirectly();
