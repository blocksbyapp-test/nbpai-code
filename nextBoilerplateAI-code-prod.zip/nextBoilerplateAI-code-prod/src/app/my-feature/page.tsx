import { TodoPage } from '@/features/my-feature/client/pages/TodoPage'

export default () => <TodoPage />
