export { GET, POST, dynamic } from '@/features/my-feature/server/private'
