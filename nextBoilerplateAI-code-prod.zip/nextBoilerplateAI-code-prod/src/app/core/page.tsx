'use client'

import {
  AvatarIcon,
  Cross1Icon,
  DotsHorizontalIcon,
  EyeClosedIcon,
  EyeOpenIcon,
  InfoCircledIcon,
  MagnifyingGlassIcon,
  PlusIcon,
} from '@radix-ui/react-icons'
import {
  AccessibleIcon,
  Accordion,
  AspectRatio,
  Collapsible,
  Form,
  Label,
  Menubar,
  NavigationMenu,
  unstable_OneTimePasswordField as OneTimePasswordField,
  unstable_PasswordToggleField as PasswordToggleField,
  Portal,
  Separator,
  Slot as SlotPrimitive,
  Toast,
  Toggle,
  ToggleGroup,
  Toolbar,
  VisuallyHidden,
} from 'radix-ui'
import * as React from 'react'

import { DismissableLayer as DismissableLayerPrimitive } from '@radix-ui/react-dismissable-layer'
import { FocusScope as FocusScopePrimitive } from '@radix-ui/react-focus-scope'
import {
  Menu,
  MenuAnchor,
  MenuContent,
  MenuItem,
  MenuPortal,
  MenuSeparator,
} from '@radix-ui/react-menu'
import { Presence } from '@radix-ui/react-presence'
import {
  RovingFocusGroup,
  RovingFocusGroupItem,
} from '@radix-ui/react-roving-focus'

import { composeEventHandlers } from '@radix-ui/primitive'
import { createCollection } from '@radix-ui/react-collection'
import {
  Popper,
  PopperAnchor,
  PopperArrow,
  PopperContent,
} from '@radix-ui/react-popper'
import {
  AlertDialog,
  Avatar,
  Box,
  Button,
  Callout,
  Card,
  Checkbox,
  ContextMenu,
  Dialog,
  DropdownMenu,
  Flex,
  Grid,
  Heading,
  HoverCard,
  IconButton,
  Popover,
  Progress,
  RadioGroup,
  ScrollArea,
  SegmentedControl,
  Select,
  Skeleton,
  Slider,
  Spinner,
  Switch,
  Table,
  TabNav,
  Tabs,
  Text,
  TextArea,
  TextField,
  ThemePanel,
  Tooltip,
} from '@radix-ui/themes'

const foodGroups: Array<{
  label?: string
  foods: Array<{ value: string; label: string; disabled?: boolean }>
}> = [
  {
    label: 'Fruits',
    foods: [
      { value: 'apple', label: 'Apple' },
      { value: 'banana', label: 'Banana' },
      { value: 'blueberry', label: 'Blueberry' },
      { value: 'grapes', label: 'Grapes' },
      { value: 'pineapple', label: 'Pineapple' },
    ],
  },
  {
    label: 'Vegetables',
    foods: [
      { value: 'aubergine', label: 'Aubergine' },
      { value: 'broccoli', label: 'Broccoli' },
      { value: 'carrot', label: 'Carrot', disabled: true },
      { value: 'courgette', label: 'Courgette' },
      { value: 'leek', label: 'Leek' },
    ],
  },
  {
    label: 'Meat',
    foods: [
      { value: 'beef', label: 'Beef' },
      { value: 'beef-with-sauce', label: 'Beef with sauce' },
      { value: 'chicken', label: 'Chicken' },
      { value: 'lamb', label: 'Lamb' },
      { value: 'pork', label: 'Pork' },
    ],
  },
  {
    foods: [
      { value: 'candies', label: 'Candies' },
      { value: 'chocolates', label: 'Chocolates' },
    ],
  },
]

type ItemData = { disabled: boolean }

const [Collection, useCollection] = createCollection<
  React.ComponentRef<typeof Item>,
  ItemData
>('List')

const List: React.FC<{ children: React.ReactNode }> = (props) => {
  return (
    <Collection.Provider scope={undefined}>
      <Collection.Slot scope={undefined}>
        <ul {...props} style={{ width: 200 }} />
      </Collection.Slot>
    </Collection.Provider>
  )
}

type ItemProps = React.ComponentPropsWithRef<'li'> & {
  children: React.ReactNode
  disabled?: boolean
  value?: string // Added value prop for basic example
}

function Item({ disabled = false, ...props }: ItemProps) {
  return (
    <Collection.ItemSlot scope={undefined} disabled={disabled}>
      <li
        {...props}
        style={{ ...props.style, opacity: disabled ? 0.3 : undefined }}
      />
    </Collection.ItemSlot>
  )
}

function LogItems({ name = 'items' }: { name?: string }) {
  const getItems = useCollection(undefined)
  React.useEffect(() => console.log(name, getItems()))
  return null
}

const DismissableLayer = DismissableLayerPrimitive
const FocusScope = FocusScopePrimitive

function DismissableLayerBasic() {
  const [open, setOpen] = React.useState(false)
  const openButtonRef = React.useRef<HTMLButtonElement>(null)

  const [dismissOnEscape, setDismissOnEscape] = React.useState(false)
  const [dismissOnPointerDownOutside, setDismissOnPointerDownOutside] =
    React.useState(false)
  const [dismissOnFocusOutside, setDismissOnFocusOutside] =
    React.useState(false)
  const [disabledOutsidePointerEvents, setDisableOutsidePointerEvents] =
    React.useState(false)

  return (
    <div className="text-center font-sans">
      <h1>DismissableLayer</h1>

      <div className="mb-5 inline-block text-left">
        <label className="block">
          <input
            type="checkbox"
            checked={dismissOnEscape}
            onChange={(event) => setDismissOnEscape(event.target.checked)}
          />{' '}
          Dismiss on escape?
        </label>

        <label className="block">
          <input
            type="checkbox"
            checked={dismissOnPointerDownOutside}
            onChange={(event) =>
              setDismissOnPointerDownOutside(event.target.checked)
            }
          />{' '}
          Dismiss on pointer down outside?
        </label>

        <label className="block">
          <input
            type="checkbox"
            checked={dismissOnFocusOutside}
            onChange={(event) => setDismissOnFocusOutside(event.target.checked)}
          />{' '}
          Dismiss on focus outside?
        </label>

        <hr />

        <label className="block">
          <input
            type="checkbox"
            checked={disabledOutsidePointerEvents}
            onChange={(event) =>
              setDisableOutsidePointerEvents(event.target.checked)
            }
          />{' '}
          Disable outside pointer events?
        </label>
      </div>

      <div className="mb-5">
        <button
          ref={openButtonRef}
          type="button"
          onClick={() => setOpen((open) => !open)}
        >
          {open ? 'Close' : 'Open'} layer
        </button>
      </div>

      {open ? (
        <DismissableLayer
          onEscapeKeyDown={(event) => {
            if (dismissOnEscape === false) {
              event.preventDefault()
            }
          }}
          onPointerDownOutside={(event) => {
            if (
              dismissOnPointerDownOutside === false ||
              event.target === openButtonRef.current
            ) {
              event.preventDefault()
            }
          }}
          onFocusOutside={(event) => {
            if (dismissOnFocusOutside === false) {
              event.preventDefault()
            }
          }}
          disableOutsidePointerEvents={disabledOutsidePointerEvents}
          onDismiss={() => setOpen(false)}
          className="mb-5 inline-flex h-[300px] w-[400px] items-center justify-center rounded-lg bg-[var(--gray-3)] align-middle dark:bg-[var(--gray-A3)]"
        >
          <input type="text" />
        </DismissableLayer>
      ) : null}

      <div className="mb-5">
        <input type="text" defaultValue="hello" className="mr-5" />
        <button type="button" onMouseDown={() => alert('hey!')}>
          hey!
        </button>
      </div>
    </div>
  )
}

function FocusScopeBasic() {
  const [trapped, setTrapped] = React.useState(false)
  const [hasDestroyButton, setHasDestroyButton] = React.useState(true)

  return (
    <>
      <div>
        <button type="button" onClick={() => setTrapped(true)}>
          Trap
        </button>{' '}
        <input /> <input />
      </div>
      {trapped ? (
        <FocusScope asChild loop={trapped} trapped={trapped}>
          <form className="m-[50px] inline-flex max-w-[500px] flex-col gap-5 border-2 border-solid p-5">
            <input type="text" placeholder="First name" />
            <input type="text" placeholder="Last name" />
            <input type="number" placeholder="Age" />
            {hasDestroyButton && (
              <div>
                <button
                  type="button"
                  onClick={() => setHasDestroyButton(false)}
                >
                  Destroy me
                </button>
              </div>
            )}
            <button type="button" onClick={() => setTrapped(false)}>
              Close
            </button>
          </form>
        </FocusScope>
      ) : null}
      <div>
        <input /> <input />
      </div>
    </>
  )
}

async function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function CardContentPlaceholder() {
  return (
    <div className="flex max-w-[400px] items-center">
      <div className="h-[60px] w-[60px] rounded-full bg-[var(--gray-1)] dark:bg-[var(--gray-A3)]" />
      <div className="ml-3.5">
        <div className="h-3.5 w-[200px] rounded-full bg-[var(--gray-1)] dark:bg-[var(--gray-A3)]" />
        <div className="mt-2.5 h-3.5 w-[150px] rounded-full bg-[var(--gray-1)] dark:bg-[var(--gray-A3)]" />
      </div>
    </div>
  )
}

type MenuProps = Omit<
  React.ComponentProps<typeof Menu> & React.ComponentProps<typeof MenuContent>,
  | 'trapFocus'
  | 'onCloseAutoFocus'
  | 'disableOutsidePointerEvents'
  | 'disableOutsideScroll'
>

const MenuWithAnchor: React.FC<MenuProps> = (props) => {
  const { open = true, children, ...contentProps } = props
  return (
    <Menu open={open} onOpenChange={() => {}} modal={false}>
      {/* inline-block allows anchor to move when rtl changes on document */}
      <MenuAnchor className="inline-block" />
      <MenuPortal>
        <MenuContent
          className="data-[side=top]:animate-slideDownAndFade data-[side=right]:animate-slideLeftAndFade data-[side=bottom]:animate-slideUpAndFade data-[side=left]:animate-slideRightAndFade min-w-[220px] rounded-md bg-[var(--gray-1)] shadow-lg will-change-[opacity,transform] dark:bg-[var(--gray-A3)]"
          onCloseAutoFocus={(event) => event.preventDefault()}
          align="start"
          {...contentProps}
        >
          {children}
        </MenuContent>
      </MenuPortal>
    </Menu>
  )
}

const CaretDownIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 15 15"
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M4.18179 6.18181C4.35753 6.00608 4.64245 6.00608 4.81819 6.18181L7.49999 8.86362L10.1818 6.18181C10.3575 6.00608 10.6424 6.00608 10.8182 6.18181C10.9939 6.35755 10.9939 6.64247 10.8182 6.81821L7.81819 9.81821C7.73379 9.9026 7.61934 9.95001 7.49999 9.95001C7.38064 9.95001 7.26618 9.9026 7.18179 9.81821L4.18179 6.81821C4.00605 6.64247 4.00605 6.35755 4.18179 6.18181Z"
      fill="currentColor"
      fillRule="evenodd"
      clipRule="evenodd"
    ></path>
  </svg>
)

const TriggerWithIndicator: React.FC<{
  children?: React.ReactNode
  disabled?: boolean
}> = ({ children, disabled }) => {
  return (
    <NavigationMenu.Trigger
      className="group flex items-center justify-between gap-0.5 rounded-md px-4 py-2 text-[15px] font-medium leading-none text-[var(--accent-11)] outline-none hover:bg-[var(--accent-3)] focus:shadow-[0_0_0_2px] focus:shadow-[0_0_0_2px_var(--accent-7)] data-[state=delayed-open]:bg-[var(--accent-3)] data-[state=open]:bg-[var(--accent-3)] data-[state=delayed-open]:transition data-[state=open]:transition"
      disabled={disabled}
    >
      {children}
      <CaretDownIcon />
    </NavigationMenu.Trigger>
  )
}

const LinkGroup: React.FC<{ items: string[]; bordered?: boolean }> = ({
  items,
  bordered = true,
}) => {
  return (
    <ul
      className={`${bordered ? 'border-r border-[var(--gray-6)]' : ''} m-0 list-none p-0`}
    >
      {items.map((item, i) => (
        <li key={i}>
          <NavigationMenu.Link
            href="#example"
            className="flex items-center text-[var(--gray-12)]"
          >
            {item}
          </NavigationMenu.Link>
        </li>
      ))}
    </ul>
  )
}

function ErrorMessage({ children }: { children: string }) {
  return <div className="mt-1 text-sm text-red-500">{children}</div>
}

const Scrollable = (props: any) => (
  <div className="flex h-[50vh] items-center justify-center" {...props} />
)

type ProgressValue = number | null
function useProgressValueState(
  initialState: ProgressValue | (() => ProgressValue),
  max = 100,
) {
  const [value, setValue] = React.useState<number | null>(initialState)
  const precentage = value != null ? Math.round((value / max) * 100) : null
  return [value, precentage, setValue] as const
}

function useIndeterminateToggle(
  value: ProgressValue,
  setValue: React.Dispatch<React.SetStateAction<ProgressValue>>,
) {
  const previousValueRef = usePreviousValueRef(value)
  const toggleIndeterminate = React.useCallback(
    function setIndeterminate() {
      setValue((val) => {
        if (val == null) {
          return previousValueRef.current
        }
        return null
      })
    },
    [previousValueRef, setValue],
  )
  return toggleIndeterminate
}

function usePreviousValueRef(value: ProgressValue) {
  const previousValueRef = React.useRef<number>(value || 0)
  React.useEffect(() => {
    if (value != null) {
      previousValueRef.current = value
    }
  })
  return previousValueRef
}

function ProgressRange({ value, setValue, max = 100 }: any) {
  const previousValueRef = usePreviousValueRef(value)
  return (
    <input
      type="range"
      disabled={value == null}
      value={value == null ? previousValueRef.current : value}
      max={max}
      min={0}
      onChange={(e) => {
        const val = Number(e.target.value)
        if (!isNaN(val)) {
          setValue(val)
        }
      }}
    />
  )
}

const ButtonGroupContext = React.createContext<{
  value?: string
  setValue: React.Dispatch<React.SetStateAction<string | undefined>>
}>({} as any)

type RovingFocusGroupProps = React.ComponentProps<typeof RovingFocusGroup>

type ButtonGroupProps = Omit<
  React.ComponentPropsWithRef<'div'>,
  'defaultValue'
> &
  RovingFocusGroupProps & { defaultValue?: string }

const ButtonGroup = ({ defaultValue, ...props }: ButtonGroupProps) => {
  const [value, setValue] = React.useState(defaultValue)
  return (
    <ButtonGroupContext.Provider value={{ value, setValue }}>
      <RovingFocusGroup
        {...props}
        className={`inline-flex ${props.orientation === 'vertical' ? 'flex-col' : 'flex-row'} gap-2.5`}
      />
    </ButtonGroupContext.Provider>
  )
}

type ButtonProps = Omit<React.ComponentPropsWithRef<'button'>, 'value'> & {
  value?: string
}

const ButtonPrimitiveWrapper = (props: ButtonProps) => {
  const { value: contextValue, setValue } = React.useContext(ButtonGroupContext)
  const isSelected =
    contextValue !== undefined &&
    props.value !== undefined &&
    contextValue === props.value

  return (
    <RovingFocusGroupItem
      asChild
      active={isSelected}
      focusable={!props.disabled}
    >
      <button
        {...props}
        className={`rounded border border-[var(--gray-6)] px-2.5 py-1.5 ${isSelected ? 'border-[var(--gray-12)] bg-[var(--gray-12)] text-[var(--gray-1)]' : ''}`}
        onClick={props.disabled ? undefined : () => setValue(props.value)}
        onFocus={composeEventHandlers(props.onFocus, (event) => {
          if (contextValue !== undefined) {
            event.target.click()
          }
        })}
      />
    </RovingFocusGroupItem>
  )
}

const Copy = (props: any) => (
  <p className="mt-0 w-[400px]" style={{ ...props.style }}>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce sit amet eros
    iaculis, bibendum tellus ac, lobortis odio. Aliquam bibendum elit est, in
    iaculis est commodo id. Donec pulvinar est libero. Proin consectetur
    pellentesque molestie. Fusce mi ante, ullamcorper eu ante finibus, finibus
    pellentesque turpis. Mauris convallis, leo in vulputate varius, sapien
    lectus suscipit eros, ac semper odio sapien sit amet magna. Sed mattis
    turpis et lacinia ultrices. Nulla a commodo mauris. Orci varius natoque
    penatibus et magnis dis parturient montes, nascetur ridiculus mus.
    Pellentesque id tempor metus. Pellentesque faucibus tortor non nisi maximus
    dignissim. Etiam leo nisi, molestie a porttitor at, euismod a libero. Nullam
    placerat tristique enim nec pulvinar. Sed eleifend dictum nulla a aliquam.
    Sed tempus ipsum eget urna posuere aliquam. Nulla maximus tortor dui, sed
    laoreet odio aliquet ac. Vestibulum dolor orci, lacinia finibus vehicula
    eget, posuere ac lectus. Quisque non felis at ipsum scelerisque condimentum.
    In pharetra semper arcu, ut hendrerit sem auctor vel. Aliquam non lacinia
    elit, a facilisis ante. Praesent eget eros augue. Praesent nunc orci,
    ullamcorper non pulvinar eu, elementum id nibh. Nam id lorem euismod,
    sodales augue quis, porttitor magna. Vivamus ut nisl velit. Nam ultrices
    maximus felis, quis ullamcorper quam luctus et.
  </p>
)

const Slot = SlotPrimitive.Root
const Slottable = SlotPrimitive.Slottable

const SlotWithoutSlottable = (props: React.ComponentPropsWithRef<'div'>) => (
  <Slot {...props} className="test" />
)

const SlotWithSlottable = ({ children, ...props }: any) => (
  <Slot {...props}>
    <Slottable>{children}</Slottable>
    <span>world</span>
  </Slot>
)

const SlotButton = ({
  children,
  asChild = false,
  iconLeft,
  iconRight,
  ...props
}: React.ComponentProps<'button'> & {
  asChild?: boolean
  iconLeft?: React.ReactNode
  iconRight?: React.ReactNode
}) => {
  const Comp = asChild ? Slot : 'button'
  return (
    <Comp
      {...props}
      className="inline-flex items-center gap-1.5 rounded-sm border border-[var(--gray-12)] bg-[var(--gray-1)] p-2.5 font-sans text-sm dark:bg-[var(--gray-A3)]"
    >
      {iconLeft}
      <Slottable>{children}</Slottable>
      {iconRight}
    </Comp>
  )
}

const MockIcon = ({
  color = 'tomato',
  ...props
}: React.ComponentProps<'span'>) => (
  <span
    {...props}
    className="inline-block h-2.5 w-2.5"
    style={{ backgroundColor: color, ...props.style }}
  />
)

const ToolbarExample = ({ title, dir, orientation }: any) => {
  const toggleItemClass =
    'flex-shrink-0 flex-grow-0 basis-auto text-[var(--gray-11)] h-[25px] px-[10px] rounded inline-flex text-[13px] leading-none items-center justify-center bg-[var(--gray-1)] dark:bg-[var(--gray-A3)] hover:bg-[var(--gray-2)] focus:relative focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] outline-none data-[state=on]:bg-[var(--gray-5)] data-[state=on]:text-[var(--accent-11)]'
  return (
    <div className="m-[-1px] p-0.5">
      <h1>{title}</h1>
      <Toolbar.Root
        className="flex w-full min-w-max rounded-md bg-[var(--gray-1)] p-[10px] shadow-md dark:bg-[var(--gray-A3)]"
        orientation={orientation}
        loop={true}
        aria-label={`${title} toolbar`}
        dir={dir}
      >
        <Toolbar.Button className="inline-flex h-[25px] flex-shrink-0 flex-grow-0 basis-auto items-center justify-center rounded bg-[var(--gray-1)] px-[10px] text-[13px] leading-none text-[var(--gray-11)] outline-none hover:bg-[var(--gray-2)] focus:relative focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
          Button
        </Toolbar.Button>
        <Toolbar.Button
          className="inline-flex h-[25px] flex-shrink-0 flex-grow-0 basis-auto items-center justify-center rounded bg-[var(--gray-1)] px-[10px] text-[13px] leading-none text-[var(--gray-11)] outline-none hover:bg-[var(--gray-2)] focus:relative focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
          disabled
        >
          Button (disabled)
        </Toolbar.Button>
        <Toolbar.Separator className="mx-[10px] w-[1px] bg-[var(--gray-6)]"></Toolbar.Separator>
        <Toolbar.Link
          className="inline-flex h-[25px] flex-shrink-0 flex-grow-0 basis-auto items-center justify-center rounded bg-[var(--gray-1)] px-[10px] text-[13px] leading-none text-[var(--gray-11)] outline-none hover:bg-[var(--gray-2)] focus:relative focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
          href="https://www.w3.org/TR/2019/WD-wai-aria-practices-1.2-20191218/examples/toolbar/toolbar.html"
          target="_blank"
        >
          Link
        </Toolbar.Link>
        <Toolbar.Separator className="mx-[10px] w-[1px] bg-[var(--gray-6)]"></Toolbar.Separator>
        <Toolbar.Button
          className="inline-flex h-[25px] flex-shrink-0 flex-grow-0 basis-auto items-center justify-center rounded bg-[var(--gray-1)] px-[10px] text-[13px] leading-none text-[var(--gray-11)] outline-none hover:bg-[var(--gray-2)] focus:relative focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
          asChild
        >
          <Toggle.Root>Toggle</Toggle.Root>
        </Toolbar.Button>
        <Toolbar.Separator className="mx-[10px] w-[1px] bg-[var(--gray-6)]"></Toolbar.Separator>
        <Toolbar.ToggleGroup
          type="single"
          className="inline-flex space-x-0.5 rounded bg-[var(--gray-4)] p-[2px]"
        >
          <Toolbar.ToggleItem value="left" className={toggleItemClass}>
            Left
          </Toolbar.ToggleItem>
          <Toolbar.ToggleItem value="center" className={toggleItemClass}>
            Center
          </Toolbar.ToggleItem>
          <Toolbar.ToggleItem value="right" className={toggleItemClass}>
            Right
          </Toolbar.ToggleItem>
        </Toolbar.ToggleGroup>
        <Toolbar.Separator className="mx-[10px] w-[1px] bg-[var(--gray-6)]"></Toolbar.Separator>
        <DropdownMenu.Root>
          <Toolbar.Button
            className="inline-flex h-[25px] flex-shrink-0 flex-grow-0 basis-auto items-center justify-center rounded bg-[var(--gray-1)] px-[10px] text-[13px] leading-none text-[var(--gray-11)] outline-none hover:bg-[var(--gray-2)] focus:relative focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            asChild
          >
            <DropdownMenu.Trigger>
              <Button>open menu</Button>
            </DropdownMenu.Trigger>
          </Toolbar.Button>
          <DropdownMenu.Content sideOffset={5}>
            <DropdownMenu.Item>Undo</DropdownMenu.Item>
            <DropdownMenu.Item>Redo</DropdownMenu.Item>
            <DropdownMenu.Separator />
            <DropdownMenu.Item disabled>Cut</DropdownMenu.Item>
            <DropdownMenu.Item>Copy</DropdownMenu.Item>
            <DropdownMenu.Item>Paste</DropdownMenu.Item>
          </DropdownMenu.Content>
        </DropdownMenu.Root>
      </Toolbar.Root>
    </div>
  )
}

export default function CorePage() {
  const [accordionSingleValue, setAccordionSingleValue] = React.useState('one')
  const [selectControlledValue, setSelectControlledValue] = React.useState('uk')
  const [toggleGroupSingleValue, setToggleGroupSingleValue] = React.useState<
    string | undefined
  >()
  const [passwordToggleVisible, setPasswordToggleVisible] =
    React.useState(false)
  const VALID_CODE = '123456' // Used by OTP
  const [otpUncontrolledFormState, setOtpUncontrolledFormState] =
    React.useState<{
      type: 'idle' | 'valid' | 'invalid'
      error?: string
    }>({ type: 'idle' })
  const [otpShowSuccessMessage, setOtpShowSuccessMessage] =
    React.useState(false)
  const [formBasicServerErrors, setFormBasicServerErrors] = React.useState<{
    email?: boolean
    password?: boolean
  }>({})
  const [formBasicLoading, setFormBasicLoading] = React.useState(false)
  const [progressValue, progressPercentage, setProgressValue] =
    useProgressValueState(0, 150)
  const toggleProgressIndeterminate = useIndeterminateToggle(
    progressValue,
    setProgressValue,
  )
  const [radioGroupControlledValue, setRadioGroupControlledValue] =
    React.useState('2')
  const [rovingFocusDir, setRovingFocusDir] =
    React.useState<RovingFocusGroupProps['dir']>('ltr')
  const [scrollAreaProps, setScrollAreaProps] = React.useState({} as any)
  const [switchChecked, setSwitchChecked] = React.useState(true)
  const [toastHasUpgrade, setToastHasUpgrade] = React.useState(false)
  const [toastIsSubscribed, setToastIsSubscribed] = React.useState(false)
  const [toastSavedCount, setToastSavedCount] = React.useState(0)
  const [toastErrorCount, setErrorCount] = React.useState(0)
  const [toggleControlledPressed, setToggleControlledPressed] =
    React.useState(true)

  // Effects for controlled components if needed (e.g., Toast auto-open)
  React.useEffect(() => {
    if (!toastHasUpgrade) {
      const timer = window.setTimeout(() => setToastHasUpgrade(true), 10000)
      return () => window.clearTimeout(timer)
    }
  }, [toastHasUpgrade])

  return (
    <Tabs.Root defaultValue="components" className={'p-4'}>
      <ThemePanel />
      <Tabs.List>
        <Tabs.Trigger value="components">Components</Tabs.Trigger>
        <Tabs.Trigger value="utilities">Utilities</Tabs.Trigger>
        <Tabs.Trigger value="overview">Overview</Tabs.Trigger>
      </Tabs.List>
      <Tabs.Content value="overview">
        <Heading size="4">Basic Layout</Heading>
        <Grid columns="3" gap="3" mt="3">
          <Box style={{ background: '#eee', height: '50px' }}>Box</Box>
          <Flex style={{ background: '#ddd' }} align="center" justify="center">
            Flex
          </Flex>
          <Box>
            <Text>Text inside a Box</Text>
          </Box>
        </Grid>
      </Tabs.Content>
      <Tabs.Content value="components">
        {/*start1*/}
        <section className="space-y-4">
          <Heading size="5">Button</Heading>
          <div className="flex gap-4">
            <Button variant="solid">Primary</Button>
            <Button variant="soft">Soft</Button>
            <Button variant="outline">Outline</Button>
            <Button disabled>Disabled</Button>
          </div>
        </section>

        <section className="space-y-4">
          <Heading size="5">TextField</Heading>
          <Flex direction="column" gap="3" maxWidth="400px">
            <Box maxWidth="200px">
              <TextField.Root placeholder="Search the docs…" size="1">
                <TextField.Slot>
                  <MagnifyingGlassIcon height="16" width="16" />
                </TextField.Slot>
              </TextField.Root>
            </Box>

            <Box maxWidth="250px">
              <TextField.Root placeholder="Search the docs…" size="2">
                <TextField.Slot>
                  <MagnifyingGlassIcon height="16" width="16" />
                </TextField.Slot>
                <TextField.Slot>
                  <IconButton size="1" variant="ghost">
                    <DotsHorizontalIcon height="14" width="14" />
                  </IconButton>
                </TextField.Slot>
              </TextField.Root>
            </Box>

            <Box maxWidth="300px">
              <TextField.Root placeholder="Search the docs…" size="3">
                <TextField.Slot>
                  <MagnifyingGlassIcon height="16" width="16" />
                </TextField.Slot>
                <TextField.Slot pr="3">
                  <IconButton size="2" variant="ghost">
                    <DotsHorizontalIcon height="16" width="16" />
                  </IconButton>
                </TextField.Slot>
              </TextField.Root>
            </Box>
          </Flex>
        </section>

        <section className="space-y-4">
          <Heading size="5">Checkbox</Heading>
          <Checkbox defaultChecked></Checkbox>Accept Terms & Conditions
        </section>

        <section className="space-y-4">
          <Heading size="5">Select</Heading>
          <Select.Root defaultValue="option1">
            <Select.Trigger className="w-1/3" />
            <Select.Content>
              <Select.Item value="option1">Option 1</Select.Item>
              <Select.Item value="option2">Option 2</Select.Item>
              <Select.Item value="option3">Option 3</Select.Item>
            </Select.Content>
          </Select.Root>
        </section>

        <section className="space-y-4">
          <Heading size="5">Dialog</Heading>
          <Dialog.Root>
            <Dialog.Trigger>
              <Button>Open Dialog</Button>
            </Dialog.Trigger>
            <Dialog.Content>
              <Dialog.Title>Subscribe</Dialog.Title>
              <Dialog.Description>
                Get weekly product updates.
              </Dialog.Description>
              <Flex gap="3" mt="4" justify="end">
                <Dialog.Close>
                  <Button variant="soft" color="gray">
                    Cancel
                  </Button>
                </Dialog.Close>
                <Button>Submit</Button>
              </Flex>
            </Dialog.Content>
          </Dialog.Root>
        </section>

        <section className="space-y-4">
          <Heading size="5">Card</Heading>
          <Card className="w-1/2 p-6">
            <Heading size="4">Pro Plan</Heading>
            <Text className="mt-2">$49/month</Text>
            <Button className="mt-4">Choose Plan</Button>
          </Card>
        </section>

        <section className="space-y-4">
          <Heading size="5">Avatar</Heading>
          <Avatar fallback="JD" radius="full" size="4" />
        </section>

        <section className="space-y-4">
          <Heading size="5">Dropdown Menu</Heading>
          <DropdownMenu.Root>
            <DropdownMenu.Trigger>
              <Button>Open Menu</Button>
            </DropdownMenu.Trigger>
            <DropdownMenu.Content>
              <DropdownMenu.Item>Account</DropdownMenu.Item>
              <DropdownMenu.Item>Settings</DropdownMenu.Item>
              <DropdownMenu.Separator />
              <DropdownMenu.Item color="red">Logout</DropdownMenu.Item>
            </DropdownMenu.Content>
          </DropdownMenu.Root>
        </section>

        <section className="space-y-4">
          <Heading size="5">Tooltip</Heading>
          <Tooltip content="More info">
            <IconButton>
              <InfoCircledIcon />
            </IconButton>
          </Tooltip>
        </section>

        <section className="space-y-4">
          <Heading size="5">Callout</Heading>
          <Callout.Root color="indigo">
            <Callout.Text>
              This is a callout with helpful information.
            </Callout.Text>
          </Callout.Root>
        </section>

        <section className="space-y-4">
          <Heading size="5">Radio Group</Heading>
          <RadioGroup.Root defaultValue="a">
            <RadioGroup.Item value="a">Option A</RadioGroup.Item>
            <RadioGroup.Item value="b">Option B</RadioGroup.Item>
          </RadioGroup.Root>
        </section>

        <section className="space-y-4">
          <Heading size="5">Switch</Heading>
          <Switch defaultChecked />
        </section>

        <section className="space-y-4">
          <Heading size="5">Slider</Heading>
          <Slider defaultValue={[50]} max={100} step={1} />
        </section>

        <section className="space-y-4">
          <Heading size="5">Spinner</Heading>
          <Spinner />
        </section>

        <section className="space-y-4">
          <Heading size="5">Table</Heading>
          <Table.Root>
            <Table.Header>
              <Table.Row>
                <Table.ColumnHeaderCell>Name</Table.ColumnHeaderCell>
                <Table.ColumnHeaderCell>Email</Table.ColumnHeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              <Table.Row>
                <Table.Cell>John Doe</Table.Cell>
                <Table.Cell>john@example.com</Table.Cell>
              </Table.Row>
            </Table.Body>
          </Table.Root>
        </section>

        <section className="space-y-4">
          <Heading size="5">Progress</Heading>
          <Progress value={70} />
        </section>

        <section className="space-y-4">
          <Heading size="5">Segmented Control</Heading>
          <SegmentedControl.Root defaultValue="monthly">
            <SegmentedControl.Item value="monthly">
              Monthly
            </SegmentedControl.Item>
            <SegmentedControl.Item value="yearly">Yearly</SegmentedControl.Item>
          </SegmentedControl.Root>
        </section>

        <section className="space-y-4">
          <Heading size="5">Scroll Area</Heading>
          <ScrollArea style={{ height: 100, width: 200 }}>
            <Text>Scrollable content line 1</Text>
            <Text>Scrollable content line 2</Text>
            <Text>Scrollable content line 3</Text>
            <Text>Scrollable content line 4</Text>
            <Text>Scrollable content line 5</Text>
            <Text>Scrollable content line 6</Text>
            <Text>Scrollable content line 7</Text>
            <Text>Scrollable content line 8</Text>
          </ScrollArea>
        </section>

        <section className="space-y-4">
          <Heading size="5">Text Area</Heading>
          <TextArea placeholder="Write something..." className="w-1/2" />
        </section>
        <section className="space-y-4">
          <Heading size="5">Skeleton</Heading>
          <Skeleton loading height="24px" width="200px" />
        </section>
        <section className="space-y-4">
          <Heading size="5">Tab Nav</Heading>
          <TabNav.Root>
            <TabNav.Link href="#" active>
              Account
            </TabNav.Link>
            <TabNav.Link href="#">Documents</TabNav.Link>
            <TabNav.Link href="#">Settings</TabNav.Link>
          </TabNav.Root>
        </section>
        {/*end1*/}
      </Tabs.Content>

      <Tabs.Content
        value="utilities"
        className="grow rounded-b-md bg-[var(--gray-1)] p-5 outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
      >
        <h1>AccessibleIcon</h1>
        <AccessibleIcon.Root label="Close">
          <Cross1Icon />
        </AccessibleIcon.Root>

        <h1>Accordion</h1>
        {/* Using the Single example */}
        <div className="mb-5">
          <h2>Uncontrolled</h2>
          <Accordion.Root
            type="single"
            className="w-[300px] rounded-md bg-[var(--gray-6)] shadow-md"
          >
            <Accordion.Item
              className="mt-[1px] overflow-hidden first:mt-0 first:rounded-t last:rounded-b focus-within:relative focus-within:z-10 focus-within:shadow-[0_0_0_2px] focus-within:shadow-[var(--gray-12)]"
              value="one"
            >
              <Accordion.Header className="flex">
                <Accordion.Trigger className="group flex h-[45px] flex-1 cursor-default items-center justify-between px-5 text-[15px] leading-none text-[var(--accent-11)] shadow-[0_1px_0_var(--gray-6)] outline-none hover:bg-[var(--gray-2)] group-[data-disabled]:cursor-not-allowed group-[data-disabled]:text-[var(--gray-8)] data-[state=open]:shadow-[0_1px_0_var(--gray-6)] data-[state=open]:shadow-[inset_0_-1px_0_0,_0_1px_0_0]">
                  One
                </Accordion.Trigger>
              </Accordion.Header>
              <Accordion.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden text-[15px]">
                <div className="px-5 py-[15px]">
                  Per erat orci nostra luctus sociosqu mus risus penatibus, duis
                  elit vulputate viverra integer ullamcorper congue curabitur
                  sociis, nisi malesuada scelerisque quam suscipit habitant sed.
                </div>
              </Accordion.Content>
            </Accordion.Item>
            <Accordion.Item
              className="mt-[1px] overflow-hidden first:mt-0 first:rounded-t last:rounded-b focus-within:relative focus-within:z-10 focus-within:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
              value="two"
            >
              <Accordion.Header className="flex">
                <Accordion.Trigger className="group flex h-[45px] flex-1 cursor-default items-center justify-between px-5 text-[15px] leading-none text-[var(--accent-11)] shadow-[0_1px_0] shadow-[0_1px_0_var(--gray-6)] outline-none hover:bg-[var(--gray-2)] group-[data-disabled]:cursor-not-allowed group-[data-disabled]:text-[var(--gray-8)] data-[state=open]:shadow-[0_1px_0_var(--gray-6)] data-[state=open]:shadow-[inset_0_-1px_0_0,_0_1px_0_0]">
                  Two
                </Accordion.Trigger>
              </Accordion.Header>
              <Accordion.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden text-[15px]">
                <div className="px-5 py-[15px]">
                  Cursus sed mattis commodo fermentum conubia ipsum pulvinar
                  sagittis, diam eget bibendum porta nascetur ac dictum, leo
                  tellus dis integer platea ultrices mi.
                </div>
              </Accordion.Content>
            </Accordion.Item>
            <Accordion.Item
              className="mt-[1px] overflow-hidden first:mt-0 first:rounded-t last:rounded-b focus-within:relative focus-within:z-10 focus-within:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
              value="three"
              disabled
            >
              <Accordion.Header className="flex">
                <Accordion.Trigger className="group flex h-[45px] flex-1 cursor-default items-center justify-between px-5 text-[15px] leading-none text-[var(--accent-11)] shadow-[0_1px_0] shadow-[0_1px_0_var(--gray-6)] outline-none hover:bg-[var(--gray-2)] group-[data-disabled]:cursor-not-allowed group-[data-disabled]:text-[var(--gray-8)] data-[state=open]:shadow-[0_1px_0_var(--gray-6)] data-[state=open]:shadow-[inset_0_-1px_0_0,_0_1px_0_0]">
                  Three (disabled)
                </Accordion.Trigger>
              </Accordion.Header>
              <Accordion.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden text-[15px]">
                <div className="px-5 py-[15px]">
                  Sociis hac sapien turpis conubia sagittis justo dui, inceptos
                  penatibus feugiat himenaeos euismod magna, nec tempor pulvinar
                  eu etiam mattis.
                </div>
              </Accordion.Content>
            </Accordion.Item>
          </Accordion.Root>
        </div>

        <div className="mb-5">
          <h2>Controlled</h2>
          <Accordion.Root
            type="single"
            value={accordionSingleValue}
            onValueChange={setAccordionSingleValue}
            className="w-[300px] rounded-md bg-[var(--gray-6)] shadow-md"
          >
            <Accordion.Item
              className="mt-[1px] overflow-hidden first:mt-0 first:rounded-t last:rounded-b focus-within:relative focus-within:z-10 focus-within:shadow-[0_0_0_2px] focus-within:shadow-[var(--gray-12)]"
              value="one"
            >
              <Accordion.Header className="flex">
                <Accordion.Trigger className="group flex h-[45px] flex-1 cursor-default items-center justify-between px-5 text-[15px] leading-none text-[var(--accent-11)] shadow-[0_1px_0] shadow-[0_1px_0_var(--gray-6)] outline-none hover:bg-[var(--gray-2)] group-[data-disabled]:cursor-not-allowed group-[data-disabled]:text-[var(--gray-8)] data-[state=open]:shadow-[0_1px_0_var(--gray-6)] data-[state=open]:shadow-[inset_0_-1px_0_0,_0_1px_0_0]">
                  One
                </Accordion.Trigger>
              </Accordion.Header>
              <Accordion.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden text-[15px]">
                <div className="px-5 py-[15px]">
                  Per erat orci nostra luctus sociosqu mus risus penatibus, duis
                  elit vulputate viverra integer ullamcorper congue curabitur
                  sociis, nisi malesuada scelerisque quam suscipit habitant sed.
                </div>
              </Accordion.Content>
            </Accordion.Item>
            <Accordion.Item
              className="mt-[1px] overflow-hidden first:mt-0 first:rounded-t last:rounded-b focus-within:relative focus-within:z-10 focus-within:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
              value="two"
            >
              <Accordion.Header className="flex">
                <Accordion.Trigger className="group flex h-[45px] flex-1 cursor-default items-center justify-between px-5 text-[15px] leading-none text-[var(--accent-11)] shadow-[0_1px_0] shadow-[0_1px_0_var(--gray-6)] outline-none hover:bg-[var(--gray-2)] group-[data-disabled]:cursor-not-allowed group-[data-disabled]:text-[var(--gray-8)] data-[state=open]:shadow-[0_1px_0_var(--gray-6)] data-[state=open]:shadow-[inset_0_-1px_0_0,_0_1px_0_0]">
                  Two
                </Accordion.Trigger>
              </Accordion.Header>
              <Accordion.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden text-[15px]">
                <div className="px-5 py-[15px]">
                  Cursus sed mattis commodo fermentum conubia ipsum pulvinar
                  sagittis, diam eget bibendum porta nascetur ac dictum, leo
                  tellus dis integer platea ultrices mi.
                </div>
              </Accordion.Content>
            </Accordion.Item>
            <Accordion.Item
              className="mt-[1px] overflow-hidden first:mt-0 first:rounded-t last:rounded-b focus-within:relative focus-within:z-10 focus-within:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
              value="three"
              disabled
            >
              <Accordion.Header className="flex">
                <Accordion.Trigger className="group flex h-[45px] flex-1 cursor-default items-center justify-between px-5 text-[15px] leading-none text-[var(--accent-11)] shadow-[0_1px_0] shadow-[0_1px_0_var(--gray-6)] outline-none hover:bg-[var(--gray-2)] group-[data-disabled]:cursor-not-allowed group-[data-disabled]:text-[var(--gray-8)] data-[state=open]:shadow-[0_1px_0_var(--gray-6)] data-[state=open]:shadow-[inset_0_-1px_0_0,_0_1px_0_0]">
                  Three (disabled)
                </Accordion.Trigger>
              </Accordion.Header>
              <Accordion.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden text-[15px]">
                <div className="px-5 py-[15px]">
                  Sociis hac sapien turpis conubia sagittis justo dui, inceptos
                  penatibus feugiat himenaeos euismod magna, nec tempor pulvinar
                  eu etiam mattis.
                </div>
              </Accordion.Content>
            </Accordion.Item>
          </Accordion.Root>
        </div>

        <h1>AlertDialog</h1>
        <div className="mb-5">
          <AlertDialog.Root>
            <AlertDialog.Trigger>
              <Button className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
                delete everything
              </Button>
            </AlertDialog.Trigger>
            <AlertDialog.Content>
              <AlertDialog.Title>Are you sure?</AlertDialog.Title>
              <AlertDialog.Description>
                This will do a very dangerous thing. Thar be dragons!
              </AlertDialog.Description>
              <Flex gap="3" mt="4" justify="end">
                <AlertDialog.Cancel>
                  <Button variant="soft" color="gray">
                    maybe not
                  </Button>
                </AlertDialog.Cancel>
                <AlertDialog.Action>
                  <Button variant="solid" color="red">
                    yolo, do it
                  </Button>
                </AlertDialog.Action>
              </Flex>
            </AlertDialog.Content>
          </AlertDialog.Root>
        </div>

        <h1>Arrow</h1>
        {/*<Popper.Arrow style={{ fill: 'crimson' }} width={20} height={10} />*/}

        <h1>AspectRatio</h1>
        <div style={{ width: 500 }} className="mb-5">
          <AspectRatio.Root className="aspect-square rounded-md bg-[var(--gray-5)]">
            <h1>Default ratio (1/1)</h1>
          </AspectRatio.Root>
        </div>

        <h1>Avatar</h1>
        <div className="mb-5 flex gap-5">
          <h2>Without image & with fallback</h2>
          <Avatar fallback="JS" size="4" radius="full" />

          <h2>With image & with fallback</h2>
          <Avatar
            src="https://picsum.photos/id/1005/400/400"
            fallback="JS"
            size="4"
            radius="full"
          />

          <h2>With image & with fallback (but broken src)</h2>
          <Avatar
            src="https://broken.link.com/broken-pic.jpg"
            fallback={<AvatarIcon />}
            size="4"
            radius="full"
          />
        </div>

        <h1>Checkbox</h1>
        {/* Using LegacyStyled */}
        <div className="mb-5">
          <p>
            This checkbox is nested inside a label. The state is uncontrolled.
          </p>

          <h2>Custom label</h2>
          <Label.Root className="flex cursor-pointer items-center gap-2">
            Label{' '}
            <Checkbox className="flex h-[25px] w-[25px] appearance-none items-center justify-center rounded-[4px] bg-[var(--gray-1)] shadow-md outline-none hover:bg-[var(--accent-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]" />
          </Label.Root>

          <br />
          <br />

          <h2>Native label</h2>
          <label className="flex cursor-pointer items-center gap-2">
            Label{' '}
            <Checkbox className="flex h-[25px] w-[25px] appearance-none items-center justify-center rounded-[4px] bg-[var(--gray-1)] shadow-md outline-none hover:bg-[var(--accent-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]" />
          </label>

          <h2>Custom label + htmlFor</h2>
          <Label.Root
            className="flex cursor-pointer items-center gap-2"
            htmlFor="checkbox-one"
          >
            Label
          </Label.Root>
          <Checkbox
            className="flex h-[25px] w-[25px] appearance-none items-center justify-center rounded-[4px] bg-[var(--gray-1)] shadow-md outline-none hover:bg-[var(--accent-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            id="checkbox-one"
          />

          <br />
          <br />

          <h2>Native label + htmlFor</h2>
          <label
            className="flex cursor-pointer items-center gap-2"
            htmlFor="checkbox-two"
          >
            Label
          </label>
          <Checkbox
            className="flex h-[25px] w-[25px] appearance-none items-center justify-center rounded-[4px] bg-[var(--gray-1)] shadow-md outline-none hover:bg-[var(--accent-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            id="checkbox-two"
          />
        </div>

        <h1>Collapsible</h1>
        <div className="mb-5">
          <Collapsible.Root className="w-[300px]">
            <Collapsible.Trigger className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
              Trigger
            </Collapsible.Trigger>
            <Collapsible.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden">
              Content 1
            </Collapsible.Content>
          </Collapsible.Root>
        </div>

        <h1>Collection</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <List>
            <Item value="red">Red</Item>
            <Item value="green" disabled>
              Green
            </Item>
            <Item value="blue">Blue</Item>
            <LogItems />
          </List>
        </div>

        <h1>ContextMenu</h1>
        <div className="mb-5 flex items-center justify-center gap-5">
          <ContextMenu.Root>
            <ContextMenu.Trigger>
              <Button className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
                Right click here
              </Button>
            </ContextMenu.Trigger>
            <ContextMenu.Content alignOffset={-5}>
              <ContextMenu.Item onSelect={() => console.log('undo')}>
                Undo
              </ContextMenu.Item>
              <ContextMenu.Item onSelect={() => console.log('redo')}>
                Redo
              </ContextMenu.Item>
              <ContextMenu.Separator />
              <ContextMenu.Item disabled onSelect={() => console.log('cut')}>
                Cut
              </ContextMenu.Item>
              <ContextMenu.Item onSelect={() => console.log('copy')}>
                Copy
              </ContextMenu.Item>
              <ContextMenu.Item onSelect={() => console.log('paste')}>
                Paste
              </ContextMenu.Item>
            </ContextMenu.Content>
          </ContextMenu.Root>
        </div>

        <h1>Dialog</h1>
        <div className="mb-5">
          <Dialog.Root>
            <Dialog.Trigger>
              <Button className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
                open
              </Button>
            </Dialog.Trigger>
            <Dialog.Content>
              <Dialog.Title>Booking info</Dialog.Title>
              <Dialog.Description>
                Please enter the info for your booking below.
              </Dialog.Description>
              <Dialog.Close>
                <IconButton size="1" variant="soft" color="gray">
                  <Cross1Icon />
                </IconButton>
              </Dialog.Close>
            </Dialog.Content>
          </Dialog.Root>
        </div>

        <h1>DismissableLayer</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <DismissableLayerBasic />
        </div>

        <h1>DropdownMenu</h1>
        <div className="mb-5 flex h-[50vh] items-center justify-center">
          <DropdownMenu.Root>
            <DropdownMenu.Trigger>
              <Button className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
                Open
              </Button>
            </DropdownMenu.Trigger>
            <DropdownMenu.Content sideOffset={5}>
              <DropdownMenu.Item onSelect={() => console.log('undo')}>
                Undo
              </DropdownMenu.Item>
              <DropdownMenu.Item onSelect={() => console.log('redo')}>
                Redo
              </DropdownMenu.Item>
              <DropdownMenu.Separator />
              <DropdownMenu.Item disabled onSelect={() => console.log('cut')}>
                Cut
              </DropdownMenu.Item>
              <DropdownMenu.Item onSelect={() => console.log('copy')}>
                Copy
              </DropdownMenu.Item>
              <DropdownMenu.Item onSelect={() => console.log('paste')}>
                Paste
              </DropdownMenu.Item>
            </DropdownMenu.Content>
          </DropdownMenu.Root>
        </div>

        <h1>FocusScope</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <FocusScopeBasic />
        </div>

        <h1>Form</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <Form.Root
            className="flex w-[300px] flex-col gap-2.5"
            onClearServerErrors={() => setFormBasicServerErrors({})}
            onSubmit={async (event) => {
              const form = event.currentTarget
              event.preventDefault()

              const formData = new FormData(form)

              setFormBasicLoading(true)
              await wait(500)
              setFormBasicLoading(false)

              const errors = new Set()
              if (!(formData.get('email') as string).includes('@gmail.com'))
                errors.add('email')
              if (!(formData.get('password') as string).includes('#'))
                errors.add('password')

              if (errors.size > 0) {
                setFormBasicServerErrors(
                  Object.fromEntries([...errors].map((name) => [name, true])),
                )
                return
              }

              window.alert(
                JSON.stringify(Object.fromEntries(formData), null, 2),
              )
            }}
          >
            <Form.Field
              name="email"
              serverInvalid={formBasicServerErrors.email}
            >
              <Form.Label>Email</Form.Label>
              <Form.Control asChild>
                <input
                  type="email"
                  required
                  className="w-full rounded bg-[var(--gray-A5)] px-2.5 text-[15px] leading-[35px] shadow-[0_0_0_1px_var(--gray-12)] shadow-lg outline-none [appearance:textfield] [box-sizing:border-box] focus:shadow-[0_0_0_2px_var(--gray-12)]"
                  onChange={() =>
                    setFormBasicServerErrors((prev) => ({
                      ...prev,
                      email: false,
                    }))
                  }
                />
              </Form.Control>
              <Form.Message match="valueMissing">
                Email is required
              </Form.Message>
              <Form.Message
                match="typeMismatch"
                forceMatch={formBasicServerErrors.email}
              >
                Email is invalid
              </Form.Message>
            </Form.Field>

            <Form.Field
              name="password"
              serverInvalid={formBasicServerErrors.password}
            >
              <Form.Label>Password</Form.Label>
              <Form.Control asChild>
                <input
                  type="password"
                  required
                  className="w-full rounded bg-[var(--gray-A5)] px-2.5 text-[15px] leading-[35px] shadow-[0_0_0_1px_var(--gray-12)] shadow-lg outline-none [appearance:textfield] [box-sizing:border-box] focus:shadow-[0_0_0_2px_var(--gray-12)]"
                  onChange={() =>
                    setFormBasicServerErrors((prev) => ({
                      ...prev,
                      password: false,
                    }))
                  }
                />
              </Form.Control>
              <Form.Message match="valueMissing">
                Password is required
              </Form.Message>
              <Form.Message
                match={(value) => value.match(/.*[0-9]+.*/) == null}
                forceMatch={formBasicServerErrors.password}
              >
                Password is not complex enough
              </Form.Message>
              {formBasicServerErrors.password && (
                <Form.Message>Woops</Form.Message>
              )}
            </Form.Field>

            <Form.Submit asChild disabled={formBasicLoading}>
              <Button className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--green-4)] px-[15px] text-[15px] font-medium leading-none text-[var(--green-11)] outline-none hover:bg-[var(--green-5)] focus:shadow-[0_0_0_2px_var(--green-7)] disabled:cursor-not-allowed disabled:opacity-50">
                Submit
              </Button>
            </Form.Submit>
            <button
              type="reset"
              className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-4)] px-[15px] text-[15px] font-medium leading-none text-[var(--gray-11)] outline-none hover:bg-[var(--gray-5)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
            >
              Reset
            </button>
          </Form.Root>
        </div>

        <h1>HoverCard</h1>
        <div className="mb-5 flex justify-center p-[50px]">
          <HoverCard.Root>
            <HoverCard.Trigger>
              <a
                href="#"
                className="inline-block cursor-pointer rounded-full shadow-lg outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
              >
                trigger
              </a>
            </HoverCard.Trigger>
            <HoverCard.Content sideOffset={5}>
              <CardContentPlaceholder />
            </HoverCard.Content>
          </HoverCard.Root>
        </div>

        <h1>Label</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Label.Root>Label</Label.Root>
        </div>

        <h1>Menu</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <MenuWithAnchor>
            <MenuItem
              className="group relative flex h-[25px] select-none items-center rounded-[3px] px-[5px] text-[13px] leading-none text-[var(--accent-11)] outline-none data-[disabled]:pointer-events-none data-[highlighted]:bg-[var(--accent-9)] data-[disabled]:text-[var(--gray-8)] data-[highlighted]:text-[var(--accent-1)]"
              onSelect={() => window.alert('undo')}
            >
              Undo
            </MenuItem>
            <MenuItem
              className="group relative flex h-[25px] select-none items-center rounded-[3px] px-[5px] text-[13px] leading-none text-[var(--accent-11)] outline-none data-[disabled]:pointer-events-none data-[highlighted]:bg-[var(--accent-9)] data-[disabled]:text-[var(--gray-8)] data-[highlighted]:text-[var(--accent-1)]"
              onSelect={() => window.alert('redo')}
            >
              Redo
            </MenuItem>
            <MenuSeparator className="m-[5px] h-[1px] bg-[var(--accent-6)]" />
            <MenuItem
              className="group relative flex h-[25px] select-none items-center rounded-[3px] px-[5px] text-[13px] leading-none text-[var(--accent-11)] outline-none data-[disabled]:pointer-events-none data-[highlighted]:bg-[var(--accent-9)] data-[disabled]:text-[var(--gray-8)] data-[highlighted]:text-[var(--accent-1)]"
              disabled
              onSelect={() => window.alert('cut')}
            >
              Cut
            </MenuItem>
            <MenuItem
              className="group relative flex h-[25px] select-none items-center rounded-[3px] px-[5px] text-[13px] leading-none text-[var(--accent-11)] outline-none data-[disabled]:pointer-events-none data-[highlighted]:bg-[var(--accent-9)] data-[disabled]:text-[var(--gray-8)] data-[highlighted]:text-[var(--accent-1)]"
              onSelect={() => window.alert('copy')}
            >
              Copy
            </MenuItem>
            <MenuItem
              className="group relative flex h-[25px] select-none items-center rounded-[3px] px-[5px] text-[13px] leading-none text-[var(--accent-11)] outline-none data-[disabled]:pointer-events-none data-[highlighted]:bg-[var(--accent-9)] data-[disabled]:text-[var(--gray-8)] data-[highlighted]:text-[var(--accent-1)]"
              onSelect={() => window.alert('paste')}
            >
              Paste
            </MenuItem>
          </MenuWithAnchor>
        </div>

        <h1>Menubar</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <MenubarExample title="Horizontal" />
          <MenubarExample title="Vertical" orientation="vertical" />
        </div>

        <h1>NavigationMenu</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <NavigationMenu.Root>
            <NavigationMenu.List className="m-0 flex list-none justify-center rounded-md bg-[var(--gray-1)] p-1 shadow-md dark:bg-[var(--gray-A3)]">
              <NavigationMenu.Item className="relative">
                <TriggerWithIndicator>Products</TriggerWithIndicator>
                <NavigationMenu.Content className="data-[motion=from-start]:animate-enterFromLeft data-[motion=from-end]:animate-enterFromRight data-[motion=to-start]:animate-exitToLeft data-[motion=to-end]:animate-exitToRight absolute left-0 top-0 w-auto md:w-auto">
                  <LinkGroup
                    bordered={false}
                    items={[
                      'Fusce pellentesque',
                      'Aliquam porttitor',
                      'Pellentesque',
                    ]}
                  />
                </NavigationMenu.Content>
              </NavigationMenu.Item>

              <NavigationMenu.Item className="relative">
                <TriggerWithIndicator>Company</TriggerWithIndicator>
                <NavigationMenu.Content className="data-[motion=from-start]:animate-enterFromLeft data-[motion=from-end]:animate-enterFromRight data-[motion=to-start]:animate-exitToLeft data-[motion=to-end]:animate-exitToRight absolute left-0 top-0 w-auto md:w-auto">
                  <LinkGroup
                    bordered={false}
                    items={[
                      'Fusce pellentesque',
                      'Aliquam porttitor',
                      'Pellentesque',
                    ]}
                  />
                </NavigationMenu.Content>
              </NavigationMenu.Item>

              <NavigationMenu.Item className="relative">
                <TriggerWithIndicator disabled>Developers</TriggerWithIndicator>
                <NavigationMenu.Content className="data-[motion=from-start]:animate-enterFromLeft data-[motion=from-end]:animate-enterFromRight data-[motion=to-start]:animate-exitToLeft data-[motion=to-end]:animate-exitToRight absolute left-0 top-0 w-auto md:w-auto">
                  <LinkGroup
                    bordered={false}
                    items={['Aliquam porttitor', 'Pellentesque']}
                  />
                </NavigationMenu.Content>
              </NavigationMenu.Item>

              <NavigationMenu.Item className="relative">
                <NavigationMenu.Link
                  href="#example"
                  className="group flex items-center justify-between gap-0.5 rounded-md px-4 py-2 text-[15px] font-medium leading-none text-[var(--accent-11)] outline-none hover:bg-[var(--accent-3)] focus:shadow-[0_0_0_2px] focus:shadow-[0_0_0_2px_var(--accent-7)] data-[state=delayed-open]:bg-[var(--accent-3)] data-[state=open]:bg-[var(--accent-3)] data-[state=delayed-open]:transition data-[state=open]:transition"
                >
                  Link
                </NavigationMenu.Link>
              </NavigationMenu.Item>
            </NavigationMenu.List>
          </NavigationMenu.Root>
        </div>

        <h1>OneTimePasswordField</h1>
        {/* Using Uncontrolled */}
        <div className="mb-5">
          <div className="flex flex-col items-center justify-center p-5">
            <form
              className="flex flex-col items-center gap-5"
              onSubmit={(event) => {
                const formData = new FormData(event.currentTarget)
                const code = formData.get('code') as string
                event.preventDefault()
                if (code.length === VALID_CODE.length && code !== VALID_CODE) {
                  setOtpUncontrolledFormState({
                    type: 'invalid',
                    error: 'Invalid code',
                  })
                }
                //
                else if (code.length !== VALID_CODE.length) {
                  setOtpUncontrolledFormState({
                    type: 'invalid',
                    error: 'Please fill in all fields',
                  })
                }
                //
                else if (Math.random() > 0.675) {
                  setOtpUncontrolledFormState({
                    type: 'invalid',
                    error: 'Server error',
                  })
                }
                //
                else {
                  setOtpUncontrolledFormState({ type: 'valid' })
                  setOtpShowSuccessMessage(true)
                }
              }}
            >
              <div className="flex flex-col items-center gap-2.5">
                <OneTimePasswordField.Root
                  data-state={otpUncontrolledFormState.type}
                  className="flex items-center gap-2.5 data-[state=invalid]:border-red-500"
                >
                  <OneTimePasswordField.Input className="h-10 w-10 rounded border border-[var(--gray-6)] text-center text-xl focus:border-blue-500 focus:outline-none data-[state=invalid]:border-red-500" />
                  <Separator.Root
                    orientation="vertical"
                    className="h-6 w-[1px] bg-[var(--gray-6)]"
                  />
                  <OneTimePasswordField.Input className="h-10 w-10 rounded border border-[var(--gray-6)] text-center text-xl focus:border-blue-500 focus:outline-none data-[state=invalid]:border-red-500" />
                  <Separator.Root
                    orientation="vertical"
                    className="h-6 w-[1px] bg-[var(--gray-6)]"
                  />
                  <OneTimePasswordField.Input className="h-10 w-10 rounded border border-[var(--gray-6)] text-center text-xl focus:border-blue-500 focus:outline-none data-[state=invalid]:border-red-500" />
                  <Separator.Root
                    orientation="vertical"
                    className="h-6 w-[1px] bg-[var(--gray-6)]"
                  />
                  <OneTimePasswordField.Input className="h-10 w-10 rounded border border-[var(--gray-6)] text-center text-xl focus:border-blue-500 focus:outline-none data-[state=invalid]:border-red-500" />
                  <Separator.Root
                    orientation="vertical"
                    className="h-6 w-[1px] bg-[var(--gray-6)]"
                  />
                  <OneTimePasswordField.Input className="h-10 w-10 rounded border border-[var(--gray-6)] text-center text-xl focus:border-blue-500 focus:outline-none data-[state=invalid]:border-red-500" />
                  <Separator.Root
                    orientation="vertical"
                    className="h-6 w-[1px] bg-[var(--gray-6)]"
                  />
                  <OneTimePasswordField.Input className="h-10 w-10 rounded border border-[var(--gray-6)] text-center text-xl focus:border-blue-500 focus:outline-none data-[state=invalid]:border-red-500" />

                  <OneTimePasswordField.HiddenInput name="code" />
                </OneTimePasswordField.Root>
                {otpUncontrolledFormState.type === 'invalid' && (
                  <ErrorMessage>{`${otpUncontrolledFormState.error}`}</ErrorMessage>
                )}
              </div>
              <button
                type="reset"
                className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-4)] px-[15px] text-[15px] font-medium leading-none text-[var(--gray-11)] outline-none hover:bg-[var(--gray-5)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
              >
                Reset form
              </button>
              <button className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--green-4)] px-[15px] text-[15px] font-medium leading-none text-[var(--green-11)] outline-none hover:bg-[var(--green-5)] focus:shadow-[0_0_0_2px_var(--green-7)]">
                Submit
              </button>
            </form>
          </div>
        </div>

        <h1>PasswordToggleField</h1>
        <div className="mb-5">
          <div className="flex flex-col items-center justify-center p-5">
            <PasswordToggleField.Root>
              <div className="flex items-center rounded border border-[var(--gray-6)] focus-within:border-blue-500">
                <PasswordToggleField.Input className="flex-1 px-2.5 py-1.5 text-base outline-none" />
                <PasswordToggleField.Toggle className="px-2.5 py-1.5 text-[var(--gray-9)] hover:text-[var(--gray-11)] focus:outline-none">
                  <PasswordToggleField.Icon
                    className="h-5 w-5"
                    visible={<EyeOpenIcon />}
                    hidden={<EyeClosedIcon />}
                  />
                </PasswordToggleField.Toggle>
              </div>
            </PasswordToggleField.Root>
          </div>
        </div>

        <h1>Popover</h1>
        <div className="mb-5 flex h-[50vh] items-center justify-center">
          <Popover.Root>
            <Popover.Trigger>
              <Button className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
                open
              </Button>
            </Popover.Trigger>
            <Popover.Content sideOffset={5}>
              <Popover.Close>
                <IconButton size="1" variant="soft" color="gray">
                  <Cross1Icon />
                </IconButton>
              </Popover.Close>
            </Popover.Content>
          </Popover.Root>
          <input />
        </div>

        <h1>Popper</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Scrollable>
            <Popper>
              <PopperAnchor
                className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
                onClick={() => {
                  /* handle open */
                }}
              >
                open
              </PopperAnchor>
              <PopperContent
                className="data-[side=top]:animate-slideDownAndFade data-[side=right]:animate-slideLeftAndFade data-[side=bottom]:animate-slideUpAndFade data-[side=left]:animate-slideRightAndFade w-[260px] rounded bg-[var(--gray-1)] p-5 shadow-lg dark:bg-[var(--gray-A3)]"
                sideOffset={5}
              >
                <button
                  className="absolute right-[5px] top-[5px] inline-flex h-[25px] w-[25px] cursor-default items-center justify-center rounded-full text-[var(--gray-11)] outline-none hover:bg-[var(--gray-4)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)]"
                  onClick={() => {
                    /* handle close */
                  }}
                >
                  close
                </button>
                <PopperArrow
                  className="fill-[var(--gray-1)] dark:fill-[var(--gray-A3)]"
                  width={20}
                  height={10}
                />
              </PopperContent>
            </Popper>
          </Scrollable>
        </div>

        <h1>Portal</h1>
        {/* Using Base */}
        <div className="mb-5">
          <div className="max-h-[200px] max-w-[300px] overflow-auto border border-solid">
            <h1>This content is rendered in the main DOM tree</h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos
              porro, est ex quia itaque facere fugit necessitatibus aut enim.
              Nisi rerum quae, repellat in perspiciatis explicabo laboriosam
              necessitatibus eius pariatur.
            </p>

            <Portal.Root>
              <h1>This content is rendered in a portal (another DOM tree)</h1>
              <p>
                Because of the portal, it can appear in a different DOM tree
                from the main one (by default a new element inside the body),
                even though it is part of the same React tree.
              </p>
            </Portal.Root>
          </div>
        </div>

        <h1>Presence</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <PresenceBasic />
        </div>

        <h1>Progress</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Progress value={progressValue} max={150} />
          <hr />
          <Button
            onClick={toggleProgressIndeterminate}
            className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
          >
            Toggle Indeterminate
          </Button>
          <ProgressRange
            value={progressValue}
            setValue={setProgressValue}
            max={150}
          />
        </div>

        <h1>RadioGroup</h1>
        {/* Using LegacyStyled */}
        <div className="mb-5">
          <Label.Root className="flex cursor-pointer items-center gap-2">
            Favourite pet
            <RadioGroup.Root className="flex flex-col gap-2.5" defaultValue="1">
              <Label.Root className="flex cursor-pointer items-center gap-2">
                <RadioGroup.Item value="1" />
                Cat
              </Label.Root>
              <Label.Root className="flex cursor-pointer items-center gap-2">
                <RadioGroup.Item value="2" />
                Dog
              </Label.Root>
              <Label.Root className="flex cursor-pointer items-center gap-2">
                <RadioGroup.Item value="3" />
                Rabbit
              </Label.Root>
            </RadioGroup.Root>
          </Label.Root>
        </div>

        <h1>RovingFocusGroup</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <div dir={rovingFocusDir}>
            <h2>no orientation (both) + no looping</h2>
            <ButtonGroup dir={rovingFocusDir} defaultValue="two">
              <ButtonPrimitiveWrapper value="one">One</ButtonPrimitiveWrapper>
              <ButtonPrimitiveWrapper value="two">Two</ButtonPrimitiveWrapper>
              <ButtonPrimitiveWrapper disabled value="three">
                Three
              </ButtonPrimitiveWrapper>
              <ButtonPrimitiveWrapper value="four">Four</ButtonPrimitiveWrapper>
            </ButtonGroup>
          </div>
        </div>

        <h1>ScrollArea</h1>
        {/* Using Basic */}
        <div className="mb-5">
          <div className="overflow-hidden rounded bg-[var(--gray-1)] shadow-md dark:bg-[var(--gray-A3)]">
            <ScrollArea
              style={{ width: 400, height: 400, margin: '30px auto' }}
            >
              {Array.from({ length: 10 }).map((_, index) => (
                <Copy key={index} />
              ))}
            </ScrollArea>
          </div>
        </div>

        <h1>Separator</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <h2>Horizontal</h2>
          <p>The following separator is horizontal and has semantic meaning.</p>
          <Separator.Root
            className="my-[15px] bg-[var(--accent-6)] data-[orientation=horizontal]:h-[1px] data-[orientation=vertical]:w-[1px]"
            orientation="horizontal"
          />
          <p>
            The following separator is horizontal and is purely decorative.
            Assistive technology will ignore this element.
          </p>
          <Separator.Root
            className="my-[15px] bg-[var(--accent-6)] data-[orientation=horizontal]:h-[1px] data-[orientation=vertical]:w-[1px]"
            orientation="horizontal"
            decorative
          />

          <h2>Vertical</h2>
          <div className="flex items-center">
            <p>The following separator is vertical and has semantic meaning.</p>
            <Separator.Root
              className="mx-[15px] bg-[var(--accent-6)] data-[orientation=horizontal]:h-[1px] data-[orientation=vertical]:w-[1px]"
              orientation="vertical"
            />
            <p>
              The following separator is vertical and is purely decorative.
              Assistive technology will ignore this element.
            </p>
            <Separator.Root
              className="mx-[15px] bg-[var(--accent-6)] data-[orientation=horizontal]:h-[1px] data-[orientation=vertical]:w-[1px]"
              orientation="vertical"
              decorative
            />
          </div>
        </div>

        <h1>Slider</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Slider
            defaultValue={[50]}
            max={100}
            step={1}
            className="relative flex h-5 w-[200px] touch-none select-none items-center"
          />
        </div>

        <h1>Slot</h1>
        {/* Using WithoutSlottable, WithSlottable, ButtonAsLink */}
        <div className="mb-5">
          <h2>Without Slottable</h2>
          <SlotWithoutSlottable>
            <b data-slot-element>hello</b>
          </SlotWithoutSlottable>

          <h2>With Slottable</h2>
          <SlotWithSlottable>
            <b data-slot-element>hello</b>
          </SlotWithSlottable>

          <h2>Button with left/right icons as link (asChild)</h2>
          <SlotButton
            asChild
            iconLeft={<MockIcon color="tomato" />}
            iconRight={<MockIcon color="royalblue" />}
          >
            <a href="https://radix-ui.com">
              Button <em>text</em>
            </a>
          </SlotButton>
        </div>

        <h1>Switch</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Label.Root className="flex cursor-default items-center gap-2">
            This is the label <Switch id="s1" defaultChecked />
          </Label.Root>
        </div>

        <h1>Tabs</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <h2>Horizontal (automatic activation)</h2>
          <Tabs.Root
            defaultValue="tab1"
            className="flex w-[300px] flex-col shadow-md"
          >
            <Tabs.List aria-label="tabs example">
              <Tabs.Trigger value="tab1">Tab 1</Tabs.Trigger>
              <Tabs.Trigger value="tab2" disabled>
                Tab 2
              </Tabs.Trigger>
              <Tabs.Trigger value="tab3">Tab 3</Tabs.Trigger>
            </Tabs.List>
            <Tabs.Content
              value="tab1"
              className="grow rounded-b-md bg-[var(--gray-1)] p-5 outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            >
              Dis metus rhoncus sit convallis sollicitudin vel cum, hac purus
              tincidunt eros sem himenaeos integer, faucibus varius nullam
              nostra bibendum consectetur mollis, gravida elementum pellentesque
              volutpat dictum ipsum.
            </Tabs.Content>
            <Tabs.Content
              value="tab2"
              className="grow rounded-b-md bg-[var(--gray-1)] p-5 outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            >
              You'll never find me!
            </Tabs.Content>
            <Tabs.Content
              value="tab3"
              className="grow rounded-b-md bg-[var(--gray-1)] p-5 outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            >
              Ut nisi elementum metus semper mauris dui fames accumsan aenean,
              maecenas ac sociis dolor quam tempus pretium.
            </Tabs.Content>
          </Tabs.Root>
        </div>

        <div className="mb-5">
          <h2>Vertical (manual activation)</h2>
          <Tabs.Root
            defaultValue="tab1"
            className="flex w-[300px] shadow-md"
            orientation="vertical"
            activationMode="manual"
          >
            <Tabs.List aria-label="tabs example">
              <Tabs.Trigger value="tab1">Tab 1</Tabs.Trigger>
              <Tabs.Trigger value="tab2" disabled>
                Tab 2
              </Tabs.Trigger>
              <Tabs.Trigger value="tab3">Tab 3</Tabs.Trigger>
            </Tabs.List>
            <Tabs.Content
              value="tab1"
              className="grow rounded-b-md bg-[var(--gray-1)] p-5 outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            >
              Dis metus rhoncus sit convallis sollicitudin vel cum, hac purus
              tincidunt eros sem himenaeos integer, faucibus varius nullam
              nostra bibendum consectetur mollis, gravida elementum pellentesque
              volutpat dictum ipsum.
            </Tabs.Content>
            <Tabs.Content
              value="tab2"
              className="grow rounded-b-md bg-[var(--gray-1)] p-5 outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            >
              You'll never find me!
            </Tabs.Content>
            <Tabs.Content
              value="tab3"
              className="grow rounded-b-md bg-[var(--gray-1)] p-5 outline-none focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
            >
              Ut nisi elementum metus semper mauris dui fames accumsan aenean,
              maecenas ac sociis dolor quam tempus pretium.
            </Tabs.Content>
          </Tabs.Root>
        </div>

        <h1>Toast</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Toast.Provider>
            <Toast.Root>
              <Toast.Title>Upgrade available</Toast.Title>
              <Toast.Description>
                We've just released Radix version 3.0
              </Toast.Description>
              <Toast.Action altText="Goto account settings to upgrade">
                Upgrade
              </Toast.Action>
            </Toast.Root>
            <Toast.Viewport className="fixed bottom-0 right-0 z-[2147483647] m-0 flex w-[390px] max-w-[100vw] list-none flex-col gap-[10px] p-[var(--viewport-padding)] outline-none [--viewport-padding:_25px]" />
          </Toast.Provider>
        </div>

        <h1>Toggle</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Toggle.Root className="cursor-default rounded bg-[var(--gray-4)] px-[15px] font-medium leading-[35px] text-[var(--gray-11)] shadow-md outline-none hover:bg-[var(--gray-5)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] data-[state=on]:bg-[var(--accent-5)] data-[state=on]:text-[var(--accent-11)]">
            Toggle
          </Toggle.Root>
        </div>

        <h1>ToggleGroup</h1>
        {/* Using Single */}
        <div className="mb-5">
          <h2>Uncontrolled</h2>
          <ToggleGroup.Root
            type="single"
            className="inline-flex gap-0.5 rounded bg-[var(--gray-4)] p-0.5 shadow-md"
            aria-label="Options"
            defaultValue="1"
          >
            <ToggleGroup.Item value="1">Option 1</ToggleGroup.Item>
            <ToggleGroup.Item value="2">Option 2</ToggleGroup.Item>
            <ToggleGroup.Item value="3">Option 3</ToggleGroup.Item>
          </ToggleGroup.Root>
        </div>

        <div className="mb-5">
          <h2>Controlled</h2>
          <ToggleGroup.Root
            type="single"
            className="inline-flex gap-0.5 rounded bg-[var(--gray-4)] p-0.5 shadow-md"
            aria-label="Options"
            value={toggleGroupSingleValue}
            onValueChange={setToggleGroupSingleValue}
          >
            <ToggleGroup.Item value="1">Option 1</ToggleGroup.Item>
            <ToggleGroup.Item value="2">Option 2</ToggleGroup.Item>
            <ToggleGroup.Item value="3">Option 3</ToggleGroup.Item>
          </ToggleGroup.Root>
        </div>

        <h1>Toolbar</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <ToolbarExample title="Horizontal" />
          <ToolbarExample title="Vertical" orientation="vertical" />
        </div>

        <h1>Tooltip</h1>
        {/* Using Styled */}
        <div className="mb-5">
          <Tooltip content="Add to library">
            <IconButton radius="full">
              <PlusIcon />
            </IconButton>
          </Tooltip>
        </div>

        <h1>VisuallyHidden</h1>
        <div className="mb-5">
          <button>
            <VisuallyHidden.Root>Save the file</VisuallyHidden.Root>
            <span aria-hidden>💾</span>
          </button>
        </div>
      </Tabs.Content>
    </Tabs.Root>
  )
}

// PresenceBasic helper
function PresenceBasic() {
  const [open, setOpen] = React.useState(true)

  return (
    <>
      <Button
        onClick={() => setOpen((prevOpen) => !prevOpen)}
        className="inline-flex h-[35px] items-center justify-center rounded bg-[var(--gray-1)] px-[15px] text-[15px] font-medium leading-none text-[var(--accent-11)] shadow-md outline-none hover:bg-[var(--gray-3)] focus:shadow-[0_0_0_2px] focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]"
      >
        toggle
      </Button>

      <Presence present={open}>
        <div>Content</div>
      </Presence>
    </>
  )
}

// MenubarExample helper
const MenubarExample = ({ title, orientation }: any) => {
  const itemClass =
    'group text-[13px] leading-none text-[var(--accent-11)] rounded-[3px] flex items-center h-[25px] px-[5px] relative select-none outline-none data-[disabled]:text-[var(--gray-8)] data-[disabled]:pointer-events-none data-[highlighted]:bg-[var(--accent-9)] data-[highlighted]:text-[var(--accent-1)]'
  const separatorClass = 'h-[1px] bg-[var(--accent-6)] m-[5px]'

  return (
    <div className="m-[-1px] p-0.5">
      <h2>{title}</h2>
      <Menubar.Root
        className={`flex rounded-md bg-[var(--gray-1)] p-0.5 shadow-md dark:bg-[var(--gray-A3)] ${orientation === 'vertical' ? 'flex-col' : 'flex-row'}`}
      >
        <Menubar.Menu>
          <Menubar.Trigger className="group flex h-[25px] cursor-default items-center rounded bg-[var(--gray-1)] px-2.5 text-[13px] leading-none text-[var(--accent-11)] outline-none data-[highlighted]:bg-[var(--gray-4)] data-[state=open]:bg-[var(--gray-4)] data-[highlighted]:text-[var(--accent-11)] data-[state=open]:text-[var(--accent-11)] data-[highlighted]:focus:shadow-[0_0_0_2px] data-[state=open]:focus:shadow-[0_0_0_2px] data-[highlighted]:focus:shadow-[var(--gray-12)] data-[state=open]:focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
            File
          </Menubar.Trigger>
          <Menubar.Portal>
            <Menubar.Content
              className="data-[side=top]:animate-slideDownAndFade data-[side=right]:animate-slideLeftAndFade data-[side=bottom]:animate-slideUpAndFade data-[side=left]:animate-slideRightAndFade min-w-[220px] rounded-md bg-[var(--gray-1)] p-[5px] shadow-lg will-change-[opacity,transform] dark:bg-[var(--gray-A3)]"
              align="start"
              sideOffset={5}
              alignOffset={-3}
            >
              <Menubar.Item className={itemClass}>New Tab</Menubar.Item>
              <Menubar.Item className={itemClass}>New Window</Menubar.Item>
              <Menubar.Separator className={separatorClass} />
              <Menubar.Item className={itemClass}>Close Tab</Menubar.Item>
              <Menubar.Item className={itemClass}>Close Window</Menubar.Item>
            </Menubar.Content>
          </Menubar.Portal>
        </Menubar.Menu>

        <Menubar.Menu>
          <Menubar.Trigger className="group flex h-[25px] cursor-default items-center rounded bg-[var(--gray-1)] px-2.5 text-[13px] leading-none text-[var(--accent-11)] outline-none data-[highlighted]:bg-[var(--gray-4)] data-[state=open]:bg-[var(--gray-4)] data-[highlighted]:text-[var(--accent-11)] data-[state=open]:text-[var(--accent-11)] data-[highlighted]:focus:shadow-[0_0_0_2px] data-[state=open]:focus:shadow-[0_0_0_2px] data-[highlighted]:focus:shadow-[var(--gray-12)] data-[state=open]:focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
            Edit
          </Menubar.Trigger>
          <Menubar.Portal>
            <Menubar.Content
              className="data-[side=top]:animate-slideDownAndFade data-[side=right]:animate-slideLeftAndFade data-[side=bottom]:animate-slideUpAndFade data-[side=left]:animate-slideRightAndFade min-w-[220px] rounded-md bg-[var(--gray-1)] p-[5px] shadow-lg will-change-[opacity,transform] dark:bg-[var(--gray-A3)]"
              align="start"
              sideOffset={5}
              alignOffset={-3}
            >
              <Menubar.Item className={itemClass}>Undo</Menubar.Item>
              <Menubar.Item className={itemClass}>Redo</Menubar.Item>
              <Menubar.Separator className={separatorClass} />
              <Menubar.CheckboxItem className={itemClass} checked>
                Show Bookmarks
              </Menubar.CheckboxItem>
              <Menubar.CheckboxItem className={itemClass}>
                Show Full URLs
              </Menubar.CheckboxItem>
              <Menubar.Separator className={separatorClass} />
              <Menubar.Item className={itemClass}>Cut</Menubar.Item>
              <Menubar.Item className={itemClass}>Copy</Menubar.Item>
              <Menubar.Item className={itemClass}>Paste</Menubar.Item>
            </Menubar.Content>
          </Menubar.Portal>
        </Menubar.Menu>

        <Menubar.Menu>
          <Menubar.Trigger className="group flex h-[25px] cursor-default items-center rounded bg-[var(--gray-1)] px-2.5 text-[13px] leading-none text-[var(--accent-11)] outline-none data-[highlighted]:bg-[var(--gray-4)] data-[state=open]:bg-[var(--gray-4)] data-[highlighted]:text-[var(--accent-11)] data-[state=open]:text-[var(--accent-11)] data-[highlighted]:focus:shadow-[0_0_0_2px] data-[state=open]:focus:shadow-[0_0_0_2px] data-[highlighted]:focus:shadow-[var(--gray-12)] data-[state=open]:focus:shadow-[var(--gray-12)] dark:bg-[var(--gray-A3)]">
            View
          </Menubar.Trigger>
          <Menubar.Portal>
            <Menubar.Content
              className="data-[side=top]:animate-slideDownAndFade data-[side=right]:animate-slideLeftAndFade data-[side=bottom]:animate-slideUpAndFade data-[side=left]:animate-slideRightAndFade min-w-[220px] rounded-md bg-[var(--gray-1)] p-[5px] shadow-lg will-change-[opacity,transform] dark:bg-[var(--gray-A3)]"
              align="start"
              sideOffset={5}
              alignOffset={-3}
            >
              <Menubar.RadioGroup value="one">
                <Menubar.RadioItem className={itemClass} value="one">
                  Zoom In
                </Menubar.RadioItem>
                <Menubar.RadioItem className={itemClass} value="two">
                  Zoom Out
                </Menubar.RadioItem>
                <Menubar.Separator className={separatorClass} />
                <Menubar.RadioItem className={itemClass} value="three">
                  Actual Size
                </Menubar.RadioItem>
              </Menubar.RadioGroup>
              <Menubar.Arrow className="fill-[var(--gray-1)] dark:fill-[var(--gray-A3)]" />
            </Menubar.Content>
          </Menubar.Portal>
        </Menubar.Menu>
      </Menubar.Root>
    </div>
  )
}
