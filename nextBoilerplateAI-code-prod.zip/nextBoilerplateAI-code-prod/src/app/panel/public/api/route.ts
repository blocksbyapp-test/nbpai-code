export { GET, POST, dynamic } from '@/features/panel/server/public'
