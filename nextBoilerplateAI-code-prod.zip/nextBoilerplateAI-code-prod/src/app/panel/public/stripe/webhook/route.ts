import { createStripeWebhookRoute } from '@/features/core/server/routes/stripe/webhook/route'
import { panelStripeAdapters } from '@/features/panel/server/services/stripeDatabaseAdapters'

const { POST } = createStripeWebhookRoute(panelStripeAdapters)

export { POST }
