import { createStripeCheckoutRoute } from '@/features/core/server/routes/stripe/checkout/route'
import { panelStripeAdapters } from '@/features/panel/server/services/stripeDatabaseAdapters'

const { GET } = createStripeCheckoutRoute(panelStripeAdapters, 'panel')

export { GET }
