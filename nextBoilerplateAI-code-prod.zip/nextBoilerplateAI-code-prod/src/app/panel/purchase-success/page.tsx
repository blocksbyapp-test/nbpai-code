'use client'

import { PrivateApolloClient } from '@/features/core/client/components/ApolloWrapper'

import { useStripeCheckoutSessionDetailsQuery } from '@/features/panel/generated/types'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { Suspense } from 'react'
const panelPrivateApolloClient = new PrivateApolloClient('panel')

function PurchaseSuccessPageContent() {
  const searchParams = useSearchParams()
  const sessionId = searchParams.get('session_id')
  const { data: session } = useSession()
  const { data, loading, error } = useStripeCheckoutSessionDetailsQuery({
    client: panelPrivateApolloClient,
    variables: { sessionId: sessionId || '' },
    skip: !sessionId, // Skip query if no session ID
  })

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-900 text-white">
        <div className="mx-auto max-w-7xl px-4 py-6 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
            Processing your purchase...
          </h1>
          <p className="mt-4 text-lg text-gray-300">
            Please do not close this page.
          </p>
        </div>
      </div>
    )
  }

  if (error || !data?.stripeCheckoutSessionDetails) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-900 text-white">
        <div className="mx-auto max-w-7xl px-4 py-6 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold tracking-tight text-red-500 sm:text-5xl">
            Purchase Error!
          </h1>
          <p className="mt-4 text-lg text-gray-300">
            There was an issue confirming your purchase. Please contact support.
          </p>
          <div className="mt-8">
            <Link href="/panel">Go to Panel</Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-900 text-white">
      <div className="text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
          Purchase Successful!
        </h1>
        <p className="mt-4 text-lg text-gray-300">
          Thank you for your purchase. Your access has been granted.
        </p>
        <div className="mt-8">
          <Link href="/panel">Go to Panel</Link>
        </div>
      </div>
    </div>
  )
}

export default function PurchaseSuccessPage() {
  return (
    <Suspense fallback={<div>Loading purchase details...</div>}>
      <PurchaseSuccessPageContent />
    </Suspense>
  )
}
