'use client'
import { PanelPage } from '@/features/panel/client/pages/PanelPage'

export default () => <PanelPage />
