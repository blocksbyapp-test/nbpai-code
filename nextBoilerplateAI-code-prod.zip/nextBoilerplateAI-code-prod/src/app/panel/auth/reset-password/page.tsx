'use client'
import { PublicApolloClient } from '@/features/core/client/components/ApolloWrapper'
import { ResetPasswordPage } from '@/features/core/client/pages/auth/reset-password/ResetPasswordPage'
import {
  useResetPasswordMutation,
  useValidatePasswordResetTokenLazyQuery,
} from '@/features/panel/generated/public/types'
import { Suspense, useCallback } from 'react'

const panelAuthClient = new PublicApolloClient('panel')

export default () => {
  const [resetPasswordMutation, { loading: resetLoading, error: resetError }] =
    useResetPasswordMutation({
      client: panelAuthClient,
    })

  const [
    getValidationData,
    { loading: validationLoading, error: validationError },
  ] = useValidatePasswordResetTokenLazyQuery({
    client: panelAuthClient,
    fetchPolicy: 'network-only',
  })

  const handleValidateToken = useCallback(
    async (token: string) => {
      try {
        const { data } = await getValidationData({
          variables: { token },
        })
        return {
          isValid: data?.validatePasswordResetToken?.isValid,
          email: data?.validatePasswordResetToken?.email,
        }
      } catch (err) {
        console.error('Token validation error:', err)
        return { isValid: false }
      }
    },
    [getValidationData],
  )

  const handleSubmit = async (token: string, newPassword: string) => {
    try {
      const { data } = await resetPasswordMutation({
        variables: {
          input: { token, newPassword },
        },
      })
      if (data?.resetPassword?.success) {
        return undefined
      } else {
        return data?.resetPassword?.message || 'Failed to reset password.'
      }
    } catch (err: any) {
      console.error('Password reset mutation error:', err)
      return err.message || 'An unexpected error occurred.'
    }
  }

  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ResetPasswordPage
        onSubmit={handleSubmit}
        onValidateToken={handleValidateToken}
        loading={resetLoading || validationLoading}
        error={resetError?.message || validationError?.message}
        feature={'panel'}
      />
    </Suspense>
  )
}
