import { createVerifyCredentialsRoute } from '@/features/core/server/routes/auth/verify-credentials/route'
import { User } from '@/features/panel/server/models/User'

const { POST } = createVerifyCredentialsRoute(User)

export { POST }
