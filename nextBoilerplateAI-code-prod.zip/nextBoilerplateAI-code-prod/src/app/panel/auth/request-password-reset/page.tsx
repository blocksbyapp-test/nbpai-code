'use client'
import { PublicApolloClient } from '@/features/core/client/components/ApolloWrapper'
import { RequestPasswordResetPage } from '@/features/core/client/pages/auth/request-password-reset/RequestPasswordResetPage'
import { useRequestPasswordResetMutation } from '@/features/panel/generated/public/types'

const panelAuthClient = new PublicApolloClient('panel')

export default () => {
  const [requestReset, { loading, error }] = useRequestPasswordResetMutation({
    client: panelAuthClient,
  })

  const handleSubmit = async (email: string) => {
    try {
      await requestReset({
        variables: {
          input: { email },
        },
      })
    } catch (err) {
      console.error('Synchronous error during mutation call:', err)
    }
  }

  return (
    <RequestPasswordResetPage
      loading={loading}
      error={error}
      onSubmit={handleSubmit}
    />
  )
}
