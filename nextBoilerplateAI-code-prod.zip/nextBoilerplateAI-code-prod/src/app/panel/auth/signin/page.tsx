'use client'
import { PublicApolloClient } from '@/features/core/client/components/ApolloWrapper'
import { SignInPage } from '@/features/core/client/pages/signin/SignInPage'
import { useUserCreateOneMutation } from '@/features/panel/generated/public/types'
import { signIn } from 'next-auth/react'
import { useState } from 'react'

const panelAuthClient = new PublicApolloClient('panel')

export default () => {
  const [createUser, { loading: registerLoading, error: registerError }] =
    useUserCreateOneMutation({
      client: panelAuthClient,
    })

  const [localError, setLocalError] = useState<string | undefined>(undefined)

  const handleSignIn = async (email: string, password: string) => {
    setLocalError(undefined)
    const result = await signIn('credentials', {
      redirect: false,
      email,
      password,
    })

    if (result?.error) {
      setLocalError(
        result.error === 'CredentialsSignin'
          ? 'Incorrect credentials'
          : 'Something went wrong',
      )
    }
    return result?.error
  }

  const handleRegister = async (
    name: string,
    email: string,
    password: string,
  ) => {
    setLocalError(undefined)
    try {
      const { data } = await createUser({
        variables: {
          record: {
            name,
            email,
            password,
            authProvider: 'credentials',
          },
        },
      })

      if (data?.UserCreateOne?.record) {
        const signInError = await handleSignIn(email, password)
        return signInError
      } else {
        setLocalError('An unexpected error occurred during registration.')
        return 'An unexpected error occurred during registration.'
      }
    } catch (err: any) {
      if (err.message?.includes('duplicate key error')) {
        const msg = 'This email is already registered. Please sign in.'
        setLocalError(msg)
        return msg
      }
      setLocalError(
        'An unexpected error occurred during registration.' + err.message,
      )
      return err.message
    }
  }

  return (
    <SignInPage
      onSubmitSignIn={handleSignIn}
      onSubmitRegister={handleRegister}
      loading={registerLoading}
      error={localError || registerError?.message}
      feature="panel"
    />
  )
}
