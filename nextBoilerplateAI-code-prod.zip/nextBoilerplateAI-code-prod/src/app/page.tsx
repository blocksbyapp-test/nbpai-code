'use client'
import { LandingPage } from '@/features/my-feature/client/pages/LandingPage'

export default () => <LandingPage />
