import { getHandlers } from '@/features/core/server/services/auth'

export const { GET, POST } = await getHandlers()
