// export { GET, POST, dynamic } from '@/features/landing-page/server/public'
