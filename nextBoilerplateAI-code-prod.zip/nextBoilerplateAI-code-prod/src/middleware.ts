import { SUPPORTED_FEATURES, type SupportedFeature } from '@/features'
import { createAuthForFeature } from '@/features/core/server/services/auth'
import type { NextRequest } from 'next/server'
import { NextResponse } from 'next/server'

export default async function middleware(req: NextRequest) {
  const { pathname, origin } = req.nextUrl

  const seg1 = (pathname.split('/')[1] || '') as string
  const isSupported = (SUPPORTED_FEATURES as readonly string[]).includes(seg1)
  if (!isSupported) {
    return NextResponse.next()
  }

  if (
    pathname.startsWith(`/${seg1}/public`) ||
    pathname.startsWith(`/${seg1}/auth`)
  ) {
    return NextResponse.next()
  }

  if (
    process.env.NODE_ENV === 'development' &&
    process.env.API_KEY_LOCAL_GENERATION?.length &&
    process.env.API_KEY_LOCAL_GENERATION.length > 10
  ) {
    const authHeader = req.headers.get('authorization')
    const apiKey = `Bearer ${process.env.API_KEY_LOCAL_GENERATION}`
    const isLocal =
      origin.startsWith('http://127.0.0.1') ||
      origin.startsWith('http://localhost')

    if (authHeader === apiKey && isLocal) {
      return NextResponse.next()
    }
  }

  const { auth } = createAuthForFeature(seg1 as SupportedFeature)
  const session = await auth()
  if (!session) {
    return NextResponse.redirect(new URL('/' + seg1 + '/auth/signin', req.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|sitemap.xml|robots.txt).*)',
  ],
}
