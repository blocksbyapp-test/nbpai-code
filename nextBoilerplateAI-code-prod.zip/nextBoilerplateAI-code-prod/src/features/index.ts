export const SUPPORTED_FEATURES = ['panel', 'my-feature'] as const
export type SupportedFeature = (typeof SUPPORTED_FEATURES)[number]
