import * as Apollo from '@apollo/client'
import { gql } from '@apollo/client'
export type Maybe<T> = T | null
export type InputMaybe<T> = Maybe<T>
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K]
}
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]?: Maybe<T[SubKey]>
}
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]: Maybe<T[SubKey]>
}
export type MakeEmpty<
  T extends { [key: string]: unknown },
  K extends keyof T,
> = { [_ in K]?: never }
export type Incremental<T> =
  | T
  | {
      [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never
    }
const defaultOptions = {} as const
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string }
  String: { input: string; output: string }
  Boolean: { input: boolean; output: boolean }
  Int: { input: number; output: number }
  Float: { input: number; output: number }
  Date: { input: any; output: any }
  MongoID: { input: any; output: any }
}

export type CreateItem = {
  success: Scalars['Boolean']['output']
}

export type CreateItemInput = {
  name: Scalars['String']['input']
}

export type CreateOneItemInput = {
  createdAt?: InputMaybe<Scalars['Date']['input']>
  email?: InputMaybe<Scalars['String']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  status?: InputMaybe<Scalars['String']['input']>
  updatedAt?: InputMaybe<Scalars['Date']['input']>
}

export type CreateOneItemPayload = {
  record?: Maybe<Item>
  recordId?: Maybe<Scalars['MongoID']['output']>
}

export type ErrorInterface = {
  message?: Maybe<Scalars['String']['output']>
}

export type FilterFindManyItemInput = {
  AND?: InputMaybe<Array<FilterFindManyItemInput>>
  OR?: InputMaybe<Array<FilterFindManyItemInput>>
  _id?: InputMaybe<Scalars['MongoID']['input']>
  _operators?: InputMaybe<FilterFindManyItemOperatorsInput>
  createdAt?: InputMaybe<Scalars['Date']['input']>
  email?: InputMaybe<Scalars['String']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  status?: InputMaybe<Scalars['String']['input']>
  updatedAt?: InputMaybe<Scalars['Date']['input']>
}

export type FilterFindManyItemOperatorsInput = {
  _id?: InputMaybe<FilterFindManyItem_IdOperatorsInput>
}

export type FilterFindManyItem_IdOperatorsInput = {
  exists?: InputMaybe<Scalars['Boolean']['input']>
  gt?: InputMaybe<Scalars['MongoID']['input']>
  gte?: InputMaybe<Scalars['MongoID']['input']>
  in?: InputMaybe<Array<InputMaybe<Scalars['MongoID']['input']>>>
  lt?: InputMaybe<Scalars['MongoID']['input']>
  lte?: InputMaybe<Scalars['MongoID']['input']>
  ne?: InputMaybe<Scalars['MongoID']['input']>
  nin?: InputMaybe<Array<InputMaybe<Scalars['MongoID']['input']>>>
}

export type Item = {
  _id: Scalars['MongoID']['output']
  createdAt?: Maybe<Scalars['Date']['output']>
  email?: Maybe<Scalars['String']['output']>
  name?: Maybe<Scalars['String']['output']>
  status?: Maybe<Scalars['String']['output']>
  updatedAt?: Maybe<Scalars['Date']['output']>
}

export type Mutation = {
  ItemCreateOne?: Maybe<CreateOneItemPayload>
  ItemRemoveById?: Maybe<RemoveByIdItemPayload>
  ItemUpdateById?: Maybe<UpdateByIdItemPayload>
  example?: Maybe<CreateItem>
}

export type MutationItemCreateOneArgs = {
  record: CreateOneItemInput
}

export type MutationItemRemoveByIdArgs = {
  _id: Scalars['MongoID']['input']
}

export type MutationItemUpdateByIdArgs = {
  _id: Scalars['MongoID']['input']
  record: UpdateByIdItemInput
}

export type MutationExampleArgs = {
  input: CreateItemInput
}

export type Query = {
  ItemMany: Array<Item>
  example?: Maybe<Example>
  exampleTCTypeUsage?: Maybe<Item>
}

export type QueryItemManyArgs = {
  filter?: InputMaybe<FilterFindManyItemInput>
  limit?: InputMaybe<Scalars['Int']['input']>
  skip?: InputMaybe<Scalars['Int']['input']>
  sort?: InputMaybe<SortFindManyItemInput>
}

export type QueryExampleArgs = {
  id: Scalars['String']['input']
}

export type QueryExampleTcTypeUsageArgs = {
  id: Scalars['String']['input']
}

export type RemoveByIdItemPayload = {
  error?: Maybe<ErrorInterface>
  record?: Maybe<Item>
  recordId?: Maybe<Scalars['MongoID']['output']>
}

export enum SortFindManyItemInput {
  IdAsc = '_ID_ASC',
  IdDesc = '_ID_DESC',
}

export type UpdateByIdItemInput = {
  createdAt?: InputMaybe<Scalars['Date']['input']>
  email?: InputMaybe<Scalars['String']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  status?: InputMaybe<Scalars['String']['input']>
  updatedAt?: InputMaybe<Scalars['Date']['input']>
}

export type UpdateByIdItemPayload = {
  error?: Maybe<ErrorInterface>
  record?: Maybe<Item>
  recordId?: Maybe<Scalars['MongoID']['output']>
}

export type Example = {
  success: Scalars['Boolean']['output']
}

export type ItemCreateOneMutationVariables = Exact<{
  record: CreateOneItemInput
}>

export type ItemCreateOneMutation = {
  ItemCreateOne?: {
    recordId?: any | null
    record?: {
      name?: string | null
      email?: string | null
      status?: string | null
      _id: any
      createdAt?: any | null
      updatedAt?: any | null
    } | null
  } | null
}

export type ItemManyQueryVariables = Exact<{
  filter?: InputMaybe<FilterFindManyItemInput>
  skip?: InputMaybe<Scalars['Int']['input']>
  limit?: InputMaybe<Scalars['Int']['input']>
  sort?: InputMaybe<SortFindManyItemInput>
}>

export type ItemManyQuery = {
  ItemMany: Array<{
    name?: string | null
    email?: string | null
    status?: string | null
    _id: any
    createdAt?: any | null
    updatedAt?: any | null
  }>
}

export type ItemRemoveByIdMutationVariables = Exact<{
  _id: Scalars['MongoID']['input']
}>

export type ItemRemoveByIdMutation = {
  ItemRemoveById?: {
    recordId?: any | null
    record?: {
      name?: string | null
      email?: string | null
      status?: string | null
      _id: any
      createdAt?: any | null
      updatedAt?: any | null
    } | null
  } | null
}

export type ItemUpdateByIdMutationVariables = Exact<{
  _id: Scalars['MongoID']['input']
  record: UpdateByIdItemInput
}>

export type ItemUpdateByIdMutation = {
  ItemUpdateById?: {
    recordId?: any | null
    record?: {
      name?: string | null
      email?: string | null
      status?: string | null
      _id: any
      createdAt?: any | null
      updatedAt?: any | null
    } | null
  } | null
}

export type ExampleMutationVariables = Exact<{
  input: CreateItemInput
}>

export type ExampleMutation = { example?: { success: boolean } | null }

export type ExampleTcTypeUsageQueryVariables = Exact<{
  id: Scalars['String']['input']
}>

export type ExampleTcTypeUsageQuery = {
  exampleTCTypeUsage?: {
    name?: string | null
    email?: string | null
    status?: string | null
    _id: any
    createdAt?: any | null
    updatedAt?: any | null
  } | null
}

export const ItemCreateOneDocument = gql`
  mutation ItemCreateOne($record: CreateOneItemInput!) {
    ItemCreateOne(record: $record) {
      recordId
      record {
        name
        email
        status
        _id
        createdAt
        updatedAt
      }
    }
  }
`
export type ItemCreateOneMutationFn = Apollo.MutationFunction<
  ItemCreateOneMutation,
  ItemCreateOneMutationVariables
>
export function useItemCreateOneMutation(
  baseOptions?: Apollo.MutationHookOptions<
    ItemCreateOneMutation,
    ItemCreateOneMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    ItemCreateOneMutation,
    ItemCreateOneMutationVariables
  >(ItemCreateOneDocument, options)
}
export type ItemCreateOneMutationHookResult = ReturnType<
  typeof useItemCreateOneMutation
>
export type ItemCreateOneMutationResult =
  Apollo.MutationResult<ItemCreateOneMutation>
export type ItemCreateOneMutationOptions = Apollo.BaseMutationOptions<
  ItemCreateOneMutation,
  ItemCreateOneMutationVariables
>
export const ItemManyDocument = gql`
  query ItemMany(
    $filter: FilterFindManyItemInput
    $skip: Int
    $limit: Int
    $sort: SortFindManyItemInput
  ) {
    ItemMany(filter: $filter, skip: $skip, limit: $limit, sort: $sort) {
      name
      email
      status
      _id
      createdAt
      updatedAt
    }
  }
`
export function useItemManyQuery(
  baseOptions?: Apollo.QueryHookOptions<ItemManyQuery, ItemManyQueryVariables>,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<ItemManyQuery, ItemManyQueryVariables>(
    ItemManyDocument,
    options,
  )
}
export function useItemManyLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    ItemManyQuery,
    ItemManyQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<ItemManyQuery, ItemManyQueryVariables>(
    ItemManyDocument,
    options,
  )
}
export function useItemManySuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<ItemManyQuery, ItemManyQueryVariables>,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<ItemManyQuery, ItemManyQueryVariables>(
    ItemManyDocument,
    options,
  )
}
export type ItemManyQueryHookResult = ReturnType<typeof useItemManyQuery>
export type ItemManyLazyQueryHookResult = ReturnType<
  typeof useItemManyLazyQuery
>
export type ItemManySuspenseQueryHookResult = ReturnType<
  typeof useItemManySuspenseQuery
>
export type ItemManyQueryResult = Apollo.QueryResult<
  ItemManyQuery,
  ItemManyQueryVariables
>
export const ItemRemoveByIdDocument = gql`
  mutation ItemRemoveById($_id: MongoID!) {
    ItemRemoveById(_id: $_id) {
      recordId
      record {
        name
        email
        status
        _id
        createdAt
        updatedAt
      }
    }
  }
`
export type ItemRemoveByIdMutationFn = Apollo.MutationFunction<
  ItemRemoveByIdMutation,
  ItemRemoveByIdMutationVariables
>
export function useItemRemoveByIdMutation(
  baseOptions?: Apollo.MutationHookOptions<
    ItemRemoveByIdMutation,
    ItemRemoveByIdMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    ItemRemoveByIdMutation,
    ItemRemoveByIdMutationVariables
  >(ItemRemoveByIdDocument, options)
}
export type ItemRemoveByIdMutationHookResult = ReturnType<
  typeof useItemRemoveByIdMutation
>
export type ItemRemoveByIdMutationResult =
  Apollo.MutationResult<ItemRemoveByIdMutation>
export type ItemRemoveByIdMutationOptions = Apollo.BaseMutationOptions<
  ItemRemoveByIdMutation,
  ItemRemoveByIdMutationVariables
>
export const ItemUpdateByIdDocument = gql`
  mutation ItemUpdateById($_id: MongoID!, $record: UpdateByIdItemInput!) {
    ItemUpdateById(_id: $_id, record: $record) {
      recordId
      record {
        name
        email
        status
        _id
        createdAt
        updatedAt
      }
    }
  }
`
export type ItemUpdateByIdMutationFn = Apollo.MutationFunction<
  ItemUpdateByIdMutation,
  ItemUpdateByIdMutationVariables
>
export function useItemUpdateByIdMutation(
  baseOptions?: Apollo.MutationHookOptions<
    ItemUpdateByIdMutation,
    ItemUpdateByIdMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    ItemUpdateByIdMutation,
    ItemUpdateByIdMutationVariables
  >(ItemUpdateByIdDocument, options)
}
export type ItemUpdateByIdMutationHookResult = ReturnType<
  typeof useItemUpdateByIdMutation
>
export type ItemUpdateByIdMutationResult =
  Apollo.MutationResult<ItemUpdateByIdMutation>
export type ItemUpdateByIdMutationOptions = Apollo.BaseMutationOptions<
  ItemUpdateByIdMutation,
  ItemUpdateByIdMutationVariables
>
export const ExampleDocument = gql`
  mutation example($input: CreateItemInput!) {
    example(input: $input) {
      success
    }
  }
`
export type ExampleMutationFn = Apollo.MutationFunction<
  ExampleMutation,
  ExampleMutationVariables
>
export function useExampleMutation(
  baseOptions?: Apollo.MutationHookOptions<
    ExampleMutation,
    ExampleMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<ExampleMutation, ExampleMutationVariables>(
    ExampleDocument,
    options,
  )
}
export type ExampleMutationHookResult = ReturnType<typeof useExampleMutation>
export type ExampleMutationResult = Apollo.MutationResult<ExampleMutation>
export type ExampleMutationOptions = Apollo.BaseMutationOptions<
  ExampleMutation,
  ExampleMutationVariables
>
export const ExampleTcTypeUsageDocument = gql`
  query exampleTCTypeUsage($id: String!) {
    exampleTCTypeUsage(id: $id) {
      name
      email
      status
      _id
      createdAt
      updatedAt
    }
  }
`
export function useExampleTcTypeUsageQuery(
  baseOptions: Apollo.QueryHookOptions<
    ExampleTcTypeUsageQuery,
    ExampleTcTypeUsageQueryVariables
  > &
    (
      | { variables: ExampleTcTypeUsageQueryVariables; skip?: boolean }
      | { skip: boolean }
    ),
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<
    ExampleTcTypeUsageQuery,
    ExampleTcTypeUsageQueryVariables
  >(ExampleTcTypeUsageDocument, options)
}
export function useExampleTcTypeUsageLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    ExampleTcTypeUsageQuery,
    ExampleTcTypeUsageQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<
    ExampleTcTypeUsageQuery,
    ExampleTcTypeUsageQueryVariables
  >(ExampleTcTypeUsageDocument, options)
}
export function useExampleTcTypeUsageSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        ExampleTcTypeUsageQuery,
        ExampleTcTypeUsageQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    ExampleTcTypeUsageQuery,
    ExampleTcTypeUsageQueryVariables
  >(ExampleTcTypeUsageDocument, options)
}
export type ExampleTcTypeUsageQueryHookResult = ReturnType<
  typeof useExampleTcTypeUsageQuery
>
export type ExampleTcTypeUsageLazyQueryHookResult = ReturnType<
  typeof useExampleTcTypeUsageLazyQuery
>
export type ExampleTcTypeUsageSuspenseQueryHookResult = ReturnType<
  typeof useExampleTcTypeUsageSuspenseQuery
>
export type ExampleTcTypeUsageQueryResult = Apollo.QueryResult<
  ExampleTcTypeUsageQuery,
  ExampleTcTypeUsageQueryVariables
>
