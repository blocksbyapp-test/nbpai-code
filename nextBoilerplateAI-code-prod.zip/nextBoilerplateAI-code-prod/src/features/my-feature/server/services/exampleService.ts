export const exampleService = (value: string) => {
  return value + '_transformed'
}
