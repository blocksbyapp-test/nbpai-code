import { createMongooseModel } from '@/features/core/server/services/mongoose'
import mongoose from 'mongoose'

export const itemSchema = new mongoose.Schema(
  {
    name: String,
    email: String,
    status: { type: String, default: 'todo' },
  },
  {
    timestamps: true,
  },
)
export const { Item, ItemTC, ItemMutations, ItemQueries } = createMongooseModel(
  'my-feature',
  'Item',
  itemSchema,
)
