import type { Resolver } from '@/features/core/server/types/types'

import { Item } from '@/features/my-feature/server/models/Item'

export const exampleQuery: Resolver<any, any> = async (
  parent,
  args,
  context,
) => {
  try {
    const { id } = args
    const item = await Item.findOne({ _id: context.userId })

    return item
  } catch (err) {
    console.log({ err })
    throw err
  }
}
