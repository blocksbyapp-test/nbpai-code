import type { Resolver } from '@/features/core/server/types/types'

import { Item } from '@/features/my-feature/server/models/Item'
import { exampleService } from '@/features/my-feature/server/services/exampleService'

export const exampleMutation: Resolver<any, any> = async (
  parent,
  args,
  context,
) => {
  try {
    const { name } = args.input

    const item = new Item({
      name: exampleService(name),
    })
    await item.save()
    return { name }
  } catch (err) {
    console.log({ err })
    throw err
  }
}
