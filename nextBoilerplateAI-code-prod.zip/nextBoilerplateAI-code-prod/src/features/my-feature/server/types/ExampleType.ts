import {
  GraphQLBoolean,
  GraphQLInputObjectType,
  GraphQLNonNull,
  GraphQLObjectType,
  GraphQLString,
} from 'graphql'

export const ExampleType = new GraphQLObjectType({
  name: 'example',
  fields: {
    success: { type: new GraphQLNonNull(GraphQLBoolean) },
  },
})

export const CreateItemType = new GraphQLObjectType({
  name: 'CreateItem',
  fields: {
    success: { type: new GraphQLNonNull(GraphQLBoolean) },
  },
})

export const CreateItemInputType = new GraphQLInputObjectType({
  name: 'CreateItemInput',
  fields: {
    name: { type: new GraphQLNonNull(GraphQLString) },
  },
})
