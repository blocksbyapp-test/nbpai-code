import { createGraphqlServer } from '@/features/core/server/services/graphqlServer'

import {
  ItemMutations,
  ItemQueries,
  ItemTC,
} from '@/features/my-feature/server/models/Item'
import { exampleMutation } from '@/features/my-feature/server/resolvers/exampleMutation'
import { exampleQuery } from '@/features/my-feature/server/resolvers/exampleQuery'
import { exampleTCTypeUsage } from '@/features/my-feature/server/resolvers/exampleTCTypeUsage'
import {
  CreateItemInputType,
  CreateItemType,
  ExampleType,
} from '@/features/my-feature/server/types/ExampleType'
import { GraphQLNonNull, GraphQLString } from 'graphql'

const { POST, GET, dynamic } = createGraphqlServer({
  query: {
    ...ItemQueries(['ItemMany']),
    example: {
      type: ExampleType,
      args: {
        id: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: exampleQuery,
    },
    exampleTCTypeUsage: {
      type: ItemTC.getType(),
      args: {
        id: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: exampleTCTypeUsage,
    },
  },
  mutation: {
    ...ItemMutations(['ItemCreateOne', 'ItemRemoveById', 'ItemUpdateById']),
    example: {
      type: CreateItemType,
      args: {
        input: {
          type: new GraphQLNonNull(CreateItemInputType),
        },
      },
      resolve: exampleMutation,
    },
  },
  models: [ItemTC],
})

export { dynamic, GET, POST }
