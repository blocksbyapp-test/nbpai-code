'use client'
import { TodoList } from '@/features/my-feature/client/components/TodoList'
import { Button } from '@radix-ui/themes'
import { signOut, useSession } from 'next-auth/react'
import Link from 'next/link'

export const TodoPage = () => {
  const { data: session } = useSession()

  return (
    <section className="bg-gray-900 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex justify-center">
          <div className="w-full max-w-2xl">
            <figure className="mt-10 flex flex-auto flex-col justify-between">
              <blockquote className="text-lg/8 text-white">
                {session ? (
                  <div className="w-full rounded-lg bg-gray-800 p-8 shadow-md">
                    <h1 className="mb-6 text-center text-2xl font-bold text-white">
                      Welcome !!!!, {session.user?.name}
                    </h1>
                    <p className="text-center text-gray-400">
                      You are signed in as {session.user?.email}
                    </p>
                    <TodoList />
                    <div className="mt-4 flex justify-center gap-4">
                      <Link href="/">
                        <Button variant="soft">Home Page</Button>
                      </Link>
                      <Link href="/panel">
                        <Button variant="soft">Panel</Button>
                      </Link>
                      <Button onClick={() => signOut()} variant="soft">
                        Sign out
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="w-full rounded-lg bg-gray-800 p-8 shadow-md">
                    <h1 className="mb-6 text-center text-2xl font-bold text-white">
                      Not Signed In
                    </h1>
                    <p className="text-center text-gray-400">
                      Please sign in to view your session details.
                    </p>
                  </div>
                )}
              </blockquote>
            </figure>
          </div>
        </div>
      </div>
    </section>
  )
}
