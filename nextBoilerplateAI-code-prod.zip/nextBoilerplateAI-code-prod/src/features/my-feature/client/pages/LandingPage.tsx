'use client'

import * as Form from '@radix-ui/react-form'
import { CaretDownIcon } from '@radix-ui/react-icons'
import {
  Avatar,
  Box,
  Button,
  Card,
  DropdownMenu,
  Flex,
  Heading,
  ScrollArea,
  Text,
  TextField,
} from '@radix-ui/themes'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import React, { useEffect, useRef, useState } from 'react'

const DropdownTriggerWithIcon = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<typeof DropdownMenu.Trigger>
>(({ children, ...props }, forwardedRef) => (
  <DropdownMenu.Trigger>
    <Button variant="ghost" ref={forwardedRef} {...props}>
      {children}
      <CaretDownIcon />
    </Button>
  </DropdownMenu.Trigger>
))

DropdownTriggerWithIcon.displayName = 'DropdownTriggerWithIcon'

const testimonials = [
  {
    name: 'John Doe',
    title: 'CEO, Example Corp',
    quote:
      'This product has completely changed how we work. Highly recommended!',
    avatarFallback: 'JD',
  },
  {
    name: 'Alice Johnson',
    title: 'Lead Developer, Tech Solutions',
    quote:
      'Incredible features and easy to use. A must-have tool for any team.',
    avatarFallback: 'AJ',
  },
  {
    name: 'Bob Williams',
    title: 'Marketing Director, Innovate Ltd.',
    quote:
      'Our team productivity has soared since we started using this platform.',
    avatarFallback: 'BW',
  },
  {
    name: 'Charlie Brown',
    title: 'Freelance Designer',
    quote: 'Simple, powerful, and effective. Exactly what I needed.',
    avatarFallback: 'CB',
  },
  {
    name: 'Diana Miller',
    title: 'Product Manager, Global Solutions',
    quote:
      'The best investment we made this year. The support is also top-notch.',
    avatarFallback: 'DM',
  },
  {
    name: 'Ethan Davis',
    title: 'Startup Founder',
    quote:
      'Helped us scale quickly and efficiently. Highly recommend for startups.',
    avatarFallback: 'ED',
  },
  {
    name: 'Fiona Green',
    title: 'Educator, University',
    quote:
      'Makes complex tasks simple. A great tool for teaching and learning.',

    avatarFallback: 'FG',
  },
  {
    name: 'George White',
    title: 'Consultant, Business Advisors',
    quote:
      'Provides clear insights and streamlines processes. Essential for any business.',
    avatarFallback: 'GW',
  },
  {
    name: 'Hannah Black',
    title: 'Non-profit Coordinator',
    quote: 'Affordable and impactful. Allows us to focus on our mission.',
    avatarFallback: 'HB',
  },
  {
    name: 'Ivan Grey',
    title: 'Student, Tech Institute',
    quote:
      'User-friendly and packed with features. Great for personal projects.',
    avatarFallback: 'IG',
  },
]

export const LandingPage = () => {
  const [email, setEmail] = useState('')
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const [isPaused, setIsPaused] = useState(false)
  const router = useRouter()

  const handleEmailSignup = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    console.log('Email submitted:', email)
    alert(`Signed up with: ${email}`)
    setEmail('')
  }

  useEffect(() => {
    const scrollArea = scrollAreaRef.current
    if (!scrollArea) return

    const viewport = scrollArea.querySelector(
      '[data-radix-scroll-area-viewport]',
    )
    if (!viewport) return

    const cards = viewport.querySelectorAll('.testimonial-card')
    if (cards.length === 0) return

    let scrollAmount = 0
    if (cards.length > 1) {
      const firstCard = cards[0] as HTMLElement
      const secondCard = cards[1] as HTMLElement
      scrollAmount = secondCard.offsetLeft - firstCard.offsetLeft
    } else if (cards.length === 1) {
      scrollAmount = (cards[0] as HTMLElement).offsetWidth
    }

    if (scrollAmount === 0) return

    const scrollInterval = 5000

    const autoScroll = () => {
      if (isPaused) return

      const currentScrollLeft = viewport.scrollLeft
      const maxScrollLeft = viewport.scrollWidth - viewport.clientWidth

      let nextScrollLeft = currentScrollLeft + scrollAmount

      if (currentScrollLeft >= maxScrollLeft - 5) {
        nextScrollLeft = 0
      }

      viewport.scrollTo({
        left: nextScrollLeft,
        behavior: 'smooth',
      })
    }

    const intervalId = setInterval(autoScroll, scrollInterval)

    const pause = () => setIsPaused(true)
    const resume = () => setIsPaused(false)

    viewport.addEventListener('mouseenter', pause)
    viewport.addEventListener('mouseleave', resume)
    viewport.addEventListener('focusin', pause)
    viewport.addEventListener('focusout', resume)

    return () => {
      clearInterval(intervalId)
      viewport.removeEventListener('mouseenter', pause)
      viewport.removeEventListener('mouseleave', resume)
      viewport.removeEventListener('focusin', pause)
      viewport.removeEventListener('focusout', resume)
    }
  }, [isPaused])

  return (
    <Box className="min-h-screen bg-gray-900 text-white">
      {/* Nav Bar */}
      <Flex
        asChild
        justify="between"
        align="center"
        p="4"
        className="border-b border-gray-800"
      >
        <header>
          <Heading size="5">Company Name</Heading>
          <DropdownMenu.Root>
            <DropdownTriggerWithIcon>Menu</DropdownTriggerWithIcon>
            <DropdownMenu.Content>
              <DropdownMenu.Item>Home</DropdownMenu.Item>
              <DropdownMenu.Item>Features</DropdownMenu.Item>
              <DropdownMenu.Item>Pricing</DropdownMenu.Item>
              <DropdownMenu.Separator />
              <DropdownMenu.Item asChild>
                <Link href="/panel">Panel</Link>
              </DropdownMenu.Item>
              <DropdownMenu.Item asChild>
                <Link href="/my-feature">Todo List</Link>
              </DropdownMenu.Item>
              <DropdownMenu.Item>Sign In</DropdownMenu.Item>
            </DropdownMenu.Content>
          </DropdownMenu.Root>
        </header>
      </Flex>

      {/* Hero Section */}
      <Box className="container mx-auto px-6 py-20 text-center">
        <Heading size="9" mb="4">
          Revolutionize Your Workflow
        </Heading>
        <Text size="5" className="text-gray-400">
          Our platform helps you achieve more with less effort. Sign up today!
        </Text>
      </Box>

      {/* Email Signup Section */}
      <Box className="container mx-auto px-6 py-16 text-center">
        <Heading size="6" mb="4">
          Join Our Newsletter
        </Heading>
        <Form.Root
          onSubmit={handleEmailSignup}
          className="flex flex-col items-center gap-4"
        >
          <Form.Field name="email" className="w-full max-w-sm">
            <Form.Label className="sr-only">Email Address</Form.Label>
            <Form.Control asChild>
              <TextField.Root
                placeholder="Enter your email"
                size="3"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full"
              />
            </Form.Control>
          </Form.Field>
          <Form.Submit asChild>
            <Button size="3" variant="solid">
              Sign Up
            </Button>
          </Form.Submit>
        </Form.Root>
      </Box>

      {/* Testimonials Section */}
      <Box className="container mx-auto px-6 py-16">
        <Heading size="6" mb="8" className="text-center">
          What Our Users Say
        </Heading>
        <ScrollArea scrollbars="both" type="always" ref={scrollAreaRef}>
          <Flex gap="6" wrap="nowrap" justify="start" className="pb-4">
            {testimonials.map((testimonial, index) => (
              <Card
                key={index}
                className="testimonial-card w-full max-w-sm flex-none bg-gray-800 p-6"
              >
                <Flex gap="4" align="center" mb="4">
                  <Avatar
                    fallback={testimonial.avatarFallback}
                    radius="full"
                    size="4"
                  />
                  <Box>
                    <Text weight="bold">{testimonial.name}</Text>
                    <Text size="2" className="text-gray-400">
                      {testimonial.title}
                    </Text>
                  </Box>
                </Flex>
                <Text size="3" className="text-gray-300">
                  "{testimonial.quote}"
                </Text>
              </Card>
            ))}
          </Flex>
        </ScrollArea>
      </Box>

      {/* Footer Section */}
      <Flex
        asChild
        justify="center"
        align="center"
        p="6"
        className="border-t border-gray-800"
      >
        <footer>
          <Text size="2" className="text-gray-500">
            © 2023 Company Name. All rights reserved.
          </Text>
          <Flex gap="3" mt="3">
            <Button variant="soft" onClick={() => router.push('/')}>
              Homepage
            </Button>
            <Button variant="soft" onClick={() => router.push('/panel')}>
              User Panel
            </Button>
          </Flex>
        </footer>
      </Flex>
    </Box>
  )
}
