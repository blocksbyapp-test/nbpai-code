'use client'
import {
  useItemCreateOneMutation,
  useItemManyQuery,
  useItemRemoveByIdMutation,
  useItemUpdateByIdMutation,
} from '@/features/my-feature/generated/types'
import {
  draggable,
  dropTargetForElements,
} from '@atlaskit/pragmatic-drag-and-drop/element/adapter'
import { useSession } from 'next-auth/react'
import { useEffect, useRef, useState } from 'react'
import invariant from 'tiny-invariant'

interface TCard {
  id: string
  name: string
  status: string
}

interface TColumn {
  id: string
  title: string
  cards: TCard[]
}

const initialColumns: TColumn[] = [
  { id: 'todo', title: 'Todo', cards: [] },
  { id: 'inprogress', title: 'In Progress', cards: [] },
  { id: 'done', title: 'Done', cards: [] },
]

const getCardData = (card: TCard, columnId: string) => ({
  card,
  columnId,
})

const getColumnData = (column: TColumn) => ({
  columnId: column.id,
})

export const TodoList = () => {
  const { data: session } = useSession()
  const [newItemName, setNewItemName] = useState('')
  const { data, loading, error, refetch } = useItemManyQuery({
    variables: { filter: { email: session?.user?.email } },
    skip: !session?.user?.email,
  })
  const [createItem] = useItemCreateOneMutation()
  const [removeItem] = useItemRemoveByIdMutation()
  const [updateItem] = useItemUpdateByIdMutation()
  const [columns, setColumns] = useState<TColumn[]>(initialColumns)

  useEffect(() => {
    if (data?.ItemMany) {
      const newColumns = initialColumns.map((col) => ({ ...col, cards: [] }))

      data.ItemMany.forEach((item) => {
        if (item) {
          const card: TCard = {
            id: item._id,
            name: item.name || '',
            status: item.status || 'todo',
          }
          const targetColumn = newColumns.find((col) => col.id === card.status)
          if (targetColumn) {
            // @ts-ignore
            targetColumn.cards.push(card)
          } else {
            // @ts-ignore
            newColumns.find((col) => col.id === 'todo')?.cards.push(card)
          }
        }
      })
      setColumns(newColumns)
    }
  }, [data])

  const handleAddItem = async () => {
    if (!newItemName.trim() || !session?.user?.email) return
    await createItem({
      variables: {
        record: {
          name: newItemName,
          email: session.user.email,
          status: 'todo',
        },
      },
    })
    setNewItemName('')
    await refetch()
  }

  const handleDeleteItem = async (id: string) => {
    await removeItem({ variables: { _id: id } })
    await refetch()
  }

  const handleCardDrop = async (
    draggedCard: TCard,
    sourceColumnId: string,
    targetColumnId: string,
  ) => {
    setColumns((currentColumns) => {
      const newColumns = currentColumns.map((col) => ({
        ...col,
        cards: [...col.cards],
      }))

      const sourceColumn = newColumns.find((col) => col.id === sourceColumnId)
      const targetColumn = newColumns.find((col) => col.id === targetColumnId)

      if (!sourceColumn || !targetColumn || sourceColumnId === targetColumnId)
        return currentColumns

      const cardIndex = sourceColumn.cards.findIndex(
        (card) => card.id === draggedCard.id,
      )
      if (cardIndex === -1) return currentColumns

      sourceColumn.cards.splice(cardIndex, 1)

      targetColumn.cards.push({ ...draggedCard, status: targetColumnId })

      return newColumns
    })

    try {
      await updateItem({
        variables: {
          _id: draggedCard.id,
          record: {
            status: targetColumnId,
          },
        },
      })
    } catch (e) {
      console.error('Failed to update item status on backend', e)

      await refetch()
    }
  }

  const ColumnComponent = ({ column }: { column: TColumn }) => {
    const columnRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
      const columnElement = columnRef.current
      invariant(columnElement)

      return dropTargetForElements({
        element: columnElement,
        canDrop: ({ source }) => {
          return (
            source.data && 'card' in source.data && 'columnId' in source.data
          )
        },
        getData: () => getColumnData(column),
        onDrop: ({ source }) => {
          const draggedCardData = source.data as {
            card: TCard
            columnId: string
          }
          handleCardDrop(
            draggedCardData.card,
            draggedCardData.columnId,
            column.id,
          )
        },
      })
    }, [column, handleCardDrop])

    return (
      <div
        ref={columnRef}
        className="flex w-64 flex-shrink-0 flex-col rounded bg-gray-700 p-4"
      >
        <h2 className="mb-2 text-lg font-bold text-white">{column.title}</h2>
        <div className="flex flex-col gap-2 overflow-y-auto">
          {column.cards.map((card) => (
            <CardComponent
              key={card.id}
              card={card}
              columnId={column.id}
              onDelete={handleDeleteItem}
            />
          ))}
        </div>
        {/* Add card button - currently not implemented to add cards to specific columns */}
        {/* <button
          type="button"
          className="flex flex-grow flex-row gap-1 rounded p-2 hover:bg-slate-700 active:bg-slate-600 text-white mt-2"
        >
          <Plus size={16} />
          <div className="leading-4">Add a card</div>
        </button> */}
      </div>
    )
  }

  const CardComponent = ({
    card,
    columnId,
    onDelete,
  }: {
    card: TCard
    columnId: string
    onDelete: (id: string) => void
  }) => {
    const cardRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
      const cardElement = cardRef.current
      invariant(cardElement)

      return draggable({
        element: cardElement,
        getInitialData: () => getCardData(card, columnId),
      })
    }, [card, columnId])

    return (
      <div
        ref={cardRef}
        className="flex cursor-grab flex-col items-center justify-between rounded bg-gray-800 p-2 text-white"
      >
        <span>{card.name}</span>
        <button
          onClick={() => onDelete(card.id)}
          className="text-sm text-red-500 hover:text-red-600"
        >
          Delete
        </button>
      </div>
    )
  }

  if (loading) return <div className="text-white">Loading...</div>
  if (error) return <div className="text-white">Error: {error.message}</div>

  return (
    <div className="flex flex-col gap-4 p-4">
      <div className="flex items-center justify-start">
        <input
          type="text"
          value={newItemName}
          onChange={(e) => setNewItemName(e.target.value)}
          className="mr-2 rounded-md border bg-gray-700 p-2 text-white focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Add a new item"
        />
        <button
          onClick={handleAddItem}
          className="rounded-md bg-blue-500 p-2 text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
        >
          Add
        </button>
      </div>
      <div className="flex flex-row gap-4 overflow-x-auto p-4">
        {columns.map((column) => (
          <ColumnComponent key={column.id} column={column} />
        ))}
      </div>
    </div>
  )
}
