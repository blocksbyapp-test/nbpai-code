'use client'

import { useCancelAccountDeletionMutation } from '@/features/panel/generated/types'
import { AlertDialog, Button, Flex, Text } from '@radix-ui/themes'
import { signOut } from 'next-auth/react'
import { useRouter } from 'next/navigation'

interface DeletionConfirmationModalProps {
  requestedDeletionAt: string
  onClose: () => void
}

export function DeletionConfirmationModal({
  requestedDeletionAt,
  onClose,
}: DeletionConfirmationModalProps) {
  const router = useRouter()
  const [cancelDeletion, { loading, error }] = useCancelAccountDeletionMutation(
    {
      onCompleted: (data) => {
        if (data.cancelAccountDeletion?.success) {
          onClose() // Close modal on success
          router.refresh() // Refresh session/page to reflect changes
        } else {
          console.error(
            'Failed to cancel deletion:',
            data.cancelAccountDeletion?.message,
          )
        }
      },
      onError: (err) => {
        console.error('Error cancelling deletion:', err)
      },
    },
  )

  const deletionDate = new Date(
    new Date(requestedDeletionAt).getTime() + 7 * 24 * 60 * 60 * 1000,
  )
  const formattedDeletionDate = deletionDate.toLocaleDateString()

  const handleCancel = () => {
    cancelDeletion()
  }

  const handleSignOut = () => {
    signOut()
  }

  return (
    <AlertDialog.Root open={true}>
      <AlertDialog.Content style={{ maxWidth: 450 }}>
        <AlertDialog.Title>Account Flagged for Deletion</AlertDialog.Title>
        <AlertDialog.Description size="2">
          Your account has been flagged for deletion and will be permanently
          deleted on <strong>{formattedDeletionDate}</strong>. If you wish to
          continue using your account, please cancel the deletion.
        </AlertDialog.Description>

        {error && (
          <Text color="red" size="2" mt="2">
            Error: {error.message}
          </Text>
        )}

        <Flex gap="3" mt="4" justify="end">
          <AlertDialog.Cancel>
            <Button variant="soft" color="gray" onClick={handleSignOut}>
              Sign out
            </Button>
          </AlertDialog.Cancel>
          <AlertDialog.Action>
            <Button
              variant="solid"
              color="indigo"
              onClick={handleCancel}
              disabled={loading}
            >
              {loading ? 'Cancelling...' : 'Cancel Deletion'}
            </Button>
          </AlertDialog.Action>
        </Flex>
      </AlertDialog.Content>
    </AlertDialog.Root>
  )
}
