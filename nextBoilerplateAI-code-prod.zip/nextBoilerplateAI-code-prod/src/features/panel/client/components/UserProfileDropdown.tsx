import { PersonIcon as UserCircleIcon } from '@radix-ui/react-icons'
import { DropdownMenu, IconButton } from '@radix-ui/themes'
import { Session } from 'next-auth'
import { NavItem } from '../types'
import { classNames } from './utility'

interface UserProfileDropdownProps {
  session: Session | null
  userNavigation: NavItem[]
  onNavigate: (id: string) => void
}

export function UserProfileDropdown({
  session,
  userNavigation,
  onNavigate,
}: UserProfileDropdownProps) {
  return (
    <DropdownMenu.Root>
      <DropdownMenu.Trigger>
        <IconButton
          variant="ghost"
          className="relative flex max-w-xs items-center rounded-full focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500"
        >
          <span className="absolute -inset-1.5" />
          <span className="sr-only">Open user menu</span>
          {session?.user?.image ? (
            <img
              alt=""
              src={session.user.image}
              className="size-8 rounded-full outline outline-1 -outline-offset-1 outline-white/10"
            />
          ) : (
            <UserCircleIcon className="size-8 text-gray-300" />
          )}
        </IconButton>
      </DropdownMenu.Trigger>

      <DropdownMenu.Content
        sideOffset={5}
        align="end"
        className="w-48 origin-top-right rounded-md bg-white py-1 shadow-lg outline outline-1 outline-black/5"
      >
        <div className="px-4 py-2 text-sm text-gray-700">
          <div className="font-medium text-gray-900">
            {session?.user?.name || 'User'}
          </div>
          <div className="text-gray-500">
            {session?.user?.email || 'No Email'}
          </div>
        </div>
        <DropdownMenu.Separator className="my-1 h-px bg-gray-100" />

        {userNavigation.map((item) => (
          <DropdownMenu.Item
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={classNames(
              'block w-full px-4 py-2 text-left text-sm text-gray-700',
            )}
          >
            {item.name}
          </DropdownMenu.Item>
        ))}
      </DropdownMenu.Content>
    </DropdownMenu.Root>
  )
}
