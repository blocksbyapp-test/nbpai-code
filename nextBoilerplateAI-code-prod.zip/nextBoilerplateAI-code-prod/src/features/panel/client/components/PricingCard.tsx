'use client'

import { Maybe, StripeCoupon } from '@/features/panel/generated/types'
import clsx from 'clsx'
import { BoltIcon } from 'lucide-react'
import React from 'react'
import { useFormStatus } from 'react-dom'

interface FeatureItemProps {
  description: string
  disabled?: boolean
  Icon?: React.ComponentType<React.ComponentPropsWithoutRef<'svg'>>
  strong?: boolean
}

function FeatureItem({
  description,
  disabled = false,
  Icon = BoltIcon,
  strong = false,
}: FeatureItemProps) {
  return (
    <li
      data-disabled={disabled ? true : undefined}
      className="flex items-start gap-4 text-sm/6 text-gray-950/75 data-[disabled]:text-gray-950/25"
    >
      <span className="inline-flex h-6 items-center">
        <Icon
          className={
            'size-[0.9375rem] shrink-0 ' +
            (disabled ? 'fill-gray-950/25' : 'fill-gray-950/75')
          }
        />
      </span>
      {disabled && <span className="sr-only">Not included:</span>}
      {strong ? (
        <strong className="font-semibold">{description}</strong>
      ) : (
        description
      )}
    </li>
  )
}

interface PricingCardProps {
  name: string
  price: number | null
  interval: string | null
  trialDays: number | null
  priceId?: string | null
  checkoutAction: (formData: FormData) => Promise<void>
  actionState: { url?: string | null; error?: unknown; success?: string }
  isOwned?: boolean
  isSubscription?: boolean
  activeCoupon?: Maybe<StripeCoupon>
  displayPrice?: number | null
  originalPrice?: number | null
  couponName?: string | null
  discountBadgeText?: string | null
  marketingTier?: {
    subheader1line: string
    subheader2line: string
    highlights: FeatureItemProps[]
    description: string
    name: string
  }
  subheaderClassName?: string
}

export function PricingCard({
  name,
  price,
  interval,
  trialDays,
  priceId,
  checkoutAction,
  actionState,
  isOwned = false,
  isSubscription = false,
  activeCoupon,
  displayPrice,
  originalPrice,
  couponName,
  discountBadgeText,
  marketingTier,
  subheaderClassName,
}: PricingCardProps) {
  const { pending } = useFormStatus()

  const finalDisplayPrice = displayPrice !== undefined ? displayPrice : price
  const showOriginalPrice =
    !!activeCoupon &&
    originalPrice !== null &&
    originalPrice !== finalDisplayPrice

  const cardName = marketingTier?.name || name
  const cardDescription = marketingTier?.description || ''
  const cardHighlights = marketingTier?.highlights || []
  const cardSubheader1 = marketingTier?.subheader1line || ''
  const cardSubheader2 = marketingTier?.subheader2line || ''

  return (
    <div className="flex flex-col rounded-lg border border-gray-200 bg-white p-8 shadow-lg">
      <h2 className="mb-2 text-2xl font-medium text-gray-900">{cardName}</h2>
      {/*<p className="mt-2 max-w-xs text-sm/6 text-gray-950/75">
        {cardDescription}
      </p>*/}
      {trialDays !== null && (
        <p className="mb-4 text-sm text-gray-600">
          with {trialDays} day free trial
        </p>
      )}
      <div className="mb-6 flex flex-col items-center">
        {discountBadgeText && (
          <span className="mb-2 inline-flex items-center rounded-md bg-green-50 px-2 py-1 text-xs font-medium text-green-700 ring-1 ring-inset ring-green-600/20">
            {discountBadgeText} {couponName && `(${couponName})`}
          </span>
        )}
        <p className="flex items-baseline text-4xl font-medium text-gray-900">
          {showOriginalPrice && (
            <span className="mr-2 text-xl font-semibold tracking-tight text-gray-400 line-through">
              ${(originalPrice! / 100).toFixed(0)}
            </span>
          )}
          {finalDisplayPrice !== null
            ? `$${(finalDisplayPrice / 100).toFixed(0)}`
            : 'Custom'}
          {interval && (
            <span className="text-xl font-normal text-gray-600">
              {' '}
              per user / {interval}
            </span>
          )}
        </p>
      </div>

      <div className="mt-2 flex items-center gap-x-4">
        <h4
          className={clsx(
            'pb-2 text-sm/6 font-semibold',
            subheaderClassName || 'text-indigo-400',
          )}
        >
          {cardSubheader1}
          <br />
          {cardSubheader2}
        </h4>
        <div className="h-px flex-auto bg-white/10" />
      </div>

      <ul className="mb-8 flex-grow space-y-4">
        {cardHighlights.length > 0 &&
          cardHighlights.map((highlight, index) => (
            <FeatureItem key={index} {...highlight} />
          ))}
        {/* If you want a fallback list, you can add it here */}
      </ul>

      {priceId && (
        <form action={checkoutAction} className="mt-auto">
          <input type="hidden" name="priceId" value={priceId} />
          {activeCoupon && (
            <input
              type="hidden"
              name="couponId"
              value={activeCoupon.id || ''}
            />
          )}
          <button
            type="submit"
            disabled={pending || !!actionState.url || isOwned}
            className={
              'w-full rounded-md py-2 text-sm font-semibold text-gray-900 shadow-sm ' +
              (isOwned
                ? 'cursor-not-allowed bg-green-500 text-white'
                : 'bg-indigo-600 text-white hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600')
            }
          >
            {isOwned
              ? isSubscription
                ? 'Current Plan'
                : 'Owned'
              : pending
                ? 'Loading...'
                : 'Get Started'}
          </button>
        </form>
      )}
    </div>
  )
}
