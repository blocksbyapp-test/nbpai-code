'use client'

import {
  useChangePasswordMutation,
  useRequestAccountDeletionMutation,
} from '@/features/panel/generated/types'
import { signOut, useSession } from 'next-auth/react'
import { useState } from 'react'

export function SettingsView() {
  const { data: session } = useSession()

  const dummyFirstName = session?.user?.name?.split(' ')[0] || 'User'

  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordChangeError, setPasswordChangeError] = useState('')
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState('')

  const [deletionRequestMessage, setDeletionRequestMessage] = useState('')
  const [deletionRequestError, setDeletionRequestError] = useState('')

  const [changePasswordMutation, { loading: changePasswordLoading }] =
    useChangePasswordMutation({
      onCompleted: (data) => {
        if (data.changePassword?.success) {
          setPasswordChangeSuccess(
            data.changePassword.message || 'Password changed successfully!',
          )
          setPasswordChangeError('')
          setCurrentPassword('')
          setNewPassword('')
          setConfirmPassword('')
        } else {
          setPasswordChangeError(
            data.changePassword?.message || 'Failed to change password.',
          )
          setPasswordChangeSuccess('')
        }
      },
      onError: (error) => {
        setPasswordChangeError(error.message || 'An unexpected error occurred.')
        setPasswordChangeSuccess('')
      },
    })

  const [requestAccountDeletionMutation, { loading: requestDeletionLoading }] =
    useRequestAccountDeletionMutation({
      onCompleted: (data) => {
        if (data.requestAccountDeletion?.success) {
          setDeletionRequestMessage(
            data.requestAccountDeletion.message ||
              'Account flagged for deletion.',
          )
          setDeletionRequestError('')
          signOut() // Sign out user after successful deletion request
        } else {
          setDeletionRequestError(
            data.requestAccountDeletion?.message ||
              'Failed to flag account for deletion.',
          )
          setDeletionRequestMessage('')
        }
      },
      onError: (error) => {
        setDeletionRequestError(
          error.message || 'An unexpected error occurred.',
        )
        setDeletionRequestMessage('')
      },
    })

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setPasswordChangeError('')
    setPasswordChangeSuccess('')

    if (newPassword !== confirmPassword) {
      setPasswordChangeError('New password and confirm password do not match.')
      return
    }
    if (!newPassword || newPassword.length < 6) {
      setPasswordChangeError('New password must be at least 6 characters long.')
      return
    }

    await changePasswordMutation({
      variables: {
        currentPassword,
        newPassword,
        confirmPassword,
      },
    })
  }

  const handleRequestDeletion = async () => {
    setDeletionRequestMessage('')
    setDeletionRequestError('')
    await requestAccountDeletionMutation()
  }

  const isCredentialsProvider = session?.user?.provider === 'credentials'

  return (
    <div className="rounded-lg bg-gray-900 p-4 shadow">
      <h2 className="text-xl font-semibold text-white">Settings</h2>
      <p className="mt-2 text-gray-400">
        Configure application settings and preferences.
      </p>

      <div className="mt-8 divide-y divide-white/10">
        <div className="grid max-w-7xl grid-cols-1 gap-x-8 gap-y-10 px-4 py-16 sm:px-6 md:grid-cols-3 lg:px-8">
          <div>
            <h2 className="text-base/7 font-semibold text-white">
              Personal Information
            </h2>
            <p className="mt-1 text-sm/6 text-gray-400">
              Manage your personal details.
            </p>
          </div>

          <form className="md:col-span-2">
            <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:max-w-xl sm:grid-cols-6">
              <div className="sm:col-span-3">
                <label
                  htmlFor="first-name"
                  className="block text-sm/6 font-medium text-white"
                >
                  First name
                </label>
                <div className="mt-2">
                  <input
                    id="first-name"
                    name="first-name"
                    type="text"
                    autoComplete="given-name"
                    value={dummyFirstName}
                    readOnly
                    className="block w-full rounded-md bg-gray-700/30 px-3 py-1.5 text-base text-gray-400 outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 sm:text-sm/6"
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label
                  htmlFor="auth-provider"
                  className="block text-sm/6 font-medium text-white"
                >
                  Authentication Provider
                </label>
                <div className="mt-2">
                  <input
                    id="auth-provider"
                    name="auth-provider"
                    type="text"
                    value={session?.user?.provider || 'Unknown'}
                    readOnly
                    className="block w-full rounded-md bg-gray-700/30 px-3 py-1.5 text-base text-gray-400 outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 sm:text-sm/6"
                  />
                </div>
              </div>

              <div className="col-span-full">
                <label
                  htmlFor="email"
                  className="block text-sm/6 font-medium text-white"
                >
                  Email address
                </label>
                <div className="mt-2">
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={session?.user?.email || ''}
                    readOnly
                    className="block w-full rounded-md bg-gray-700/30 px-3 py-1.5 text-base text-gray-400 outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 sm:text-sm/6"
                  />
                </div>
              </div>
            </div>

            <div className="mt-8 flex">
              <button
                type="submit"
                disabled
                className="rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50"
              >
                Save
              </button>
            </div>
          </form>
        </div>

        {isCredentialsProvider && (
          <div className="grid max-w-7xl grid-cols-1 gap-x-8 gap-y-10 px-4 py-16 sm:px-6 md:grid-cols-3 lg:px-8">
            <div>
              <h2 className="text-base/7 font-semibold text-white">
                Change password
              </h2>
              <p className="mt-1 text-sm/6 text-gray-400">
                Update your password associated with your account.
              </p>
            </div>

            <form onSubmit={handleChangePassword} className="md:col-span-2">
              <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:max-w-xl sm:grid-cols-6">
                <div className="col-span-full">
                  <label
                    htmlFor="current-password"
                    className="block text-sm/6 font-medium text-white"
                  >
                    Current password
                  </label>
                  <div className="mt-2">
                    <input
                      id="current-password"
                      name="current_password"
                      type="password"
                      autoComplete="current-password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      required
                      className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                    />
                  </div>
                </div>

                <div className="col-span-full">
                  <label
                    htmlFor="new-password"
                    className="block text-sm/6 font-medium text-white"
                  >
                    New password
                  </label>
                  <div className="mt-2">
                    <input
                      id="new-password"
                      name="new_password"
                      type="password"
                      autoComplete="new-password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      required
                      className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                    />
                  </div>
                </div>

                <div className="col-span-full">
                  <label
                    htmlFor="confirm-password"
                    className="block text-sm/6 font-medium text-white"
                  >
                    Confirm password
                  </label>
                  <div className="mt-2">
                    <input
                      id="confirm-password"
                      name="confirm_password"
                      type="password"
                      autoComplete="new-password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                      className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-8 flex">
                <button
                  type="submit"
                  disabled={changePasswordLoading}
                  className="rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {changePasswordLoading ? 'Saving...' : 'Save'}
                </button>
              </div>
              {passwordChangeError && (
                <p className="mt-4 text-sm text-red-400">
                  {passwordChangeError}
                </p>
              )}
              {passwordChangeSuccess && (
                <p className="mt-4 text-sm text-green-400">
                  {passwordChangeSuccess}
                </p>
              )}
            </form>
          </div>
        )}

        <div className="grid max-w-7xl grid-cols-1 gap-x-8 gap-y-10 px-4 py-16 sm:px-6 md:grid-cols-3 lg:px-8">
          <div>
            <h2 className="text-base/7 font-semibold text-white">
              Delete account
            </h2>
            <p className="mt-1 text-sm/6 text-gray-400">
              No longer want to use our service? You can delete your account
              here. This action is not reversible. All information related to
              this account will be deleted permanently.
            </p>
          </div>

          <form className="flex items-start md:col-span-2">
            <button
              type="button"
              onClick={handleRequestDeletion}
              disabled={requestDeletionLoading}
              className="rounded-md bg-red-500 px-3 py-2 text-sm font-semibold text-white hover:bg-red-400 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {requestDeletionLoading
                ? 'Requesting...'
                : 'Request Account Deletion'}
            </button>
          </form>
        </div>
        {deletionRequestMessage && (
          <p className="mt-4 text-center text-sm text-green-400">
            {deletionRequestMessage}
          </p>
        )}
        {deletionRequestError && (
          <p className="mt-4 text-center text-sm text-red-400">
            {deletionRequestError}
          </p>
        )}
      </div>
    </div>
  )
}
