'use client'

export function YourProfileView() {
  return (
    <div className="rounded-lg bg-gray-900 p-4 shadow">
      <h2 className="text-xl font-semibold text-white">Your Profile</h2>
      <p className="mt-2 text-gray-400">
        Manage your personal profile settings and information.
      </p>
    </div>
  )
}
