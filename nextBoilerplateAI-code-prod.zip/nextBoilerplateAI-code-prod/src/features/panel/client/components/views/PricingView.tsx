'use client'

import { PricingCard } from '@/features/panel/client/components/PricingCard'
import {
  useCreateCheckoutSessionMutation,
  useCurrentUserPurchasedProductIdsQuery,
  useCurrentUserStripeSubscriptionIdQuery,
  useCurrentUserSubscriptionStatusQuery,
  useStripeCouponsQuery,
  useStripePricesQuery,
  useStripeProductsQuery,
} from '@/features/panel/generated/types'
import { BoltIcon } from 'lucide-react'
import { useEffect } from 'react'

export function PricingView() {
  const { data: couponsData } = useStripeCouponsQuery()

  const {
    data: pricesData,
    loading: pricesLoading,
    error: pricesError,
  } = useStripePricesQuery()
  const {
    data: productsData,
    loading: productsLoading,
    error: productsError,
  } = useStripeProductsQuery()

  const {
    data: currentUserStripeSubscriptionIdData,
    loading: currentUserStripeSubscriptionIdLoading,
    error: currentUserStripeSubscriptionIdError,
  } = useCurrentUserStripeSubscriptionIdQuery({ fetchPolicy: 'network-only' })

  const {
    data: currentUserSubscriptionStatusData,
    loading: currentUserSubscriptionStatusLoading,
    error: currentUserSubscriptionStatusError,
  } = useCurrentUserSubscriptionStatusQuery({ fetchPolicy: 'network-only' })

  const {
    data: currentUserPurchasedProductsData,
    loading: currentUserPurchasedProductsLoading,
    error: currentUserPurchasedProductsError,
  } = useCurrentUserPurchasedProductIdsQuery({ fetchPolicy: 'network-only' })

  const [
    createCheckoutSession,
    { data: checkoutData, loading: checkoutLoading, error: checkoutError },
  ] = useCreateCheckoutSessionMutation()

  useEffect(() => {
    if (checkoutData?.createCheckoutSession?.url) {
      window.location.assign(checkoutData.createCheckoutSession.url)
    }
  }, [checkoutData])

  const handleCheckoutAction = async (formData: FormData) => {
    const priceId = formData.get('priceId') as string
    const couponId = formData.get('couponId') as string | undefined
    if (!priceId) return

    await createCheckoutSession({
      variables: {
        priceId,
        couponId,
      },
    })
  }

  const isLoading =
    pricesLoading ||
    productsLoading ||
    checkoutLoading ||
    currentUserStripeSubscriptionIdLoading ||
    currentUserSubscriptionStatusLoading ||
    currentUserPurchasedProductsLoading

  const isError =
    pricesError ||
    productsError ||
    checkoutError ||
    currentUserStripeSubscriptionIdError ||
    currentUserSubscriptionStatusError ||
    currentUserPurchasedProductsError

  if (isLoading) {
    return (
      <div className="bg-gray-900 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-3 lg:px-4">
          <div className="mx-auto max-w-4xl sm:text-center">
            <h2 className="text-pretty text-5xl font-semibold tracking-tight text-white sm:text-balance sm:text-6xl">
              Loading plans...
            </h2>
          </div>
        </div>
      </div>
    )
  }

  if (isError) {
    return (
      <div className="bg-gray-900 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-3 lg:px-4">
          <div className="mx-auto max-w-4xl sm:text-center">
            <h2 className="text-pretty text-5xl font-semibold tracking-tight text-red-500 sm:text-balance sm:text-6xl">
              Error loading pricing plans.
            </h2>
          </div>
        </div>
      </div>
    )
  }

  const currentUserStripeSubscriptionId =
    currentUserStripeSubscriptionIdData?.currentUserStripeSubscriptionId
  const currentUserSubscriptionStatus =
    currentUserSubscriptionStatusData?.currentUserSubscriptionStatus
  const purchasedProducts =
    currentUserPurchasedProductsData?.currentUserPurchasedProductIds || []

  const hasAnyPurchasedProduct = purchasedProducts.length > 0

  const activeCoupon = couponsData?.stripeCoupons?.[0]

  // Keep your minimal, “styled” highlights
  const commonHighlights = [
    { description: 'Generic Feature 1', Icon: BoltIcon, strong: true },
    { description: 'Generic Feature 2', Icon: BoltIcon },
    { description: 'Generic Feature 3', Icon: BoltIcon },
    { description: 'Generic Feature 4', Icon: BoltIcon },
  ]

  // ✅ Build marketing tiers **from Stripe products**, not static ids
  const marketingTiers =
    productsData?.stripeProducts?.map((product) => {
      const highlights = [...commonHighlights]
      const howToGetStarted: { title: string; description: string }[] = [
        {
          title: '1. Select Your Plan',
          description: `Choose the ${product.name ?? 'plan'} that fits your needs.`,
        },
        {
          title: '2. Get Started',
          description: 'Access your features and start building.',
        },
      ]

      // Optional: mirror your working logic for specific product/coupon tweaks
      if (activeCoupon?.id === 'JUnoZjdt') {
        // Example tweak: if you want a plan to show shorter updates under that coupon,
        // you can conditionally adjust highlights for a specific product id.
        // (Leave as-is if not needed in this variant.)
      }

      return {
        id: product.id,
        name: product.name ?? '',
        description: product.description ?? 'A simple plan for basic needs.',
        subheader1line: 'All Features:',
        subheader2line: '',
        highlights,
        howToGetStarted,
      }
    }) || []

  // Optional: stable ordering by name
  marketingTiers.sort((a, b) => (a.name ?? '').localeCompare(b.name ?? ''))

  return (
    <div id="pricing-section" className="bg-gray-900 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-3 lg:px-4">
        <div className="mx-auto max-w-4xl sm:text-center">
          <h2 className="text-pretty text-5xl font-semibold tracking-tight text-white sm:text-balance sm:text-6xl">
            {hasAnyPurchasedProduct
              ? 'Manage your access to features'
              : 'Unlock your access to features'}
          </h2>
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg font-medium text-gray-400 sm:text-xl/8">
            Choose the package that best suits your needs.
          </p>
        </div>

        <div className="mt-16 space-y-16 sm:mt-20 lg:space-y-20">
          {marketingTiers.map((marketingTier) => {
            const product = productsData?.stripeProducts?.find(
              (p) => p.id === marketingTier.id,
            )
            const price = pricesData?.stripePrices?.find(
              (p) => p.productId === product?.id,
            )

            let isOwned = false
            const isSubscription = !!price?.interval

            if (isSubscription) {
              if (
                currentUserStripeSubscriptionId === product?.id &&
                (currentUserSubscriptionStatus === 'active' ||
                  currentUserSubscriptionStatus === 'trialing')
              ) {
                isOwned = true
              }
            } else {
              if (
                product?.id &&
                purchasedProducts.some((p) => p?.productId === product.id)
              ) {
                isOwned = true
              }
            }

            let displayPrice: number | null = price?.unitAmount ?? null
            const originalPrice = price?.unitAmount ?? null
            let discountBadgeText: string | null = null
            let couponName: string | null = null

            if (activeCoupon && price?.unitAmount !== null) {
              if (activeCoupon.percentOff) {
                displayPrice =
                  (price?.unitAmount || 0) * (1 - activeCoupon.percentOff / 100)
                discountBadgeText = `${activeCoupon.percentOff}% OFF`
              } else if (activeCoupon.amountOff) {
                displayPrice = (price?.unitAmount || 0) - activeCoupon.amountOff
                discountBadgeText = `$${(activeCoupon.amountOff / 100).toFixed(0)} OFF`
              }
              displayPrice = Math.max(0, Math.round(displayPrice ?? 0))
              couponName = activeCoupon.name || null
            }

            return (
              <div
                key={marketingTier.id}
                className="mx-auto max-w-2xl rounded-3xl bg-gray-800/50 ring-1 ring-white/10 lg:mx-0 lg:flex lg:max-w-none"
              >
                <div className="p-8 sm:p-10 lg:flex-auto">
                  <h3 className="text-3xl font-semibold tracking-tight text-white">
                    {marketingTier.name}
                  </h3>
                  <p className="mt-6 text-base/7 text-gray-300">
                    {marketingTier.description}
                  </p>
                  <div className="mt-10 flex items-center gap-x-4">
                    <h4 className="flex-none text-sm/6 font-semibold text-indigo-400">
                      How to Get Started
                    </h4>
                    <div className="h-px flex-auto bg-white/10" />
                  </div>
                  {marketingTier.howToGetStarted &&
                    marketingTier.howToGetStarted.length > 0 && (
                      <div className="mt-8">
                        <ul className="mt-3 space-y-3">
                          {marketingTier.howToGetStarted.map((step, index) => (
                            <li key={index}>
                              <h5 className="text-base font-semibold text-white">
                                {step.title}
                              </h5>
                              <p className="text-sm/6 text-gray-300">
                                {step.description}
                              </p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                </div>
                <div className="-mt-2 p-2 lg:mt-0 lg:w-full lg:max-w-md lg:shrink-0">
                  <div className="rounded-2xl bg-gray-900 py-2 text-center ring-1 ring-inset ring-white/10 lg:flex lg:flex-col lg:justify-center lg:py-4">
                    <div className="max-w-s mx-auto px-4">
                      <PricingCard
                        name={marketingTier.name}
                        price={price?.unitAmount ?? null}
                        interval={price?.interval ?? null}
                        trialDays={price?.trialPeriodDays ?? null}
                        priceId={price?.id ?? null}
                        checkoutAction={handleCheckoutAction}
                        actionState={{
                          url: checkoutData?.createCheckoutSession?.url,
                          error: checkoutError as any,
                        }}
                        isOwned={isOwned}
                        isSubscription={isSubscription}
                        activeCoupon={activeCoupon}
                        displayPrice={displayPrice}
                        originalPrice={originalPrice}
                        couponName={couponName}
                        discountBadgeText={discountBadgeText}
                        marketingTier={marketingTier}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
