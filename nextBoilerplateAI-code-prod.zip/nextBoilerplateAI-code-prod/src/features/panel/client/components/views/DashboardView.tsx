'use client'

export function DashboardView() {
  return <div className={'text-white'}>Welcome from DashboardView</div>
}
