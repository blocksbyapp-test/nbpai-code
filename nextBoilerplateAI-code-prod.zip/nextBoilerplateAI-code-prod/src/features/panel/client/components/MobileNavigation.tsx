interface NavItem {
  id: string
  name: string
}

interface MobileNavigationProps {
  navigation: NavItem[]
  activeViewId: string
  onNavigate: (id: string) => void
}

export function MobileNavigation({
  navigation,
  activeViewId,
  onNavigate,
}: MobileNavigationProps) {
  return (
    <div className="space-y-1 px-2 pb-3 pt-2 sm:px-3">
      {navigation.map((item) => (
        <button
          key={item.id}
          onClick={() => onNavigate(item.id)}
          aria-current={item.id === activeViewId ? 'page' : undefined}
          className={
            item.id === activeViewId
              ? 'block w-full rounded-md bg-gray-950/50 px-3 py-2 text-left text-base font-medium text-white'
              : 'block w-full rounded-md px-3 py-2 text-left text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white'
          }
        >
          {item.name}
        </button>
      ))}
    </div>
  )
}
