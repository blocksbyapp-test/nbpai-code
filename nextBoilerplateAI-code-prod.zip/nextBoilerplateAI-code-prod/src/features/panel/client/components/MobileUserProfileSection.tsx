import { PersonIcon as UserCircleIcon } from '@radix-ui/react-icons'
import { Session } from 'next-auth'
import { NavItem } from '../types'

interface MobileUserProfileSectionProps {
  session: Session | null
  userNavigation: NavItem[]
  activeViewId: string
  onNavigate: (id: string) => void
}

export function MobileUserProfileSection({
  session,
  userNavigation,
  onNavigate,
  activeViewId,
}: MobileUserProfileSectionProps) {
  return (
    <div className="border-t border-white/10 pb-3 pt-4">
      <div className="flex items-center px-5">
        <div className="shrink-0">
          {session?.user?.image ? (
            <img
              alt=""
              src={session.user.image}
              className="size-10 rounded-full outline outline-1 -outline-offset-1 outline-white/10"
            />
          ) : (
            <UserCircleIcon className="size-10 text-gray-300" />
          )}
        </div>
        <div className="ml-3">
          <div className="text-base font-medium text-white">
            {session?.user?.name}
          </div>
          <div className="text-sm font-medium text-gray-400">
            {session?.user?.email}
          </div>
        </div>
      </div>
      <div className="mt-3 space-y-1 px-2">
        {userNavigation.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={
              item.id === 'sign-out'
                ? 'block w-full rounded-md px-3 py-2 text-left text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white'
                : item.id === 'settings'
                  ? activeViewId === item.id
                    ? 'block w-full rounded-md bg-gray-950/50 px-3 py-2 text-left text-base font-medium text-white'
                    : 'block w-full rounded-md px-3 py-2 text-left text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white'
                  : 'block w-full rounded-md px-3 py-2 text-left text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white'
            }
          >
            {item.name}
          </button>
        ))}
      </div>
    </div>
  )
}
