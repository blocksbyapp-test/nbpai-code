interface NavItem {
  id: string
  name: string
}

interface DesktopNavigationProps {
  navigation: NavItem[]
  activeViewId: string
  onNavigate: (id: string) => void
}

export function DesktopNavigation({
  navigation,
  activeViewId,
  onNavigate,
}: DesktopNavigationProps) {
  return (
    <div className="ml-10 flex items-baseline space-x-4">
      {navigation.map((item) => (
        <button
          key={item.id}
          onClick={() => onNavigate(item.id)}
          aria-current={item.id === activeViewId ? 'page' : undefined}
          className={
            item.id === activeViewId
              ? 'bg-gray-950/50 text-white' +
                ' rounded-md px-3 py-2 text-sm font-medium'
              : 'text-gray-300 hover:bg-white/5 hover:text-white' +
                ' rounded-md px-3 py-2 text-sm font-medium'
          }
        >
          {item.name}
        </button>
      ))}
    </div>
  )
}
