'use client'

import { UserProfileDropdown } from '@/features/panel/client/components/UserProfileDropdown'

import { DashboardView } from '@/features/panel/client/components/views/DashboardView'
import { PricingView } from '@/features/panel/client/components/views/PricingView'
import { SettingsView } from '@/features/panel/client/components/views/SettingsView'
import { useCurrentUserDeletionStatusQuery } from '@/features/panel/generated/types'
import { Cross1Icon, HamburgerMenuIcon } from '@radix-ui/react-icons'
import { Dialog, IconButton } from '@radix-ui/themes'
import { signOut, useSession } from 'next-auth/react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { DeletionConfirmationModal } from '../components/DeletionConfirmationModal'
import { DesktopNavigation } from '../components/DesktopNavigation'
import { MobileNavigation } from '../components/MobileNavigation'
import { MobileUserProfileSection } from '../components/MobileUserProfileSection'
import { NavItem } from '../types'

const navigationConfig: NavItem[] = [
  { id: 'dashboard', name: 'Dashboard', component: DashboardView },
  { id: 'pricing', name: 'Pricing', component: PricingView },
]

const userNavigationConfig: NavItem[] = [
  { id: 'my-feature', name: 'My Feature (Todo List)' },
  { id: 'homepage', name: 'Homepage' },
  { id: 'settings', name: 'Settings', component: SettingsView },
  { id: 'sign-out', name: 'Sign out', action: 'signOut' },
]

export function PanelPage() {
  const { data: session } = useSession()
  const [activeViewId, setActiveViewId] = useState(navigationConfig[0].id)
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const router = useRouter()

  const { data: deletionStatusData, refetch: refetchDeletionStatus } =
    useCurrentUserDeletionStatusQuery({
      fetchPolicy: 'network-only',
    })

  const requestedDeletionAt =
    deletionStatusData?.currentUserDeletionStatus?.requestedDeletionAt

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener('scroll', handleScroll)

    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  const allNavigationItems = [...navigationConfig, ...userNavigationConfig]

  const CurrentViewComponent = allNavigationItems.find(
    (item) => item.id === activeViewId,
  )?.component

  const handleNavigationClick = (viewId: string) => {
    const navItem = allNavigationItems.find((item) => item.id === viewId)

    if (navItem) {
      if (navItem.action === 'signOut') {
        signOut()
      } else if (viewId === 'my-feature') {
        router.push('/my-feature')
        setMobileMenuOpen(false)
      } else if (viewId === 'homepage') {
        router.push('/')
        setMobileMenuOpen(false)
      } else {
        setActiveViewId(viewId)
        setMobileMenuOpen(false) // Close mobile menu on navigation
      }
    }
  }

  const activeItem = allNavigationItems.find((item) => item.id === activeViewId)

  const headerTitle = activeItem
    ? activeItem.name.charAt(0).toUpperCase() +
      activeItem.name.slice(1).replace(/-/g, ' ')
    : ''

  const handleCloseDeletionModal = () => {
    refetchDeletionStatus()
  }

  return (
    <div className="min-h-screen bg-gray-800">
      <nav
        className={`sticky top-0 z-50 bg-gray-800 transition-shadow duration-300 ${scrolled ? 'shadow-xl shadow-black/50' : ''}`}
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center">
              <div className="shrink-0">
                <Link href="/">
                  <img
                    alt="Your Company"
                    src="/LOGO_NBPAI.png"
                    className="size-8"
                  />
                </Link>
              </div>
              <div className="hidden md:block">
                <DesktopNavigation
                  navigation={navigationConfig}
                  activeViewId={activeViewId}
                  onNavigate={handleNavigationClick}
                />
              </div>
            </div>
            <div className="hidden md:block">
              <div className="ml-4 flex items-center md:ml-6">
                {/*<BellIconNotificationButton />*/}
                <UserProfileDropdown
                  session={session}
                  userNavigation={userNavigationConfig}
                  onNavigate={handleNavigationClick}
                />
              </div>
            </div>
            <div className="-mr-2 flex md:hidden">
              <IconButton
                onClick={() => setMobileMenuOpen(true)}
                className="group relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-white/5 hover:text-white focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-indigo-500"
              >
                <span className="absolute -inset-0.5" />
                <span className="sr-only">Open main menu</span>
                <HamburgerMenuIcon
                  className="block size-6"
                  aria-hidden="true"
                />
              </IconButton>
            </div>
          </div>
        </div>

        <Dialog.Root open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
          <Dialog.Content
            className="fixed inset-0 z-40 overflow-y-auto bg-gray-800"
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              width: '100vw',
              height: '100vh',
              padding: 0,
              margin: 0,
              borderRadius: 0,
              boxShadow: 'none',
            }}
          >
            {/* Mobile Header inside the overlay */}
            <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
              <div className="shrink-0">
                <Link href="/">
                  <img
                    alt="Your Company"
                    src="/LOGO_NBPAI.png"
                    className="size-8"
                  />
                </Link>
              </div>
              <IconButton
                onClick={() => setMobileMenuOpen(false)}
                className="group relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-white/5 hover:text-white focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-indigo-500"
              >
                <span className="absolute -inset-0.5" />
                <span className="sr-only">Close main menu</span>
                <Cross1Icon className="block size-6" aria-hidden="true" />
              </IconButton>
            </div>

            <MobileNavigation
              navigation={navigationConfig}
              activeViewId={activeViewId}
              onNavigate={handleNavigationClick}
            />
            <MobileUserProfileSection
              session={session}
              userNavigation={userNavigationConfig}
              activeViewId={activeViewId}
              onNavigate={handleNavigationClick}
            />
          </Dialog.Content>
        </Dialog.Root>
      </nav>
      <main>
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          {CurrentViewComponent && (
            <CurrentViewComponent onNavigate={handleNavigationClick} />
          )}
        </div>
      </main>
      {requestedDeletionAt && (
        <DeletionConfirmationModal
          requestedDeletionAt={requestedDeletionAt}
          onClose={handleCloseDeletionModal}
        />
      )}
    </div>
  )
}
