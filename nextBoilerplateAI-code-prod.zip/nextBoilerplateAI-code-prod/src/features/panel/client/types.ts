import { ReactElement } from 'react'

export interface NavItem {
  id: string
  name: string
  component?: (props: { onNavigate: (id: string) => void }) => ReactElement
  action?: string
}
