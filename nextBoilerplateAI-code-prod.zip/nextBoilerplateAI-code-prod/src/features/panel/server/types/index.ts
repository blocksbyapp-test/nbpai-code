import {
  GraphQLBoolean,
  GraphQLNonNull,
  GraphQLObjectType,
  GraphQLString,
} from 'graphql'
import { GraphQLDate } from 'graphql-compose'

export const MutationResponse = new GraphQLObjectType({
  name: 'MutationResponse',
  fields: {
    success: { type: new GraphQLNonNull(GraphQLBoolean) },
    message: { type: GraphQLString },
  },
})

export const DeletionStatusPayload = new GraphQLObjectType({
  name: 'DeletionStatusPayload',
  fields: { requestedDeletionAt: { type: GraphQLDate } },
})
