import { GraphQLBoolean, GraphQLObjectType, GraphQLString } from 'graphql'

export const NotifyAICodingAssistantPayload = new GraphQLObjectType({
  name: 'NotifyAICodingAssistantPayload',
  fields: {
    success: { type: GraphQLBoolean },
    message: { type: GraphQLString },
  },
})
