import { sendEmailFromLocalTemplate } from '@/features/core/server/services/emailService'
import { createGraphqlServer } from '@/features/core/server/services/graphqlServer'
import { createUserPasswordOperations } from '@/features/core/server/services/userPasswordOperations'
import { PasswordResetToken } from '@/features/panel/server/models/PasswordResetToken'
import { User, UserTC } from '@/features/panel/server/models/User'

const { query: passwordQuery, mutation: passwordMutation } =
  createUserPasswordOperations(User, PasswordResetToken, 'panel')

const { POST, GET, dynamic } = createGraphqlServer({
  query: {
    ...passwordQuery,
  },
  mutation: {
    UserCreateOne: UserTC.mongooseResolvers
      .createOne()
      .wrapResolve((next) => async (rp) => {
        const payload = await next(rp)
        if (payload.record) {
          const { name, email } = payload.record
          await sendEmailFromLocalTemplate(
            'RegistrationEmail',
            { name: name || email },
            email,
          )
        }
        return payload
      }),
    ...passwordMutation,
  },
  models: [],
})

export { dynamic, GET, POST }
