import { auth } from '@/features/core/server/services/auth'
import { createPaymentsOperations } from '@/features/core/server/services/createPaymentsOperations'
import { createGraphqlServer } from '@/features/core/server/services/graphqlServer'
import { User, UserTC } from '@/features/panel/server/models/User'
import { cancelAccountDeletion } from '@/features/panel/server/resolvers/cancelAccountDeletion'
import { changePassword } from '@/features/panel/server/resolvers/changePassword'
import { currentUserDeletionStatus } from '@/features/panel/server/resolvers/currentUserDeletionStatus'

import { notifyAICodingAssistant } from '@/features/panel/server/resolvers/notifyAICodingAssistant'
import { requestAccountDeletion } from '@/features/panel/server/resolvers/requestAccountDeletion'
import {
  DeletionStatusPayload,
  MutationResponse,
} from '@/features/panel/server/types'
import { NotifyAICodingAssistantPayload } from '@/features/panel/server/types/AICodingAssistantTypes'
import { ChangePasswordPayload } from '@/features/panel/server/types/ChangePasswordTypes'
import { GraphQLNonNull, GraphQLString } from 'graphql'
import { panelStripeAdapters } from './services/stripeDatabaseAdapters'

const { query: paymentsQuery, mutation: paymentsMutation } =
  createPaymentsOperations(panelStripeAdapters, 'panel')

const { POST, GET, dynamic } = createGraphqlServer({
  query: {
    ...paymentsQuery,
    currentUser: {
      type: UserTC.getType(),
      resolve: async (source, args, context) => {
        const session = await auth()
        if (!session?.user?.email) return null
        const user = await User.findOne({ email: session.user.email })
        return user
      },
    },
    currentUserDeletionStatus: {
      type: DeletionStatusPayload,
      resolve: currentUserDeletionStatus,
    },
  },
  mutation: {
    ...paymentsMutation,
    changePassword: {
      type: ChangePasswordPayload,
      args: {
        currentPassword: { type: new GraphQLNonNull(GraphQLString) },
        newPassword: { type: new GraphQLNonNull(GraphQLString) },
        confirmPassword: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: changePassword,
    },
    requestAccountDeletion: {
      type: MutationResponse,
      resolve: requestAccountDeletion,
    },
    cancelAccountDeletion: {
      type: MutationResponse,
      resolve: cancelAccountDeletion,
    },
    notifyAICodingAssistant: {
      type: NotifyAICodingAssistantPayload,
      resolve: notifyAICodingAssistant,
    },
  },
  models: [],
})

export { dynamic, GET, POST }
