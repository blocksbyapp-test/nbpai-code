import { createStripeDatabaseAdapters } from '@/features/core/server/services/createStripeDatabaseAdapters'
import { sendEmailFromLocalTemplate } from '@/features/core/server/services/emailService'
import { Team } from '@/features/panel/server/models/Team'
import { User } from '@/features/panel/server/models/User'

export const panelStripeAdapters = createStripeDatabaseAdapters(
  User,
  Team,
  async (email, name) => {
    await sendEmailFromLocalTemplate(
      'RegistrationEmail',
      { name: name || email },
      email,
    )
  },
)
