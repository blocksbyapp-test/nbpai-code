import { passwordResetTokenSchema } from '@/features/core/server/models/PasswordResetToken'
import { createMongooseModel } from '@/features/core/server/services/mongoose'

export const { PasswordResetToken, PasswordResetTokenTC } = createMongooseModel(
  'panel',
  'PasswordResetToken',
  passwordResetTokenSchema,
)
