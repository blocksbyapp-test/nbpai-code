import {
  addPasswordHashingToUserSchema,
  coreUserFields,
} from '@/features/core/server/models/User'
import { createMongooseModel } from '@/features/core/server/services/mongoose'
import mongoose from 'mongoose'
export const userSchema = new mongoose.Schema(
  {
    ...coreUserFields,
    NotifyAICodingAssistantDate: { type: Date },
    requestedDeletionAt: { type: Date },
  },
  { timestamps: true },
)

addPasswordHashingToUserSchema(userSchema)
export const { User, UserTC, UserMutations } = createMongooseModel(
  'panel',
  'User',
  userSchema,
)
