import { teamSchema } from '@/features/core/server/models/Team'
import { createMongooseModel } from '@/features/core/server/services/mongoose'

export const { Team, TeamTC, TeamQueries, TeamMutations } = createMongooseModel(
  'panel',
  'Team',
  teamSchema,
)
