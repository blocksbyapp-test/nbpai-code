import { auth } from '@/features/core/server/services/auth'
import { Resolver } from '@/features/core/server/types/types'
import { User } from '@/features/panel/server/models/User'

export const currentUserDeletionStatus: Resolver<any, any> = async (
  parent,
  args,
  context,
) => {
  try {
    const session = await auth()
    if (!session?.user?.email) {
      return null
    }

    const user = await User.findOne({ email: session.user.email })
    if (!user) {
      return null
    }

    return { requestedDeletionAt: user.requestedDeletionAt }
  } catch (err: any) {
    console.error('Error fetching current user deletion status:', err)
    return null
  }
}
