import { auth } from '@/features/core/server/services/auth'
import { Resolver } from '@/features/core/server/types/types'
import { User } from '@/features/panel/server/models/User'

export const notifyAICodingAssistant: Resolver<any, any> = async (
  parent,
  args,
  context,
) => {
  try {
    const session = await auth()
    if (!session?.user?.email) {
      return { success: false, message: 'Authentication required.' }
    }

    const user = await User.findOne({ email: session.user.email })
    if (!user) {
      return { success: false, message: 'User not found.' }
    }

    if (user.NotifyAICodingAssistantDate) {
      return {
        success: false,
        message: 'You have already requested early access.',
      }
    }

    user.NotifyAICodingAssistantDate = new Date()
    await user.save()

    return {
      success: true,
      message: 'You will be notified for early access!',
    }
  } catch (err: any) {
    console.error('Error notifying AI Coding Assistant:', err)
    return {
      success: false,
      message: err.message || 'An unexpected error occurred.',
    }
  }
}
