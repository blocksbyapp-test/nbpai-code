import { auth } from '@/features/core/server/services/auth'
import { Resolver } from '@/features/core/server/types/types'
import { User } from '@/features/panel/server/models/User'
import bcrypt from 'bcrypt'

export const changePassword: Resolver<any, any> = async (
  parent,
  args,
  context,
) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = args

    if (newPassword !== confirmPassword) {
      return {
        success: false,
        message: 'New password and confirm password do not match.',
      }
    }

    const session = await auth()
    if (!session?.user?.email) {
      return { success: false, message: 'Authentication required.' }
    }

    const user = await User.findOne({ email: session.user.email }).select(
      '+password',
    )

    if (!user) {
      return { success: false, message: 'User not found.' }
    }

    if (user.authProvider !== 'credentials') {
      return {
        success: false,
        message: 'Password change is only available for credentials accounts.',
      }
    }

    const isCurrentPasswordValid = await bcrypt.compare(
      currentPassword,
      user.password || '',
    )

    if (!isCurrentPasswordValid) {
      return { success: false, message: 'Incorrect current password.' }
    }

    user.password = newPassword

    await user.save()

    return { success: true, message: 'Password changed successfully.' }
  } catch (err: any) {
    console.error('Error changing password:', err)
    return {
      success: false,
      message: err.message || 'An unexpected error occurred.',
    }
  }
}
