import { auth } from '@/features/core/server/services/auth'
import { Resolver } from '@/features/core/server/types/types'
import { User } from '@/features/panel/server/models/User'

export const requestAccountDeletion: Resolver<any, any> = async (
  parent,
  args,
  context,
) => {
  try {
    const session = await auth()
    if (!session?.user?.email) {
      return { success: false, message: 'Authentication required.' }
    }

    const user = await User.findOne({ email: session.user.email })
    if (!user) {
      return { success: false, message: 'User not found.' }
    }

    user.requestedDeletionAt = new Date()
    await user.save()

    return {
      success: true,
      message: 'Account flagged for deletion. You have 7 days to cancel.',
    }
  } catch (err: any) {
    console.error('Error requesting account deletion:', err)
    return {
      success: false,
      message: err.message || 'An unexpected error occurred.',
    }
  }
}
