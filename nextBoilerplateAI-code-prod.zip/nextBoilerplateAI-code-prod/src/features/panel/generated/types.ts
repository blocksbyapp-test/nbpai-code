import * as Apollo from '@apollo/client'
import { gql } from '@apollo/client'
export type Maybe<T> = T | null
export type InputMaybe<T> = Maybe<T>
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K]
}
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]?: Maybe<T[SubKey]>
}
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]: Maybe<T[SubKey]>
}
export type MakeEmpty<
  T extends { [key: string]: unknown },
  K extends keyof T,
> = { [_ in K]?: never }
export type Incremental<T> =
  | T
  | {
      [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never
    }
const defaultOptions = {} as const
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string }
  String: { input: string; output: string }
  Boolean: { input: boolean; output: boolean }
  Int: { input: number; output: number }
  Float: { input: number; output: number }
  Date: { input: any; output: any }
  MongoID: { input: any; output: any }
}

export type ChangePasswordPayload = {
  message?: Maybe<Scalars['String']['output']>
  success: Scalars['Boolean']['output']
}

export type CreateCheckoutSessionPayload = {
  error?: Maybe<Scalars['String']['output']>
  url?: Maybe<Scalars['String']['output']>
}

export type DeletionStatusPayload = {
  requestedDeletionAt?: Maybe<Scalars['Date']['output']>
}

export type Mutation = {
  cancelAccountDeletion?: Maybe<MutationResponse>
  changePassword?: Maybe<ChangePasswordPayload>
  createCheckoutSession?: Maybe<CreateCheckoutSessionPayload>
  notifyAICodingAssistant?: Maybe<NotifyAiCodingAssistantPayload>
  requestAccountDeletion?: Maybe<MutationResponse>
}

export type MutationChangePasswordArgs = {
  confirmPassword: Scalars['String']['input']
  currentPassword: Scalars['String']['input']
  newPassword: Scalars['String']['input']
}

export type MutationCreateCheckoutSessionArgs = {
  couponId?: InputMaybe<Scalars['String']['input']>
  priceId: Scalars['String']['input']
}

export type MutationResponse = {
  message?: Maybe<Scalars['String']['output']>
  success: Scalars['Boolean']['output']
}

export type NotifyAiCodingAssistantPayload = {
  message?: Maybe<Scalars['String']['output']>
  success?: Maybe<Scalars['Boolean']['output']>
}

export type PurchasedProduct = {
  couponId?: Maybe<Scalars['String']['output']>
  productId?: Maybe<Scalars['String']['output']>
  purchaseDate?: Maybe<Scalars['Date']['output']>
}

export type Query = {
  currentUser?: Maybe<User>
  currentUserDeletionStatus?: Maybe<DeletionStatusPayload>
  currentUserPurchasedProductIds?: Maybe<Array<Maybe<PurchasedProduct>>>
  currentUserStripeSubscriptionId?: Maybe<Scalars['String']['output']>
  currentUserSubscriptionStatus?: Maybe<Scalars['String']['output']>
  stripeCheckoutSessionDetails?: Maybe<StripeCheckoutSessionDetails>
  stripeCoupons: Array<StripeCoupon>
  stripePrices: Array<StripePrice>
  stripeProducts: Array<StripeProduct>
}

export type QueryStripeCheckoutSessionDetailsArgs = {
  sessionId: Scalars['String']['input']
}

export type StripeCheckoutSessionDetails = {
  amountTotal?: Maybe<Scalars['Int']['output']>
  coupon?: Maybe<Scalars['String']['output']>
  currency?: Maybe<Scalars['String']['output']>
  id: Scalars['String']['output']
  productId?: Maybe<Scalars['String']['output']>
  productName?: Maybe<Scalars['String']['output']>
}

export type StripeCoupon = {
  amountOff?: Maybe<Scalars['Int']['output']>
  currency?: Maybe<Scalars['String']['output']>
  duration?: Maybe<Scalars['String']['output']>
  durationInMonths?: Maybe<Scalars['Int']['output']>
  id?: Maybe<Scalars['String']['output']>
  maxRedemptions?: Maybe<Scalars['Int']['output']>
  name?: Maybe<Scalars['String']['output']>
  percentOff?: Maybe<Scalars['Float']['output']>
  redeemBy?: Maybe<Scalars['Date']['output']>
  timesRedeemed?: Maybe<Scalars['Int']['output']>
  valid?: Maybe<Scalars['Boolean']['output']>
}

export type StripePrice = {
  currency?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['String']['output']>
  interval?: Maybe<Scalars['String']['output']>
  productId?: Maybe<Scalars['String']['output']>
  trialPeriodDays?: Maybe<Scalars['Int']['output']>
  unitAmount?: Maybe<Scalars['Int']['output']>
}

export type StripeProduct = {
  defaultPriceId?: Maybe<Scalars['String']['output']>
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['String']['output']>
  name?: Maybe<Scalars['String']['output']>
}

export type User = {
  NotifyAICodingAssistantDate?: Maybe<Scalars['Date']['output']>
  _id: Scalars['MongoID']['output']
  authProvider: Scalars['String']['output']
  createdAt?: Maybe<Scalars['Date']['output']>
  email: Scalars['String']['output']
  name?: Maybe<Scalars['String']['output']>
  password?: Maybe<Scalars['String']['output']>
  registrationDate?: Maybe<Scalars['Date']['output']>
  requestedDeletionAt?: Maybe<Scalars['Date']['output']>
  salt?: Maybe<Scalars['String']['output']>
  teamId?: Maybe<Scalars['MongoID']['output']>
  updatedAt?: Maybe<Scalars['Date']['output']>
}

export type CancelAccountDeletionMutationVariables = Exact<{
  [key: string]: never
}>

export type CancelAccountDeletionMutation = {
  cancelAccountDeletion?: { success: boolean; message?: string | null } | null
}

export type ChangePasswordMutationVariables = Exact<{
  currentPassword: Scalars['String']['input']
  newPassword: Scalars['String']['input']
  confirmPassword: Scalars['String']['input']
}>

export type ChangePasswordMutation = {
  changePassword?: { success: boolean; message?: string | null } | null
}

export type CreateCheckoutSessionMutationVariables = Exact<{
  priceId: Scalars['String']['input']
  couponId?: InputMaybe<Scalars['String']['input']>
}>

export type CreateCheckoutSessionMutation = {
  createCheckoutSession?: { url?: string | null } | null
}

export type CurrentUserQueryVariables = Exact<{ [key: string]: never }>

export type CurrentUserQuery = {
  currentUser?: {
    authProvider: string
    email: string
    name?: string | null
    password?: string | null
    salt?: string | null
    teamId?: any | null
    registrationDate?: any | null
    NotifyAICodingAssistantDate?: any | null
    requestedDeletionAt?: any | null
    _id: any
    createdAt?: any | null
    updatedAt?: any | null
  } | null
}

export type CurrentUserDeletionStatusQueryVariables = Exact<{
  [key: string]: never
}>

export type CurrentUserDeletionStatusQuery = {
  currentUserDeletionStatus?: { requestedDeletionAt?: any | null } | null
}

export type CurrentUserPurchasedProductIdsQueryVariables = Exact<{
  [key: string]: never
}>

export type CurrentUserPurchasedProductIdsQuery = {
  currentUserPurchasedProductIds?: Array<{
    productId?: string | null
    couponId?: string | null
    purchaseDate?: any | null
  } | null> | null
}

export type CurrentUserStripeSubscriptionIdQueryVariables = Exact<{
  [key: string]: never
}>

export type CurrentUserStripeSubscriptionIdQuery = {
  currentUserStripeSubscriptionId?: string | null
}

export type CurrentUserSubscriptionStatusQueryVariables = Exact<{
  [key: string]: never
}>

export type CurrentUserSubscriptionStatusQuery = {
  currentUserSubscriptionStatus?: string | null
}

export type NotifyAiCodingAssistantMutationVariables = Exact<{
  [key: string]: never
}>

export type NotifyAiCodingAssistantMutation = {
  notifyAICodingAssistant?: {
    success?: boolean | null
    message?: string | null
  } | null
}

export type RequestAccountDeletionMutationVariables = Exact<{
  [key: string]: never
}>

export type RequestAccountDeletionMutation = {
  requestAccountDeletion?: { success: boolean; message?: string | null } | null
}

export type StripeCheckoutSessionDetailsQueryVariables = Exact<{
  sessionId: Scalars['String']['input']
}>

export type StripeCheckoutSessionDetailsQuery = {
  stripeCheckoutSessionDetails?: {
    id: string
    amountTotal?: number | null
    currency?: string | null
    coupon?: string | null
    productId?: string | null
    productName?: string | null
  } | null
}

export type StripeCouponsQueryVariables = Exact<{ [key: string]: never }>

export type StripeCouponsQuery = {
  stripeCoupons: Array<{
    id?: string | null
    name?: string | null
    percentOff?: number | null
    amountOff?: number | null
    currency?: string | null
    duration?: string | null
    durationInMonths?: number | null
    maxRedemptions?: number | null
    redeemBy?: any | null
    timesRedeemed?: number | null
    valid?: boolean | null
  }>
}

export type StripePricesQueryVariables = Exact<{ [key: string]: never }>

export type StripePricesQuery = {
  stripePrices: Array<{
    id?: string | null
    productId?: string | null
    unitAmount?: number | null
    currency?: string | null
    interval?: string | null
    trialPeriodDays?: number | null
  }>
}

export type StripeProductsQueryVariables = Exact<{ [key: string]: never }>

export type StripeProductsQuery = {
  stripeProducts: Array<{
    id?: string | null
    name?: string | null
    description?: string | null
    defaultPriceId?: string | null
  }>
}

export const CancelAccountDeletionDocument = gql`
  mutation cancelAccountDeletion {
    cancelAccountDeletion {
      success
      message
    }
  }
`
export type CancelAccountDeletionMutationFn = Apollo.MutationFunction<
  CancelAccountDeletionMutation,
  CancelAccountDeletionMutationVariables
>
export function useCancelAccountDeletionMutation(
  baseOptions?: Apollo.MutationHookOptions<
    CancelAccountDeletionMutation,
    CancelAccountDeletionMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    CancelAccountDeletionMutation,
    CancelAccountDeletionMutationVariables
  >(CancelAccountDeletionDocument, options)
}
export type CancelAccountDeletionMutationHookResult = ReturnType<
  typeof useCancelAccountDeletionMutation
>
export type CancelAccountDeletionMutationResult =
  Apollo.MutationResult<CancelAccountDeletionMutation>
export type CancelAccountDeletionMutationOptions = Apollo.BaseMutationOptions<
  CancelAccountDeletionMutation,
  CancelAccountDeletionMutationVariables
>
export const ChangePasswordDocument = gql`
  mutation changePassword(
    $currentPassword: String!
    $newPassword: String!
    $confirmPassword: String!
  ) {
    changePassword(
      currentPassword: $currentPassword
      newPassword: $newPassword
      confirmPassword: $confirmPassword
    ) {
      success
      message
    }
  }
`
export type ChangePasswordMutationFn = Apollo.MutationFunction<
  ChangePasswordMutation,
  ChangePasswordMutationVariables
>
export function useChangePasswordMutation(
  baseOptions?: Apollo.MutationHookOptions<
    ChangePasswordMutation,
    ChangePasswordMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    ChangePasswordMutation,
    ChangePasswordMutationVariables
  >(ChangePasswordDocument, options)
}
export type ChangePasswordMutationHookResult = ReturnType<
  typeof useChangePasswordMutation
>
export type ChangePasswordMutationResult =
  Apollo.MutationResult<ChangePasswordMutation>
export type ChangePasswordMutationOptions = Apollo.BaseMutationOptions<
  ChangePasswordMutation,
  ChangePasswordMutationVariables
>
export const CreateCheckoutSessionDocument = gql`
  mutation createCheckoutSession($priceId: String!, $couponId: String) {
    createCheckoutSession(priceId: $priceId, couponId: $couponId) {
      url
    }
  }
`
export type CreateCheckoutSessionMutationFn = Apollo.MutationFunction<
  CreateCheckoutSessionMutation,
  CreateCheckoutSessionMutationVariables
>
export function useCreateCheckoutSessionMutation(
  baseOptions?: Apollo.MutationHookOptions<
    CreateCheckoutSessionMutation,
    CreateCheckoutSessionMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    CreateCheckoutSessionMutation,
    CreateCheckoutSessionMutationVariables
  >(CreateCheckoutSessionDocument, options)
}
export type CreateCheckoutSessionMutationHookResult = ReturnType<
  typeof useCreateCheckoutSessionMutation
>
export type CreateCheckoutSessionMutationResult =
  Apollo.MutationResult<CreateCheckoutSessionMutation>
export type CreateCheckoutSessionMutationOptions = Apollo.BaseMutationOptions<
  CreateCheckoutSessionMutation,
  CreateCheckoutSessionMutationVariables
>
export const CurrentUserDocument = gql`
  query currentUser {
    currentUser {
      authProvider
      email
      name
      password
      salt
      teamId
      registrationDate
      NotifyAICodingAssistantDate
      requestedDeletionAt
      _id
      createdAt
      updatedAt
    }
  }
`
export function useCurrentUserQuery(
  baseOptions?: Apollo.QueryHookOptions<
    CurrentUserQuery,
    CurrentUserQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<CurrentUserQuery, CurrentUserQueryVariables>(
    CurrentUserDocument,
    options,
  )
}
export function useCurrentUserLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    CurrentUserQuery,
    CurrentUserQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<CurrentUserQuery, CurrentUserQueryVariables>(
    CurrentUserDocument,
    options,
  )
}
export function useCurrentUserSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        CurrentUserQuery,
        CurrentUserQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<CurrentUserQuery, CurrentUserQueryVariables>(
    CurrentUserDocument,
    options,
  )
}
export type CurrentUserQueryHookResult = ReturnType<typeof useCurrentUserQuery>
export type CurrentUserLazyQueryHookResult = ReturnType<
  typeof useCurrentUserLazyQuery
>
export type CurrentUserSuspenseQueryHookResult = ReturnType<
  typeof useCurrentUserSuspenseQuery
>
export type CurrentUserQueryResult = Apollo.QueryResult<
  CurrentUserQuery,
  CurrentUserQueryVariables
>
export const CurrentUserDeletionStatusDocument = gql`
  query currentUserDeletionStatus {
    currentUserDeletionStatus {
      requestedDeletionAt
    }
  }
`
export function useCurrentUserDeletionStatusQuery(
  baseOptions?: Apollo.QueryHookOptions<
    CurrentUserDeletionStatusQuery,
    CurrentUserDeletionStatusQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<
    CurrentUserDeletionStatusQuery,
    CurrentUserDeletionStatusQueryVariables
  >(CurrentUserDeletionStatusDocument, options)
}
export function useCurrentUserDeletionStatusLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    CurrentUserDeletionStatusQuery,
    CurrentUserDeletionStatusQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<
    CurrentUserDeletionStatusQuery,
    CurrentUserDeletionStatusQueryVariables
  >(CurrentUserDeletionStatusDocument, options)
}
export function useCurrentUserDeletionStatusSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        CurrentUserDeletionStatusQuery,
        CurrentUserDeletionStatusQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    CurrentUserDeletionStatusQuery,
    CurrentUserDeletionStatusQueryVariables
  >(CurrentUserDeletionStatusDocument, options)
}
export type CurrentUserDeletionStatusQueryHookResult = ReturnType<
  typeof useCurrentUserDeletionStatusQuery
>
export type CurrentUserDeletionStatusLazyQueryHookResult = ReturnType<
  typeof useCurrentUserDeletionStatusLazyQuery
>
export type CurrentUserDeletionStatusSuspenseQueryHookResult = ReturnType<
  typeof useCurrentUserDeletionStatusSuspenseQuery
>
export type CurrentUserDeletionStatusQueryResult = Apollo.QueryResult<
  CurrentUserDeletionStatusQuery,
  CurrentUserDeletionStatusQueryVariables
>
export const CurrentUserPurchasedProductIdsDocument = gql`
  query currentUserPurchasedProductIds {
    currentUserPurchasedProductIds {
      productId
      couponId
      purchaseDate
    }
  }
`
export function useCurrentUserPurchasedProductIdsQuery(
  baseOptions?: Apollo.QueryHookOptions<
    CurrentUserPurchasedProductIdsQuery,
    CurrentUserPurchasedProductIdsQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<
    CurrentUserPurchasedProductIdsQuery,
    CurrentUserPurchasedProductIdsQueryVariables
  >(CurrentUserPurchasedProductIdsDocument, options)
}
export function useCurrentUserPurchasedProductIdsLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    CurrentUserPurchasedProductIdsQuery,
    CurrentUserPurchasedProductIdsQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<
    CurrentUserPurchasedProductIdsQuery,
    CurrentUserPurchasedProductIdsQueryVariables
  >(CurrentUserPurchasedProductIdsDocument, options)
}
export function useCurrentUserPurchasedProductIdsSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        CurrentUserPurchasedProductIdsQuery,
        CurrentUserPurchasedProductIdsQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    CurrentUserPurchasedProductIdsQuery,
    CurrentUserPurchasedProductIdsQueryVariables
  >(CurrentUserPurchasedProductIdsDocument, options)
}
export type CurrentUserPurchasedProductIdsQueryHookResult = ReturnType<
  typeof useCurrentUserPurchasedProductIdsQuery
>
export type CurrentUserPurchasedProductIdsLazyQueryHookResult = ReturnType<
  typeof useCurrentUserPurchasedProductIdsLazyQuery
>
export type CurrentUserPurchasedProductIdsSuspenseQueryHookResult = ReturnType<
  typeof useCurrentUserPurchasedProductIdsSuspenseQuery
>
export type CurrentUserPurchasedProductIdsQueryResult = Apollo.QueryResult<
  CurrentUserPurchasedProductIdsQuery,
  CurrentUserPurchasedProductIdsQueryVariables
>
export const CurrentUserStripeSubscriptionIdDocument = gql`
  query currentUserStripeSubscriptionId {
    currentUserStripeSubscriptionId
  }
`
export function useCurrentUserStripeSubscriptionIdQuery(
  baseOptions?: Apollo.QueryHookOptions<
    CurrentUserStripeSubscriptionIdQuery,
    CurrentUserStripeSubscriptionIdQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<
    CurrentUserStripeSubscriptionIdQuery,
    CurrentUserStripeSubscriptionIdQueryVariables
  >(CurrentUserStripeSubscriptionIdDocument, options)
}
export function useCurrentUserStripeSubscriptionIdLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    CurrentUserStripeSubscriptionIdQuery,
    CurrentUserStripeSubscriptionIdQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<
    CurrentUserStripeSubscriptionIdQuery,
    CurrentUserStripeSubscriptionIdQueryVariables
  >(CurrentUserStripeSubscriptionIdDocument, options)
}
export function useCurrentUserStripeSubscriptionIdSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        CurrentUserStripeSubscriptionIdQuery,
        CurrentUserStripeSubscriptionIdQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    CurrentUserStripeSubscriptionIdQuery,
    CurrentUserStripeSubscriptionIdQueryVariables
  >(CurrentUserStripeSubscriptionIdDocument, options)
}
export type CurrentUserStripeSubscriptionIdQueryHookResult = ReturnType<
  typeof useCurrentUserStripeSubscriptionIdQuery
>
export type CurrentUserStripeSubscriptionIdLazyQueryHookResult = ReturnType<
  typeof useCurrentUserStripeSubscriptionIdLazyQuery
>
export type CurrentUserStripeSubscriptionIdSuspenseQueryHookResult = ReturnType<
  typeof useCurrentUserStripeSubscriptionIdSuspenseQuery
>
export type CurrentUserStripeSubscriptionIdQueryResult = Apollo.QueryResult<
  CurrentUserStripeSubscriptionIdQuery,
  CurrentUserStripeSubscriptionIdQueryVariables
>
export const CurrentUserSubscriptionStatusDocument = gql`
  query currentUserSubscriptionStatus {
    currentUserSubscriptionStatus
  }
`
export function useCurrentUserSubscriptionStatusQuery(
  baseOptions?: Apollo.QueryHookOptions<
    CurrentUserSubscriptionStatusQuery,
    CurrentUserSubscriptionStatusQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<
    CurrentUserSubscriptionStatusQuery,
    CurrentUserSubscriptionStatusQueryVariables
  >(CurrentUserSubscriptionStatusDocument, options)
}
export function useCurrentUserSubscriptionStatusLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    CurrentUserSubscriptionStatusQuery,
    CurrentUserSubscriptionStatusQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<
    CurrentUserSubscriptionStatusQuery,
    CurrentUserSubscriptionStatusQueryVariables
  >(CurrentUserSubscriptionStatusDocument, options)
}
export function useCurrentUserSubscriptionStatusSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        CurrentUserSubscriptionStatusQuery,
        CurrentUserSubscriptionStatusQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    CurrentUserSubscriptionStatusQuery,
    CurrentUserSubscriptionStatusQueryVariables
  >(CurrentUserSubscriptionStatusDocument, options)
}
export type CurrentUserSubscriptionStatusQueryHookResult = ReturnType<
  typeof useCurrentUserSubscriptionStatusQuery
>
export type CurrentUserSubscriptionStatusLazyQueryHookResult = ReturnType<
  typeof useCurrentUserSubscriptionStatusLazyQuery
>
export type CurrentUserSubscriptionStatusSuspenseQueryHookResult = ReturnType<
  typeof useCurrentUserSubscriptionStatusSuspenseQuery
>
export type CurrentUserSubscriptionStatusQueryResult = Apollo.QueryResult<
  CurrentUserSubscriptionStatusQuery,
  CurrentUserSubscriptionStatusQueryVariables
>
export const NotifyAiCodingAssistantDocument = gql`
  mutation notifyAICodingAssistant {
    notifyAICodingAssistant {
      success
      message
    }
  }
`
export type NotifyAiCodingAssistantMutationFn = Apollo.MutationFunction<
  NotifyAiCodingAssistantMutation,
  NotifyAiCodingAssistantMutationVariables
>
export function useNotifyAiCodingAssistantMutation(
  baseOptions?: Apollo.MutationHookOptions<
    NotifyAiCodingAssistantMutation,
    NotifyAiCodingAssistantMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    NotifyAiCodingAssistantMutation,
    NotifyAiCodingAssistantMutationVariables
  >(NotifyAiCodingAssistantDocument, options)
}
export type NotifyAiCodingAssistantMutationHookResult = ReturnType<
  typeof useNotifyAiCodingAssistantMutation
>
export type NotifyAiCodingAssistantMutationResult =
  Apollo.MutationResult<NotifyAiCodingAssistantMutation>
export type NotifyAiCodingAssistantMutationOptions = Apollo.BaseMutationOptions<
  NotifyAiCodingAssistantMutation,
  NotifyAiCodingAssistantMutationVariables
>
export const RequestAccountDeletionDocument = gql`
  mutation requestAccountDeletion {
    requestAccountDeletion {
      success
      message
    }
  }
`
export type RequestAccountDeletionMutationFn = Apollo.MutationFunction<
  RequestAccountDeletionMutation,
  RequestAccountDeletionMutationVariables
>
export function useRequestAccountDeletionMutation(
  baseOptions?: Apollo.MutationHookOptions<
    RequestAccountDeletionMutation,
    RequestAccountDeletionMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    RequestAccountDeletionMutation,
    RequestAccountDeletionMutationVariables
  >(RequestAccountDeletionDocument, options)
}
export type RequestAccountDeletionMutationHookResult = ReturnType<
  typeof useRequestAccountDeletionMutation
>
export type RequestAccountDeletionMutationResult =
  Apollo.MutationResult<RequestAccountDeletionMutation>
export type RequestAccountDeletionMutationOptions = Apollo.BaseMutationOptions<
  RequestAccountDeletionMutation,
  RequestAccountDeletionMutationVariables
>
export const StripeCheckoutSessionDetailsDocument = gql`
  query stripeCheckoutSessionDetails($sessionId: String!) {
    stripeCheckoutSessionDetails(sessionId: $sessionId) {
      id
      amountTotal
      currency
      coupon
      productId
      productName
    }
  }
`
export function useStripeCheckoutSessionDetailsQuery(
  baseOptions: Apollo.QueryHookOptions<
    StripeCheckoutSessionDetailsQuery,
    StripeCheckoutSessionDetailsQueryVariables
  > &
    (
      | {
          variables: StripeCheckoutSessionDetailsQueryVariables
          skip?: boolean
        }
      | { skip: boolean }
    ),
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<
    StripeCheckoutSessionDetailsQuery,
    StripeCheckoutSessionDetailsQueryVariables
  >(StripeCheckoutSessionDetailsDocument, options)
}
export function useStripeCheckoutSessionDetailsLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    StripeCheckoutSessionDetailsQuery,
    StripeCheckoutSessionDetailsQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<
    StripeCheckoutSessionDetailsQuery,
    StripeCheckoutSessionDetailsQueryVariables
  >(StripeCheckoutSessionDetailsDocument, options)
}
export function useStripeCheckoutSessionDetailsSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        StripeCheckoutSessionDetailsQuery,
        StripeCheckoutSessionDetailsQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    StripeCheckoutSessionDetailsQuery,
    StripeCheckoutSessionDetailsQueryVariables
  >(StripeCheckoutSessionDetailsDocument, options)
}
export type StripeCheckoutSessionDetailsQueryHookResult = ReturnType<
  typeof useStripeCheckoutSessionDetailsQuery
>
export type StripeCheckoutSessionDetailsLazyQueryHookResult = ReturnType<
  typeof useStripeCheckoutSessionDetailsLazyQuery
>
export type StripeCheckoutSessionDetailsSuspenseQueryHookResult = ReturnType<
  typeof useStripeCheckoutSessionDetailsSuspenseQuery
>
export type StripeCheckoutSessionDetailsQueryResult = Apollo.QueryResult<
  StripeCheckoutSessionDetailsQuery,
  StripeCheckoutSessionDetailsQueryVariables
>
export const StripeCouponsDocument = gql`
  query stripeCoupons {
    stripeCoupons {
      id
      name
      percentOff
      amountOff
      currency
      duration
      durationInMonths
      maxRedemptions
      redeemBy
      timesRedeemed
      valid
    }
  }
`
export function useStripeCouponsQuery(
  baseOptions?: Apollo.QueryHookOptions<
    StripeCouponsQuery,
    StripeCouponsQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<StripeCouponsQuery, StripeCouponsQueryVariables>(
    StripeCouponsDocument,
    options,
  )
}
export function useStripeCouponsLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    StripeCouponsQuery,
    StripeCouponsQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<StripeCouponsQuery, StripeCouponsQueryVariables>(
    StripeCouponsDocument,
    options,
  )
}
export function useStripeCouponsSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        StripeCouponsQuery,
        StripeCouponsQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    StripeCouponsQuery,
    StripeCouponsQueryVariables
  >(StripeCouponsDocument, options)
}
export type StripeCouponsQueryHookResult = ReturnType<
  typeof useStripeCouponsQuery
>
export type StripeCouponsLazyQueryHookResult = ReturnType<
  typeof useStripeCouponsLazyQuery
>
export type StripeCouponsSuspenseQueryHookResult = ReturnType<
  typeof useStripeCouponsSuspenseQuery
>
export type StripeCouponsQueryResult = Apollo.QueryResult<
  StripeCouponsQuery,
  StripeCouponsQueryVariables
>
export const StripePricesDocument = gql`
  query stripePrices {
    stripePrices {
      id
      productId
      unitAmount
      currency
      interval
      trialPeriodDays
    }
  }
`
export function useStripePricesQuery(
  baseOptions?: Apollo.QueryHookOptions<
    StripePricesQuery,
    StripePricesQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<StripePricesQuery, StripePricesQueryVariables>(
    StripePricesDocument,
    options,
  )
}
export function useStripePricesLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    StripePricesQuery,
    StripePricesQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<StripePricesQuery, StripePricesQueryVariables>(
    StripePricesDocument,
    options,
  )
}
export function useStripePricesSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        StripePricesQuery,
        StripePricesQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<StripePricesQuery, StripePricesQueryVariables>(
    StripePricesDocument,
    options,
  )
}
export type StripePricesQueryHookResult = ReturnType<
  typeof useStripePricesQuery
>
export type StripePricesLazyQueryHookResult = ReturnType<
  typeof useStripePricesLazyQuery
>
export type StripePricesSuspenseQueryHookResult = ReturnType<
  typeof useStripePricesSuspenseQuery
>
export type StripePricesQueryResult = Apollo.QueryResult<
  StripePricesQuery,
  StripePricesQueryVariables
>
export const StripeProductsDocument = gql`
  query stripeProducts {
    stripeProducts {
      id
      name
      description
      defaultPriceId
    }
  }
`
export function useStripeProductsQuery(
  baseOptions?: Apollo.QueryHookOptions<
    StripeProductsQuery,
    StripeProductsQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<StripeProductsQuery, StripeProductsQueryVariables>(
    StripeProductsDocument,
    options,
  )
}
export function useStripeProductsLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    StripeProductsQuery,
    StripeProductsQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<StripeProductsQuery, StripeProductsQueryVariables>(
    StripeProductsDocument,
    options,
  )
}
export function useStripeProductsSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        StripeProductsQuery,
        StripeProductsQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    StripeProductsQuery,
    StripeProductsQueryVariables
  >(StripeProductsDocument, options)
}
export type StripeProductsQueryHookResult = ReturnType<
  typeof useStripeProductsQuery
>
export type StripeProductsLazyQueryHookResult = ReturnType<
  typeof useStripeProductsLazyQuery
>
export type StripeProductsSuspenseQueryHookResult = ReturnType<
  typeof useStripeProductsSuspenseQuery
>
export type StripeProductsQueryResult = Apollo.QueryResult<
  StripeProductsQuery,
  StripeProductsQueryVariables
>
