import * as Apollo from '@apollo/client'
import { gql } from '@apollo/client'
export type Maybe<T> = T | null
export type InputMaybe<T> = Maybe<T>
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K]
}
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]?: Maybe<T[SubKey]>
}
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]: Maybe<T[SubKey]>
}
export type MakeEmpty<
  T extends { [key: string]: unknown },
  K extends keyof T,
> = { [_ in K]?: never }
export type Incremental<T> =
  | T
  | {
      [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never
    }
const defaultOptions = {} as const
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string }
  String: { input: string; output: string }
  Boolean: { input: boolean; output: boolean }
  Int: { input: number; output: number }
  Float: { input: number; output: number }
  Date: { input: any; output: any }
  MongoID: { input: any; output: any }
}

export type CreateOneUserInput = {
  NotifyAICodingAssistantDate?: InputMaybe<Scalars['Date']['input']>
  authProvider: Scalars['String']['input']
  createdAt?: InputMaybe<Scalars['Date']['input']>
  email: Scalars['String']['input']
  name?: InputMaybe<Scalars['String']['input']>
  password?: InputMaybe<Scalars['String']['input']>
  registrationDate?: InputMaybe<Scalars['Date']['input']>
  requestedDeletionAt?: InputMaybe<Scalars['Date']['input']>
  salt?: InputMaybe<Scalars['String']['input']>
  teamId?: InputMaybe<Scalars['MongoID']['input']>
  updatedAt?: InputMaybe<Scalars['Date']['input']>
}

export type CreateOneUserPayload = {
  error?: Maybe<ErrorInterface>
  record?: Maybe<User>
  recordId?: Maybe<Scalars['MongoID']['output']>
}

export type ErrorInterface = {
  message?: Maybe<Scalars['String']['output']>
}

export type Mutation = {
  UserCreateOne?: Maybe<CreateOneUserPayload>
  requestPasswordReset?: Maybe<RequestPasswordResetPayload>
  resetPassword?: Maybe<ResetPasswordPayload>
}

export type MutationUserCreateOneArgs = {
  record: CreateOneUserInput
}

export type MutationRequestPasswordResetArgs = {
  input: RequestPasswordResetInput
}

export type MutationResetPasswordArgs = {
  input: ResetPasswordInput
}

export type Query = {
  validatePasswordResetToken?: Maybe<ValidatePasswordResetTokenPayload>
}

export type QueryValidatePasswordResetTokenArgs = {
  token: Scalars['String']['input']
}

export type RequestPasswordResetInput = {
  email: Scalars['String']['input']
}

export type RequestPasswordResetPayload = {
  message?: Maybe<Scalars['String']['output']>
  success?: Maybe<Scalars['Boolean']['output']>
}

export type ResetPasswordInput = {
  newPassword: Scalars['String']['input']
  token: Scalars['String']['input']
}

export type ResetPasswordPayload = {
  message?: Maybe<Scalars['String']['output']>
  success?: Maybe<Scalars['Boolean']['output']>
}

export type User = {
  NotifyAICodingAssistantDate?: Maybe<Scalars['Date']['output']>
  _id: Scalars['MongoID']['output']
  authProvider: Scalars['String']['output']
  createdAt?: Maybe<Scalars['Date']['output']>
  email: Scalars['String']['output']
  name?: Maybe<Scalars['String']['output']>
  password?: Maybe<Scalars['String']['output']>
  registrationDate?: Maybe<Scalars['Date']['output']>
  requestedDeletionAt?: Maybe<Scalars['Date']['output']>
  salt?: Maybe<Scalars['String']['output']>
  teamId?: Maybe<Scalars['MongoID']['output']>
  updatedAt?: Maybe<Scalars['Date']['output']>
}

export type ValidatePasswordResetTokenPayload = {
  email?: Maybe<Scalars['String']['output']>
  isValid?: Maybe<Scalars['Boolean']['output']>
}

export type UserCreateOneMutationVariables = Exact<{
  record: CreateOneUserInput
}>

export type UserCreateOneMutation = {
  UserCreateOne?: {
    recordId?: any | null
    record?: {
      authProvider: string
      email: string
      name?: string | null
      password?: string | null
      salt?: string | null
      teamId?: any | null
      registrationDate?: any | null
      NotifyAICodingAssistantDate?: any | null
      requestedDeletionAt?: any | null
      _id: any
      createdAt?: any | null
      updatedAt?: any | null
    } | null
  } | null
}

export type RequestPasswordResetMutationVariables = Exact<{
  input: RequestPasswordResetInput
}>

export type RequestPasswordResetMutation = {
  requestPasswordReset?: {
    success?: boolean | null
    message?: string | null
  } | null
}

export type ResetPasswordMutationVariables = Exact<{
  input: ResetPasswordInput
}>

export type ResetPasswordMutation = {
  resetPassword?: { success?: boolean | null; message?: string | null } | null
}

export type ValidatePasswordResetTokenQueryVariables = Exact<{
  token: Scalars['String']['input']
}>

export type ValidatePasswordResetTokenQuery = {
  validatePasswordResetToken?: {
    isValid?: boolean | null
    email?: string | null
  } | null
}

export const UserCreateOneDocument = gql`
  mutation UserCreateOne($record: CreateOneUserInput!) {
    UserCreateOne(record: $record) {
      recordId
      record {
        authProvider
        email
        name
        password
        salt
        teamId
        registrationDate
        NotifyAICodingAssistantDate
        requestedDeletionAt
        _id
        createdAt
        updatedAt
      }
    }
  }
`
export type UserCreateOneMutationFn = Apollo.MutationFunction<
  UserCreateOneMutation,
  UserCreateOneMutationVariables
>
export function useUserCreateOneMutation(
  baseOptions?: Apollo.MutationHookOptions<
    UserCreateOneMutation,
    UserCreateOneMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    UserCreateOneMutation,
    UserCreateOneMutationVariables
  >(UserCreateOneDocument, options)
}
export type UserCreateOneMutationHookResult = ReturnType<
  typeof useUserCreateOneMutation
>
export type UserCreateOneMutationResult =
  Apollo.MutationResult<UserCreateOneMutation>
export type UserCreateOneMutationOptions = Apollo.BaseMutationOptions<
  UserCreateOneMutation,
  UserCreateOneMutationVariables
>
export const RequestPasswordResetDocument = gql`
  mutation requestPasswordReset($input: RequestPasswordResetInput!) {
    requestPasswordReset(input: $input) {
      success
      message
    }
  }
`
export type RequestPasswordResetMutationFn = Apollo.MutationFunction<
  RequestPasswordResetMutation,
  RequestPasswordResetMutationVariables
>
export function useRequestPasswordResetMutation(
  baseOptions?: Apollo.MutationHookOptions<
    RequestPasswordResetMutation,
    RequestPasswordResetMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    RequestPasswordResetMutation,
    RequestPasswordResetMutationVariables
  >(RequestPasswordResetDocument, options)
}
export type RequestPasswordResetMutationHookResult = ReturnType<
  typeof useRequestPasswordResetMutation
>
export type RequestPasswordResetMutationResult =
  Apollo.MutationResult<RequestPasswordResetMutation>
export type RequestPasswordResetMutationOptions = Apollo.BaseMutationOptions<
  RequestPasswordResetMutation,
  RequestPasswordResetMutationVariables
>
export const ResetPasswordDocument = gql`
  mutation resetPassword($input: ResetPasswordInput!) {
    resetPassword(input: $input) {
      success
      message
    }
  }
`
export type ResetPasswordMutationFn = Apollo.MutationFunction<
  ResetPasswordMutation,
  ResetPasswordMutationVariables
>
export function useResetPasswordMutation(
  baseOptions?: Apollo.MutationHookOptions<
    ResetPasswordMutation,
    ResetPasswordMutationVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useMutation<
    ResetPasswordMutation,
    ResetPasswordMutationVariables
  >(ResetPasswordDocument, options)
}
export type ResetPasswordMutationHookResult = ReturnType<
  typeof useResetPasswordMutation
>
export type ResetPasswordMutationResult =
  Apollo.MutationResult<ResetPasswordMutation>
export type ResetPasswordMutationOptions = Apollo.BaseMutationOptions<
  ResetPasswordMutation,
  ResetPasswordMutationVariables
>
export const ValidatePasswordResetTokenDocument = gql`
  query validatePasswordResetToken($token: String!) {
    validatePasswordResetToken(token: $token) {
      isValid
      email
    }
  }
`
export function useValidatePasswordResetTokenQuery(
  baseOptions: Apollo.QueryHookOptions<
    ValidatePasswordResetTokenQuery,
    ValidatePasswordResetTokenQueryVariables
  > &
    (
      | { variables: ValidatePasswordResetTokenQueryVariables; skip?: boolean }
      | { skip: boolean }
    ),
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useQuery<
    ValidatePasswordResetTokenQuery,
    ValidatePasswordResetTokenQueryVariables
  >(ValidatePasswordResetTokenDocument, options)
}
export function useValidatePasswordResetTokenLazyQuery(
  baseOptions?: Apollo.LazyQueryHookOptions<
    ValidatePasswordResetTokenQuery,
    ValidatePasswordResetTokenQueryVariables
  >,
) {
  const options = { ...defaultOptions, ...baseOptions }
  return Apollo.useLazyQuery<
    ValidatePasswordResetTokenQuery,
    ValidatePasswordResetTokenQueryVariables
  >(ValidatePasswordResetTokenDocument, options)
}
export function useValidatePasswordResetTokenSuspenseQuery(
  baseOptions?:
    | Apollo.SkipToken
    | Apollo.SuspenseQueryHookOptions<
        ValidatePasswordResetTokenQuery,
        ValidatePasswordResetTokenQueryVariables
      >,
) {
  const options =
    baseOptions === Apollo.skipToken
      ? baseOptions
      : { ...defaultOptions, ...baseOptions }
  return Apollo.useSuspenseQuery<
    ValidatePasswordResetTokenQuery,
    ValidatePasswordResetTokenQueryVariables
  >(ValidatePasswordResetTokenDocument, options)
}
export type ValidatePasswordResetTokenQueryHookResult = ReturnType<
  typeof useValidatePasswordResetTokenQuery
>
export type ValidatePasswordResetTokenLazyQueryHookResult = ReturnType<
  typeof useValidatePasswordResetTokenLazyQuery
>
export type ValidatePasswordResetTokenSuspenseQueryHookResult = ReturnType<
  typeof useValidatePasswordResetTokenSuspenseQuery
>
export type ValidatePasswordResetTokenQueryResult = Apollo.QueryResult<
  ValidatePasswordResetTokenQuery,
  ValidatePasswordResetTokenQueryVariables
>
