import * as process from 'process'
export default {
  googleGaTag: process.env.NEXT_PUBLIC_GOOGLE_GA_TAG as string,
  dbPassword: process.env.NEXT_PUBLIC_DB_PASSWORD as string,
  dbUsername: process.env.NEXT_PUBLIC_DB_USERNAME as string,
  dbHost: process.env.NEXT_PUBLIC_DB_HOST as string,
  dbPort: process.env.NEXT_PUBLIC_DB_PORT as string,
  authSecret: process.env.NEXT_PUBLIC_AUTH_SECRET as string,
  googleId: process.env.NEXT_PUBLIC_AUTH_GOOGLE_ID as string,
  googleSecret: process.env.NEXT_PUBLIC_AUTH_GOOGLE_SECRET as string,
  appUrl: process.env.NEXT_PUBLIC_APP_URL as string,
  stripeSecretKey: process.env.NEXT_PUBLIC_STRIPE_SECRET_KEY as string,
  stripeWebhookSecret: process.env.NEXT_PUBLIC_STRIPE_WEBHOOK_SECRET as string,
  awsRegion: process.env.NEXT_PUBLIC_AWS_REGION as string,
  awsSesSourceEmail: process.env.NEXT_PUBLIC_AWS_SES_SOURCE_EMAIL as string,
}
