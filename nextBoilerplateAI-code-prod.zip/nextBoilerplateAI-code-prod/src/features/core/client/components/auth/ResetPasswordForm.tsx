'use client'
import { ArrowLeftIcon } from '@heroicons/react/20/solid'
import { useState } from 'react'

interface ResetPasswordUIProps {
  emailToDisplay: string
  loading: boolean
  error: string | undefined
  message: string | undefined
  onSubmit: (newPassword: string, confirmPassword: string) => Promise<void>
  onBack: () => void
}

export function ResetPasswordUI({
  emailToDisplay,
  loading,
  error,
  message,
  onSubmit,
  onBack,
}: ResetPasswordUIProps) {
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [localError, setLocalError] = useState<string | undefined>(undefined)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLocalError(undefined)

    if (newPassword !== confirmPassword) {
      setLocalError('Passwords do not match.')
      return
    }

    if (newPassword.length < 6) {
      setLocalError('Password must be at least 6 characters long.')
      return
    }

    await onSubmit(newPassword, confirmPassword)
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <div className="flex flex-1 flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm lg:w-96">
          <button
            onClick={onBack}
            className="mb-8 flex items-center text-gray-400 hover:text-white"
          >
            <ArrowLeftIcon className="mr-2 size-5" />
            Back
          </button>
          <div>
            <div className={'flex items-center'}>
              <img
                alt="Next Boilerplate ai logo"
                src="/LOGO_NBPAI.png"
                className="size-16"
              />{' '}
              <p className="max-w-lg pl-4 text-xl/7 font-medium text-[#D15052] sm:text-2xl/8">
                The Unfair Advantage for Solo Founders.
              </p>
            </div>
            <h2 className="mt-8 text-2xl/9 font-bold tracking-tight text-white">
              Reset Your Password
            </h2>
            <p className="mt-2 text-sm/6 text-gray-400">
              Setting new password for:{' '}
              <span className="font-semibold text-white">{emailToDisplay}</span>
            </p>
          </div>

          <div className="mt-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label
                  htmlFor="new-password"
                  className="block text-sm/6 font-medium text-gray-100"
                >
                  New Password
                </label>
                <div className="mt-2">
                  <input
                    id="new-password"
                    name="new-password"
                    type="password"
                    required
                    autoComplete="new-password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="confirm-password"
                  className="block text-sm/6 font-medium text-gray-100"
                >
                  Confirm New Password
                </label>
                <div className="mt-2">
                  <input
                    id="confirm-password"
                    name="confirm-password"
                    type="password"
                    required
                    autoComplete="new-password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                  />
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex w-full justify-center rounded-md bg-indigo-500 px-3 py-1.5 text-sm/6 font-semibold text-white hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500"
                >
                  {loading ? 'Resetting...' : 'Reset Password'}
                </button>
              </div>
              {(localError || error || message) && (
                <p
                  className={`text-center text-sm ${localError || error ? 'text-red-400' : 'text-green-400'}`}
                >
                  {localError || error || message}
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
      <div className="relative hidden w-0 flex-1 lg:block">
        <img
          alt=""
          src="https://images.unsplash.com/photo-1496917756835-20cb06e75b4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1908&q=80"
          className="absolute inset-0 size-full object-cover"
        />
      </div>
    </div>
  )
}
