import { clsx } from 'clsx'
import { useRouter } from 'next/navigation'

export function Button({
  children,
  className = '',
  onClick,
}: {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}) {
  const router = useRouter()

  const handleClick = () => {
    if (onClick) {
      onClick()
    }
  }

  return (
    <button
      onClick={handleClick}
      className={clsx(
        className,
        'flex-none rounded-md bg-indigo-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600',
      )}
    >
      {children}
    </button>
  )
}
