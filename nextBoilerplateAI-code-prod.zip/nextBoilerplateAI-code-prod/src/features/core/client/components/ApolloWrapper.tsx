'use client'
import type { SupportedFeature } from '@/features'
import { SUPPORTED_FEATURES } from '@/features'
import type { NormalizedCacheObject } from '@apollo/client'
import {
  ApolloClient,
  ApolloProvider,
  HttpLink,
  InMemoryCache,
} from '@apollo/client'
import React, { useMemo } from 'react'

export class PublicApolloClient extends ApolloClient<NormalizedCacheObject> {
  constructor(feature: SupportedFeature) {
    const httpLink = new HttpLink({
      uri: `/${feature}/public/api`,
      fetch,
    })

    super({
      cache: new InMemoryCache({ addTypename: false }),
      link: httpLink,
      defaultOptions: {
        watchQuery: { fetchPolicy: 'cache-and-network' },
      },
    })
  }
}

export class PrivateApolloClient extends ApolloClient<NormalizedCacheObject> {
  constructor(feature: SupportedFeature) {
    const httpLink = new HttpLink({
      uri: `/${feature}/api`,
      fetch,
    })

    super({
      cache: new InMemoryCache({ addTypename: false }),
      link: httpLink,
      defaultOptions: {
        watchQuery: { fetchPolicy: 'cache-and-network' },
      },
    })
  }
}

function resolveFeatureFromPath(
  pathname: string | undefined,
): SupportedFeature {
  if (!pathname) return SUPPORTED_FEATURES[0]
  const segments = pathname.split('/').filter(Boolean)
  return (SUPPORTED_FEATURES.find((f) => segments.includes(f)) ??
    SUPPORTED_FEATURES[0]) as SupportedFeature
}

export function ApolloWrapper({ children }: { children: React.ReactNode }) {
  const client = useMemo(() => {
    const dynamicFetch: typeof fetch = (_input, init) => {
      const pathname =
        typeof window !== 'undefined' ? window.location.pathname : ''
      const feature = resolveFeatureFromPath(pathname)
      const url = `/${feature}/api`
      return fetch(url, init)
    }

    return new ApolloClient<NormalizedCacheObject>({
      cache: new InMemoryCache({ addTypename: false }),
      link: new HttpLink({ uri: '/_placeholder', fetch: dynamicFetch }),
      defaultOptions: { watchQuery: { fetchPolicy: 'cache-and-network' } },
    })
  }, [])

  return <ApolloProvider client={client}>{children}</ApolloProvider>
}
