'use client'
import { SupportedFeature } from '@/features'
import { ResetPasswordUI } from '@/features/core/client/components/auth/ResetPasswordForm'
import { notFound, useRouter, useSearchParams } from 'next/navigation'
import { useEffect, useState } from 'react'

interface ResetPasswordPageProps {
  onSubmit: (token: string, newPassword: string) => Promise<string | undefined>
  onValidateToken: (
    token: string,
  ) => Promise<{ isValid?: boolean | null; email?: string | null } | undefined>
  loading: boolean
  error: string | undefined
  feature: SupportedFeature
}

export function ResetPasswordPage({
  onSubmit,
  onValidateToken,
  loading,
  feature,
  error: apolloError, // Renamed to avoid confusion
}: ResetPasswordPageProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const token = searchParams.get('token')

  const [emailToDisplay, setEmailToDisplay] = useState('Validating...')
  const [isValidToken, setIsValidToken] = useState(false)
  const [displayMessage, setDisplayMessage] = useState<string | undefined>(
    undefined,
  )
  const [isSuccessMessage, setIsSuccessMessage] = useState(false)

  useEffect(() => {
    if (!token) {
      notFound()
      return
    }

    const validate = async () => {
      const validationResult = await onValidateToken(token)
      if (validationResult?.isValid) {
        setIsValidToken(true)
        setEmailToDisplay(validationResult.email || 'Unknown User')
      } else {
        notFound()
      }
    }

    validate()
  }, [token, onValidateToken])

  const handleSubmit = async (newPassword: string, confirmPassword: string) => {
    if (!token) {
      setDisplayMessage('No reset token provided.')
      setIsSuccessMessage(false)
      return
    }

    const submitError = await onSubmit(token, newPassword)
    if (!submitError) {
      setDisplayMessage('Password reset successfully!')
      setIsSuccessMessage(true)
      setTimeout(() => {
        router.push(`/${feature}/auth/signin`)
      }, 3000)
    } else {
      setDisplayMessage(submitError)
      setIsSuccessMessage(false)
    }
  }

  if (!isValidToken) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-900">
        <p className="text-lg text-white">Validating token..</p>
      </div>
    )
  }

  // Determine the final error and message to pass to UI
  let finalErrorForUI: string | undefined
  let finalMessageForUI: string | undefined

  if (isSuccessMessage) {
    finalMessageForUI = displayMessage
    finalErrorForUI = undefined // Clear any Apollo errors if we have a success message
  } else {
    finalErrorForUI = apolloError || displayMessage // Apollo error or API error from onSubmit
    finalMessageForUI = undefined // No success message
  }

  return (
    <ResetPasswordUI
      emailToDisplay={emailToDisplay}
      loading={loading}
      error={finalErrorForUI}
      message={finalMessageForUI}
      onSubmit={handleSubmit}
      onBack={() => router.back()}
    />
  )
}
