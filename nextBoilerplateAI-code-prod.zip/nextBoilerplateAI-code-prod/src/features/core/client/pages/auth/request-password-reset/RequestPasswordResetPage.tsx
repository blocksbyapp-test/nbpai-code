'use client'
import { ArrowLeftIcon } from '@heroicons/react/20/solid'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

interface RequestPasswordResetPageProps {
  loading: boolean
  error: Error | undefined
  onSubmit: (email: string) => Promise<void>
}

export function RequestPasswordResetPage({
  loading,
  error,
  onSubmit,
}: RequestPasswordResetPageProps) {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [localMessage, setLocalMessage] = useState('')
  const [isEmailValid, setIsEmailValid] = useState(false)
  const [localError, setLocalError] = useState('')
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false)

  const SUCCESS_MESSAGE =
    'If an account with that email exists, a password reset link has been sent.'
  const GENERIC_ERROR_MESSAGE = 'Something went wrong, please try again.'

  useEffect(() => {
    if (email) {
      const valid = /^\S+@\S+\.\S+$/.test(email)
      setIsEmailValid(valid)
      if (!valid) {
        setLocalError('Please enter a valid email address.')
      } else {
        setLocalError('')
      }
    } else {
      setIsEmailValid(false)
      setLocalError('')
    }
  }, [email])

  useEffect(() => {
    if (hasAttemptedSubmit && !loading) {
      if (error) {
        setLocalMessage(GENERIC_ERROR_MESSAGE)
      } else {
        setLocalMessage(SUCCESS_MESSAGE)
      }
      setHasAttemptedSubmit(false)
    }
  }, [hasAttemptedSubmit, loading, error])

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value)
    setLocalMessage('')
    setHasAttemptedSubmit(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!isEmailValid) {
      setLocalError('Please enter a valid email address.')
      return
    }
    setLocalError('')
    setLocalMessage('')
    setHasAttemptedSubmit(true)
    await onSubmit(email)
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <div className="flex flex-1 flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm lg:w-96">
          <button
            onClick={() => router.back()}
            className="mb-8 flex items-center text-gray-400 hover:text-white"
          >
            <ArrowLeftIcon className="mr-2 size-5" />
            Back
          </button>
          <div>
            <div className={'flex items-center'}>
              <img
                alt="Next Boilerplate ai logo"
                src="/LOGO_NBPAI.png"
                className="size-16"
              />{' '}
              <p className="max-w-lg pl-4 text-xl/7 font-medium text-[#D15052] sm:text-2xl/8">
                The Unfair Advantage for Solo Founders.
              </p>
            </div>
            <h2 className="mt-8 text-2xl/9 font-bold tracking-tight text-white">
              Request Password Reset
            </h2>
            <p className="mt-2 text-sm/6 text-gray-400">
              Enter your email to receive a password reset link.
            </p>
          </div>

          <div className="mt-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label
                  htmlFor="email"
                  className="block text-sm/6 font-medium text-gray-100"
                >
                  Email address
                </label>
                <div className="mt-2">
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={handleEmailChange}
                    className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                  />
                </div>
                {localError && (
                  <p className="mt-2 text-sm text-red-400">{localError}</p>
                )}
              </div>

              <div>
                <button
                  type="submit"
                  disabled={loading || !isEmailValid}
                  className="flex w-full justify-center rounded-md bg-indigo-500 px-3 py-1.5 text-sm/6 font-semibold text-white hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {loading ? 'Sending...' : 'Send Reset Link'}
                </button>
              </div>
              {localMessage && (
                <p
                  className={`text-center text-sm ${error ? 'text-red-400' : 'text-green-400'}`}
                >
                  {localMessage}
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
      <div className="relative hidden w-0 flex-1 lg:block">
        <img
          alt=""
          src="https://images.unsplash.com/photo-1496917756835-20cb06e75b4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1908&q=80"
          className="absolute inset-0 size-full object-cover"
        />
      </div>
    </div>
  )
}
