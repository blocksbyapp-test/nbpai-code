'use client'
import { SupportedFeature } from '@/features'
import { ArrowLeftIcon } from '@heroicons/react/20/solid'
import { signIn, useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

interface SignInPageProps {
  onSubmitSignIn: (
    email: string,
    password: string,
  ) => Promise<string | undefined>
  onSubmitRegister: (
    name: string,
    email: string,
    password: string,
  ) => Promise<string | undefined>
  loading: boolean
  error: string | undefined
  feature?: SupportedFeature
}

export function SignInPage({
  onSubmitSignIn,
  onSubmitRegister,
  loading,
  error,
  feature,
}: SignInPageProps) {
  const { data: session } = useSession()
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [isRegistering, setIsRegistering] = useState(false)

  useEffect(() => {
    if (session) {
      router.push(`/${feature || ''}`)
    }
  }, [session, router, feature])

  const handleCredentialSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (isRegistering) {
      await onSubmitRegister(name, email, password)
    } else {
      await onSubmitSignIn(email, password)
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <div className="flex flex-1 flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm lg:w-96">
          <button
            onClick={() => router.push('/')}
            className="mb-8 flex items-center text-gray-400 hover:text-white"
          >
            <ArrowLeftIcon className="mr-2 size-5" />
            Back
          </button>
          <div>
            <div className={'flex items-center'}>
              <img
                alt="Next Boilerplate ai logo"
                src="/LOGO_NBPAI.png"
                className="size-16"
              />{' '}
              <p className="max-w-lg pl-4 text-xl/7 font-medium text-[#D15052] sm:text-2xl/8">
                The Unfair Advantage for Solo Founders.
              </p>
            </div>
            <h2 className="mt-8 text-2xl/9 font-bold tracking-tight text-white">
              {isRegistering
                ? 'Create your account'
                : 'Sign in to your account'}
            </h2>
            <p className="mt-2 text-sm/6 text-gray-400">
              {isRegistering ? 'Already have an account?' : 'Not a member?'}{' '}
              <button
                onClick={() => setIsRegistering(!isRegistering)}
                className="font-semibold text-indigo-400 hover:text-indigo-300"
              >
                {isRegistering ? 'Sign in' : 'Register with email and password'}
                {''}
              </button>
            </p>
          </div>

          <div className="mt-10">
            <div>
              <form onSubmit={handleCredentialSubmit} className="space-y-6">
                {isRegistering && (
                  <div>
                    <label
                      htmlFor="name"
                      className="block text-sm/6 font-medium text-gray-100"
                    >
                      Name
                    </label>
                    <div className="mt-2">
                      <input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                      />
                    </div>
                  </div>
                )}
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm/6 font-medium text-gray-100"
                  >
                    Email address
                  </label>
                  <div className="mt-2">
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      autoComplete="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="password"
                    className="block text-sm/6 font-medium text-gray-100"
                  >
                    Password
                  </label>
                  <div className="mt-2">
                    <input
                      id="password"
                      name="password"
                      type="password"
                      required
                      autoComplete={
                        isRegistering ? 'new-password' : 'current-password'
                      }
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="block w-full rounded-md bg-white/5 px-3 py-1.5 text-base text-white outline outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                    />
                  </div>
                </div>

                {!isRegistering && (
                  <div className="flex items-center justify-between">
                    <div className="flex gap-3">
                      <div className="flex h-6 shrink-0 items-center">
                        <div className="group grid size-4 grid-cols-1"></div>
                      </div>
                    </div>
                    <div className="text-sm/6">
                      <a
                        href={`/${feature}/auth/request-password-reset`}
                        className="font-semibold text-indigo-400 hover:text-indigo-300"
                      >
                        Forgot password?
                      </a>
                    </div>
                  </div>
                )}

                <div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex w-full justify-center rounded-md bg-indigo-500 px-3 py-1.5 text-sm/6 font-semibold text-white hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500"
                  >
                    {loading
                      ? 'Loading...'
                      : isRegistering
                        ? 'Register'
                        : 'Sign in'}
                  </button>
                </div>
                {error && (
                  <p className="text-center text-sm text-red-400">{error}</p>
                )}

                <p className="mt-4 text-center text-sm/6 text-gray-400">
                  By continuing, you confirm you agree to our{' '}
                  <a
                    href="/privacy-policy"
                    className="font-semibold text-indigo-400 hover:text-indigo-300"
                  >
                    Privacy Policy
                  </a>{' '}
                  and{' '}
                  <a
                    href="/terms-of-use"
                    className="font-semibold text-indigo-400 hover:text-indigo-300"
                  >
                    Terms of Use
                  </a>
                  .
                </p>
              </form>
            </div>

            <div className="mt-10">
              <div className="relative">
                <div
                  aria-hidden="true"
                  className="absolute inset-0 flex items-center"
                >
                  <div className="w-full border-t border-gray-700" />
                </div>
                <div className="relative flex justify-center text-sm/6 font-medium">
                  <span className="bg-gray-900 px-6 text-gray-300">
                    Or continue with
                  </span>
                </div>
              </div>

              <div className="mt-6">
                <button
                  onClick={() => signIn('google')}
                  className="flex w-full items-center justify-center gap-3 rounded-md bg-white/10 px-3 py-2 text-sm font-semibold text-white ring-1 ring-inset ring-white/5 hover:bg-white/20 focus-visible:ring-transparent"
                >
                  <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    className="h-5 w-5"
                  >
                    <path
                      d="M12.0003 4.75C13.7703 4.75 15.3553 5.36002 16.6053 6.54998L20.0303 3.125C17.9502 1.19 15.2353 0 12.0003 0C7.31028 0 3.25527 2.69 1.28027 6.60998L5.27028 9.70498C6.21525 6.86002 8.87028 4.75 12.0003 4.75Z"
                      fill="#EA4335"
                    />
                    <path
                      d="M23.49 12.275C23.49 11.49 23.415 10.73 23.3 10H12V14.51H18.47C18.18 15.99 17.34 17.25 16.08 18.1L19.945 21.1C22.2 19.01 23.49 15.92 23.49 12.275Z"
                      fill="#4285F4"
                    />
                    <path
                      d="M5.26498 14.2949C5.02498 13.5699 4.88501 12.7999 4.88501 11.9999C4.88501 11.1999 5.01998 10.4299 5.26498 9.7049L1.275 6.60986C0.46 8.22986 0 10.0599 0 11.9999C0 13.9399 0.46 15.7699 1.28 17.3899L5.26498 14.2949Z"
                      fill="#FBBC05"
                    />
                    <path
                      d="M12.0004 24.0001C15.2404 24.0001 17.9654 22.935 19.9454 21.095L16.0804 18.095C15.0054 18.82 13.6204 19.245 12.0004 19.245C8.8704 19.245 6.21537 17.135 5.2654 14.29L1.27539 17.385C3.25539 21.31 7.3104 24.0001 12.0004 24.0001Z"
                      fill="#34A853"
                    />
                  </svg>
                  <span className="text-sm/6 font-semibold">Google</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="relative hidden w-0 flex-1 lg:block">
        <img
          alt=""
          src="https://images.unsplash.com/photo-1496917756835-20cb06e75b4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1908&q=80"
          className="absolute inset-0 size-full object-cover"
        />
      </div>
    </div>
  )
}
