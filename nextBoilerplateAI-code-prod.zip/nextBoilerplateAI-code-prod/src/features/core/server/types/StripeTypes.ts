import {
  GraphQLBoolean,
  GraphQLFloat,
  GraphQLInt,
  GraphQLNonNull,
  GraphQLObjectType,
  GraphQLString,
} from 'graphql'
import { GraphQLDate } from 'graphql-compose'

export const StripePriceType = new GraphQLObjectType({
  name: 'StripePrice',
  fields: {
    id: { type: GraphQLString },
    productId: { type: GraphQLString },
    unitAmount: { type: GraphQLInt },
    currency: { type: GraphQLString },
    interval: { type: GraphQLString },
    trialPeriodDays: { type: GraphQLInt },
  },
})

export const StripeProductType = new GraphQLObjectType({
  name: 'StripeProduct',
  fields: {
    id: { type: GraphQLString },
    name: { type: GraphQLString },
    description: { type: GraphQLString },
    defaultPriceId: { type: GraphQLString },
  },
})

export const CreateCheckoutSessionPayload = new GraphQLObjectType({
  name: 'CreateCheckoutSessionPayload',
  fields: {
    url: { type: GraphQLString },
    error: { type: GraphQLString },
  },
})

export const StripeCouponType = new GraphQLObjectType({
  name: 'StripeCoupon',
  fields: {
    id: { type: GraphQLString },
    name: { type: GraphQLString },
    percentOff: { type: GraphQLFloat },
    amountOff: { type: GraphQLInt },
    currency: { type: GraphQLString },
    duration: { type: GraphQLString },
    durationInMonths: { type: GraphQLInt },
    maxRedemptions: { type: GraphQLInt },
    redeemBy: { type: GraphQLDate },
    timesRedeemed: { type: GraphQLInt },
    valid: { type: GraphQLBoolean },
  },
})
export const StripeCheckoutSessionDetailsType = new GraphQLObjectType({
  name: 'StripeCheckoutSessionDetails',
  fields: {
    id: { type: new GraphQLNonNull(GraphQLString) },
    amountTotal: { type: GraphQLInt },
    currency: { type: GraphQLString },
    coupon: { type: GraphQLString },
    productId: { type: GraphQLString },
    productName: { type: GraphQLString },
  },
})
