import {
  GraphQLBoolean,
  GraphQLInputObjectType,
  GraphQLNonNull,
  GraphQLObjectType,
  GraphQLString,
} from 'graphql'

export const RequestPasswordResetInput = new GraphQLInputObjectType({
  name: 'RequestPasswordResetInput',
  fields: {
    email: { type: new GraphQLNonNull(GraphQLString) },
  },
})

export const RequestPasswordResetPayload = new GraphQLObjectType({
  name: 'RequestPasswordResetPayload',
  fields: {
    success: { type: GraphQLBoolean },
    message: { type: GraphQLString },
  },
})

export const ResetPasswordInput = new GraphQLInputObjectType({
  name: 'ResetPasswordInput',
  fields: {
    token: { type: new GraphQLNonNull(GraphQLString) },
    newPassword: { type: new GraphQLNonNull(GraphQLString) },
  },
})

export const ResetPasswordPayload = new GraphQLObjectType({
  name: 'ResetPasswordPayload',
  fields: {
    success: { type: GraphQLBoolean },
    message: { type: GraphQLString },
  },
})

export const ValidatePasswordResetTokenPayload = new GraphQLObjectType({
  name: 'ValidatePasswordResetTokenPayload',
  fields: {
    isValid: { type: GraphQLBoolean },
    email: { type: GraphQLString },
  },
})
