import type { GraphQLResolveInfo } from 'graphql/type/definition'

export type Resolver<TRes, TArgs = { [argName: string]: any }> = (
  source: any,
  args: TArgs,
  context: { userId: string; isAuth: boolean; sourceIp: string },
  info: GraphQLResolveInfo,
) => Promise<TRes>
