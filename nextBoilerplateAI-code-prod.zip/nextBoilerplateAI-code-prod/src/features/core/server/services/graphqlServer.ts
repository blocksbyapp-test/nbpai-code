import { connectDB } from '@/features/core/server/services/mongoose'
import { ApolloServer } from '@apollo/server'
import { startServerAndCreateNextHandler } from '@as-integrations/next'
import type { ObjectTypeComposerFieldConfigMapDefinition } from 'graphql-compose'
import { SchemaComposer } from 'graphql-compose'
import type { ObjectTypeComposerWithMongooseResolvers } from 'graphql-compose-mongoose'
import { NextRequest } from 'next/server'

export const createGraphqlServer = ({
  mutation,
  models,
  query,
}: {
  query?: ObjectTypeComposerFieldConfigMapDefinition<any, any>
  mutation?: ObjectTypeComposerFieldConfigMapDefinition<any, any>
  models?: ReadonlyArray<ObjectTypeComposerWithMongooseResolvers<any>>
}) => {
  const schemaComposer = new SchemaComposer()
  if (query) {
    schemaComposer.Query.addFields(query)
  }
  if (mutation) {
    schemaComposer.Mutation.addFields(mutation)
  }

  const server = new ApolloServer({
    schema: schemaComposer.buildSchema(),
  })

  const handler = startServerAndCreateNextHandler(server, {
    context: async (req: NextRequest) => {
      await connectDB()
      return {}
    },
  })

  async function POST(request: NextRequest) {
    return handler(request)
  }

  async function GET(request: NextRequest) {
    return handler(request)
  }
  const dynamic = 'force-dynamic' as const
  return { POST, GET, dynamic }
}
