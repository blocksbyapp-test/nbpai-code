import config from '@/features/core/config'
import PasswordResetEmail from '@/templates/PasswordResetEmail.json'
import RegistrationEmail from '@/templates/RegistrationEmail.json'
import {
  SESv2Client,
  SendEmailCommand,
  SendEmailCommandInput,
} from '@aws-sdk/client-sesv2'

export const emailTemplates = {
  RegistrationEmail,
  PasswordResetEmail,
} as const

const sesClient = new SESv2Client({ region: config.awsRegion })

export async function sendEmail(
  templateName: string,
  templateData: Record<string, any>,
  recipientEmail: string,
) {
  if (!config.awsSesSourceEmail) {
    console.warn(' AWS_SES_SOURCE_EMAIL is not configured. Skipping email send')
    return
  }

  const params: SendEmailCommandInput = {
    FromEmailAddress: config.awsSesSourceEmail,
    Destination: {
      ToAddresses: [recipientEmail],
    },
    Content: {
      Template: {
        TemplateName: templateName,
        TemplateData: JSON.stringify(templateData),
      },
    },
  }

  try {
    const command = new SendEmailCommand(params)
    await sesClient.send(command)
    console.log(
      `Email sent successfully using template ${templateName} to ${recipientEmail}`,
    )
  } catch (error) {
    console.error(
      `Error sending email using template ${templateName} to ${recipientEmail}:`,
      error,
    )
    throw error
  }
}

function render(template: string, data: Record<string, unknown>): string {
  return template.replace(/{{\s*([\w.]+)\s*}}/g, (_: string, key: string) => {
    const val = key.split('.').reduce<unknown>((o: unknown, k: string) => {
      if (o == null || typeof o !== 'object') return undefined
      return (o as Record<string, unknown>)[k]
    }, data as unknown)

    return val == null ? '' : String(val)
  })
}

export async function sendEmailFromLocalTemplate(
  templateName: keyof typeof emailTemplates,
  templateData: Record<string, any>,
  recipientEmail: string,
) {
  if (!config.awsSesSourceEmail) {
    console.warn(
      'NEXT_PUBLIC_AWS_SES_SOURCE_EMAIL is not configured. Skipping email send',
    )
    return
  }

  const tpl = emailTemplates[templateName].Template

  const subject = render(tpl.SubjectPart, templateData)
  const html =
    'HtmlPart' in tpl && tpl.HtmlPart
      ? render(tpl.HtmlPart, templateData)
      : undefined
  const text = tpl.TextPart ? render(tpl.TextPart, templateData) : undefined

  const params: SendEmailCommandInput = {
    FromEmailAddress: config.awsSesSourceEmail,
    Destination: { ToAddresses: [recipientEmail] },
    Content: {
      Simple: {
        Subject: { Data: subject },
        Body: {
          ...(html ? { Html: { Data: html } } : {}),
          ...(text ? { Text: { Data: text } } : {}),
        },
      },
    },
  }

  try {
    await sesClient.send(new SendEmailCommand(params))
    console.log(
      `Email sent (local template ${templateName}) to ${recipientEmail}`,
    )
  } catch (error) {
    console.error(
      `Error sending local-template email ${templateName} → ${recipientEmail}:`,
      error,
    )
    throw error
  }
}
