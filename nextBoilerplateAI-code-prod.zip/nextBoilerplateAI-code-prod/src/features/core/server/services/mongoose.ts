import type { SupportedFeature } from '@/features'
import Config from '@/features/core/config'
import type { ObjectTypeComposerWithMongooseResolvers } from 'graphql-compose-mongoose'
import { composeMongoose } from 'graphql-compose-mongoose'
import mongoose, {
  AnyKeys,
  FilterQuery,
  HydratedDocument,
  InferSchemaType,
  Model,
  ObtainSchemaGeneric,
} from 'mongoose'

import process from 'process'

const { dbPassword, dbUsername, dbHost, dbPort } = Config

const connectionDatabaseStringProd = `mongodb+srv://${dbUsername}:${dbPassword}@${dbHost}?retryWrites=true&w=majority`
const connectionDatabaseStringDev = `mongodb://${dbHost}:${dbPort}/`
const connectionDatabaseString =
  process.env.NODE_ENV === 'production'
    ? connectionDatabaseStringProd
    : connectionDatabaseStringDev

export async function connectDB() {
  if (mongoose.connection.readyState === 1) {
    return
  }

  try {
    await mongoose.connect(connectionDatabaseString)
    console.log('Database connected:', connectionDatabaseString)
  } catch (error) {
    console.error('Database connection error:', error)
  }
}

export function createMongooseModel<
  TSchema extends mongoose.Schema,
  K extends string,
>(databaseName: SupportedFeature, modelName: K, schema: TSchema) {
  type SchemaType = InferSchemaType<TSchema>

  const model = mongoose.connection
    .useDb(databaseName)
    .model<SchemaType>(modelName, schema)

  const typeComposer = composeMongoose(model as any, {})
  typeComposer.setExtension('mongooseModel', model)

  const { queries } = registerModelQueries<K>(typeComposer)
  const { mutations } = registerModelMutations<K>(typeComposer)
  return {
    [modelName]: model,
    [`${modelName}TC`]: typeComposer,
    [`${modelName}Queries`]: queries,
    [`${modelName}Mutations`]: mutations,
  } as Record<
    K,
    mongoose.Model<
      SchemaType,
      ObtainSchemaGeneric<TSchema, 'TQueryHelpers'>,
      ObtainSchemaGeneric<TSchema, 'TInstanceMethods'>,
      ObtainSchemaGeneric<TSchema, 'TVirtuals'>
    > &
      ObtainSchemaGeneric<TSchema, 'TStaticMethods'>
  > &
    Record<
      `${K}TC`,
      ObjectTypeComposerWithMongooseResolvers<
        mongoose.Document<SchemaType>,
        any
      >
    > &
    Record<`${K}Queries`, typeof queries> &
    Record<`${K}Mutations`, typeof mutations>
}

type QueryKeys<K extends string> =
  | `${K}ById`
  | `${K}ByIds`
  | `${K}One`
  | `${K}Many`
  | `${K}DataLoader`
  | `${K}DataLoaderMany`
  | `${K}ByIdLean`
  | `${K}ByIdsLean`
  | `${K}OneLean`
  | `${K}ManyLean`
  | `${K}DataLoaderLean`
  | `${K}DataLoaderManyLean`
  | `${K}Count`
  | `${K}Connection`
  | `${K}Pagination`

type MutationKeys<K extends string> =
  | `${K}CreateOne`
  | `${K}CreateMany`
  | `${K}UpdateById`
  | `${K}UpdateOne`
  | `${K}UpdateMany`
  | `${K}RemoveById`
  | `${K}RemoveOne`
  | `${K}RemoveMany`

export function registerModelMutations<K extends string>(
  modelTC: ObjectTypeComposerWithMongooseResolvers<any>,
) {
  const allMutations = {
    [`${modelTC.getType().name}CreateOne`]: modelTC.mongooseResolvers.createOne(
      { disableErrorField: true },
    ),
    [`${modelTC.getType().name}CreateMany`]:
      modelTC.mongooseResolvers.createMany(),
    [`${modelTC.getType().name}UpdateById`]:
      modelTC.mongooseResolvers.updateById(),
    [`${modelTC.getType().name}UpdateOne`]:
      modelTC.mongooseResolvers.updateOne(),
    [`${modelTC.getType().name}UpdateMany`]:
      modelTC.mongooseResolvers.updateMany(),
    [`${modelTC.getType().name}RemoveById`]:
      modelTC.mongooseResolvers.removeById(),
    [`${modelTC.getType().name}RemoveOne`]:
      modelTC.mongooseResolvers.removeOne(),
    [`${modelTC.getType().name}RemoveMany`]:
      modelTC.mongooseResolvers.removeMany(),
  } as const

  type AllMutationsType = typeof allMutations

  return {
    mutations<Keys extends MutationKeys<K>>(select: Keys[]) {
      const picked: { [P in Keys]?: AllMutationsType[P] } = {}
      for (const key of select) {
        picked[key] = allMutations[key]
      }
      return picked as Pick<AllMutationsType, Keys>
    },
  }
}

export function registerModelQueries<K extends string>(
  modelTC: ObjectTypeComposerWithMongooseResolvers<any>,
) {
  const allQueries = {
    [`${modelTC.getType().name}ById`]: modelTC.mongooseResolvers.findById(),
    [`${modelTC.getType().name}ByIds`]: modelTC.mongooseResolvers.findByIds(),
    [`${modelTC.getType().name}One`]: modelTC.mongooseResolvers.findOne(),
    [`${modelTC.getType().name}Many`]: modelTC.mongooseResolvers.findMany(),
    [`${modelTC.getType().name}DataLoader`]:
      modelTC.mongooseResolvers.dataLoader(),
    [`${modelTC.getType().name}DataLoaderMany`]:
      modelTC.mongooseResolvers.dataLoaderMany(),
    [`${modelTC.getType().name}ByIdLean`]: modelTC.mongooseResolvers.findById({
      lean: true,
    }),
    [`${modelTC.getType().name}ByIdsLean`]: modelTC.mongooseResolvers.findByIds(
      { lean: true },
    ),
    [`${modelTC.getType().name}OneLean`]: modelTC.mongooseResolvers.findOne({
      lean: true,
    }),
    [`${modelTC.getType().name}ManyLean`]: modelTC.mongooseResolvers.findMany({
      lean: true,
    }),
    [`${modelTC.getType().name}DataLoaderLean`]:
      modelTC.mongooseResolvers.dataLoader({ lean: true }),
    [`${modelTC.getType().name}DataLoaderManyLean`]:
      modelTC.mongooseResolvers.dataLoaderMany({ lean: true }),
    [`${modelTC.getType().name}Count`]: modelTC.mongooseResolvers.count(),
    [`${modelTC.getType().name}Connection`]:
      modelTC.mongooseResolvers.connection(),
    [`${modelTC.getType().name}Pagination`]:
      modelTC.mongooseResolvers.pagination(),
  } as const

  type AllQueriesType = typeof allQueries

  return {
    queries<Keys extends QueryKeys<K>>(select: Keys[]) {
      const picked: { [P in Keys]?: AllQueriesType[P] } = {}
      for (const key of select) {
        picked[key] = allQueries[key]
      }
      return picked as Pick<AllQueriesType, Keys>
    },
  }
}

export type CreateIfNotExistsResult<T> = {
  doc: HydratedDocument<T>
  created: boolean
}

export async function createIfNotExists<T>(
  Model: Model<T>,
  find: FilterQuery<T>,
  setOnInsert: AnyKeys<T>,
  onCreated?: (doc: HydratedDocument<T>) => void | Promise<void>,
): Promise<CreateIfNotExistsResult<T>> {
  const raw = await Model.findOneAndUpdate(
    find,
    { $setOnInsert: setOnInsert as any },
    {
      upsert: true,
      new: true,
      rawResult: true,
    },
  )

  const value = (raw as any)?.value ?? raw
  if (!value) {
    const existing = await Model.findOne(find)
    if (!existing) {
      throw new Error('createIfNotExists: Document not found after upsert.')
    }
    return { doc: existing as HydratedDocument<T>, created: false }
  }

  const created =
    Boolean((raw as any)?.lastErrorObject?.upserted) ||
    (raw as any)?.lastErrorObject?.updatedExisting === false

  const doc: HydratedDocument<T> = value

  if (created && onCreated) {
    await onCreated(doc)
  }

  return { doc, created }
}
