import { SupportedFeature } from '@/features'
import config from '@/features/core/config'
import { passwordResetTokenSchema } from '@/features/core/server/models/PasswordResetToken'
import { sendEmailFromLocalTemplate } from '@/features/core/server/services/emailService'
import {
  RequestPasswordResetInput,
  RequestPasswordResetPayload,
  ResetPasswordInput,
  ResetPasswordPayload,
  ValidatePasswordResetTokenPayload,
} from '@/features/core/server/types/auth/PasswordResetTypes'
import { Resolver } from '@/features/core/server/types/types'
import crypto from 'crypto'
import { GraphQLNonNull, GraphQLString } from 'graphql'
import mongoose, { InferSchemaType } from 'mongoose'
import { coreUserSchema } from '../models/User'

export const createUserPasswordOperations = (
  MongooseUser: mongoose.Model<InferSchemaType<typeof coreUserSchema>>,
  PasswordResetToken: mongoose.Model<
    InferSchemaType<typeof passwordResetTokenSchema>
  >,
  feature: SupportedFeature,
) => {
  const requestPasswordResetResolver: Resolver<any, any> = async (
    parent,
    args,
  ) => {
    try {
      const { email } = args.input

      const user = await MongooseUser.findOne({ email })

      if (!user) {
        return {
          success: true,
          message:
            'If an account with that email exists, a password reset link has been sent.',
        }
      }

      const token = crypto.randomBytes(32).toString('hex')
      const expires = new Date(Date.now() + 3600000)

      await PasswordResetToken.updateMany({ userId: user._id }, { used: true })

      await PasswordResetToken.create({
        userId: user._id,
        token,
        expires,
      })

      const resetLink = `${config.appUrl}${feature}/auth/reset-password?token=${token}`
      try {
        await sendEmailFromLocalTemplate(
          'PasswordResetEmail',
          {
            name: user.name || user.email,
            resetLink,
          },
          user.email,
        )
      } catch (emailError) {
        console.error('Error sending password reset email:', emailError)
      }

      return {
        success: true,
        message:
          'If an account with that email exists, a password reset link has been sent.',
      }
    } catch (err: any) {
      console.error('Error requesting password reset:', err)
      return {
        success: false,
        message: 'Failed to process your request. Please try again later.',
      }
    }
  }

  const resetPasswordResolver: Resolver<any, any> = async (parent, args) => {
    try {
      const { token, newPassword } = args.input

      const resetToken = await PasswordResetToken.findOne({ token })

      if (!resetToken || resetToken.used || resetToken.expires < new Date()) {
        return { success: false, message: 'Invalid or expired reset token.' }
      }

      const user = await MongooseUser.findById(resetToken.userId)

      if (!user) {
        return { success: false, message: 'User not found.' }
      }

      user.password = newPassword
      await user.save()

      resetToken.used = true
      await resetToken.save()

      return { success: true, message: 'Password has been reset successfully.' }
    } catch (err: any) {
      console.error('Error resetting password:', err)
      return {
        success: false,
        message: err.message || 'An unexpected error occurred.',
      }
    }
  }

  const validatePasswordResetTokenResolver: Resolver<any, any> = async (
    parent,
    args,
  ) => {
    try {
      const { token } = args

      const resetToken = await PasswordResetToken.findOne({ token })

      if (!resetToken || resetToken.used || resetToken.expires < new Date()) {
        return { isValid: false, email: null }
      }

      const user = await MongooseUser.findById(resetToken.userId)

      if (!user) {
        return { isValid: false, email: null }
      }

      return { isValid: true, email: user.email }
    } catch (err: any) {
      console.error('Error validating password reset token:', err)
      return { isValid: false, email: null }
    }
  }

  return {
    query: {
      validatePasswordResetToken: {
        type: ValidatePasswordResetTokenPayload,
        args: { token: { type: new GraphQLNonNull(GraphQLString) } },
        resolve: validatePasswordResetTokenResolver,
      },
    },
    mutation: {
      requestPasswordReset: {
        type: RequestPasswordResetPayload,
        args: {
          input: { type: new GraphQLNonNull(RequestPasswordResetInput) },
        },
        resolve: requestPasswordResetResolver,
      },
      resetPassword: {
        type: ResetPasswordPayload,
        args: { input: { type: new GraphQLNonNull(ResetPasswordInput) } },
        resolve: resetPasswordResolver,
      },
    },
  }
}
