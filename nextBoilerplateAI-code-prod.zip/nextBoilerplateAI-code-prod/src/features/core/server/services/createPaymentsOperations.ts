import { SupportedFeature } from '@/features'
import { auth } from '@/features/core/server/services/auth'
import {
  createCheckoutSession,
  getStripeCoupons,
  getStripeInstance,
  getStripePrices,
  getStripeProducts,
} from '@/features/core/server/stripe'
import { StripeDatabaseAdapters } from '@/features/core/server/types'
import {
  CreateCheckoutSessionPayload,
  StripeCheckoutSessionDetailsType,
  StripeCouponType,
  StripePriceType,
  StripeProductType,
} from '@/features/core/server/types/StripeTypes'
import { Resolver } from '@/features/core/server/types/types'
import {
  GraphQLList,
  GraphQLNonNull,
  GraphQLObjectType,
  GraphQLString,
} from 'graphql'
import { GraphQLDate } from 'graphql-compose'

export const PurchasedProductType = new GraphQLObjectType({
  name: 'PurchasedProduct',
  fields: {
    productId: { type: GraphQLString },
    couponId: { type: GraphQLString },
    purchaseDate: { type: GraphQLDate },
  },
})

export const createPaymentsOperations = (
  stripeDatabaseAdapters: StripeDatabaseAdapters,
  feature: SupportedFeature,
) => {
  const stripeCouponsResolver: Resolver<any, any> = async () => {
    try {
      const session = await auth()
      if (!session?.user?.email) return []
      return getStripeCoupons() || []
    } catch (error: any) {
      console.error('stripeCouponsResolver error:', JSON.stringify(error))
      throw new Error('Failed to retrieve coupons.')
    }
  }

  const createCheckoutSessionResolver: Resolver<any, any> = async (
    source,
    { priceId, couponId },
    context,
  ) => {
    try {
      const user = await stripeDatabaseAdapters.getUserFn()
      if (!user) {
        return { error: 'Authentication required' }
      }
      const team = await stripeDatabaseAdapters.getTeamFn()
      if (!team) {
        return { error: 'User is not associated with a team.' }
      }
      const url = await createCheckoutSession(
        team,
        priceId,
        user._id,
        stripeDatabaseAdapters,
        feature,
        couponId,
      )
      return { url }
    } catch (error: any) {
      console.error(
        'createCheckoutSessionResolver error:',
        JSON.stringify(error),
      )
      return {
        error: error.message || 'Failed to create checkout session.',
      }
    }
  }

  const currentUserStripeSubscriptionIdResolver: Resolver<
    any,
    any
  > = async () => {
    try {
      const team = await stripeDatabaseAdapters.getTeamFn()
      return team?.stripeSubscriptionId || null
    } catch (error: any) {
      console.error(
        'currentUserStripeSubscriptionIdResolver error:',
        JSON.stringify(error),
      )
      throw new Error('Failed to retrieve user subscription ID.')
    }
  }

  const currentUserSubscriptionStatusResolver: Resolver<
    any,
    any
  > = async () => {
    try {
      const team = await stripeDatabaseAdapters.getTeamFn()
      return team?.subscriptionStatus || null
    } catch (error: any) {
      console.error(
        'currentUserSubscriptionStatusResolver error:',
        JSON.stringify(error),
      )
      throw new Error('Failed to retrieve user subscription status.')
    }
  }

  const stripeCheckoutSessionDetailsResolver: Resolver<
    any,
    { sessionId: string }
  > = async (source, { sessionId }, context) => {
    try {
      const stripe = getStripeInstance()
      const session = await stripe.checkout.sessions.retrieve(sessionId, {
        expand: ['line_items.data.price.product'],
      })

      let productId: string | null = null
      let productName: string | null = null

      if (session.line_items && session.line_items.data.length > 0) {
        const product = session.line_items.data[0].price?.product
        if (product && typeof product !== 'string') {
          productId = product.id
          productName = ('name' in product && product.name) || 'Unknown Product'
        }
      }
      console.log('session.discounts', JSON.stringify(session?.discounts || {}))
      return {
        id: session.id,
        amountTotal: session.amount_total,
        currency: session.currency,
        coupon: session.discounts?.[0]?.coupon,
        productId,
        productName,
      }
    } catch (error: any) {
      console.error(
        'stripeCheckoutSessionDetailsResolver error:',
        JSON.stringify(error),
      )
      throw new Error('Failed to retrieve checkout session details.')
    }
  }

  const currentUserPurchasedProductIdsResolver: Resolver<
    any,
    any
  > = async () => {
    try {
      const team = await stripeDatabaseAdapters.getTeamFn()
      return team?.purchasedProducts || []
    } catch (error: any) {
      console.error(
        'currentUserPurchasedProductIdsResolver error:',
        JSON.stringify(error),
      )
      throw new Error('Failed to retrieve purchased product IDs.')
    }
  }

  return {
    query: {
      stripeCheckoutSessionDetails: {
        type: StripeCheckoutSessionDetailsType,
        args: { sessionId: { type: new GraphQLNonNull(GraphQLString) } },
        resolve: stripeCheckoutSessionDetailsResolver,
      },
      stripePrices: {
        type: new GraphQLNonNull(
          new GraphQLList(new GraphQLNonNull(StripePriceType)),
        ),
        resolve: getStripePrices,
      },
      stripeProducts: {
        type: new GraphQLNonNull(
          new GraphQLList(new GraphQLNonNull(StripeProductType)),
        ),
        resolve: getStripeProducts,
      },
      stripeCoupons: {
        type: new GraphQLNonNull(
          new GraphQLList(new GraphQLNonNull(StripeCouponType)),
        ),
        resolve: stripeCouponsResolver,
      },
      currentUserStripeSubscriptionId: {
        type: GraphQLString,
        resolve: currentUserStripeSubscriptionIdResolver,
      },
      currentUserSubscriptionStatus: {
        type: GraphQLString,
        resolve: currentUserSubscriptionStatusResolver,
      },
      currentUserPurchasedProductIds: {
        type: new GraphQLList(PurchasedProductType),
        resolve: currentUserPurchasedProductIdsResolver,
      },
    },
    mutation: {
      createCheckoutSession: {
        type: CreateCheckoutSessionPayload,
        args: {
          priceId: { type: new GraphQLNonNull(GraphQLString) },
          couponId: { type: GraphQLString },
        },
        resolve: createCheckoutSessionResolver,
      },
    },
  }
}
