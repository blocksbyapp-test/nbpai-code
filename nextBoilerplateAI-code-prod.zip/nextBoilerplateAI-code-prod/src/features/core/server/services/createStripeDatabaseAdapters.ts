import { teamSchema } from '@/features/core/server/models/Team'
import { coreUserSchema } from '@/features/core/server/models/User'
import { auth } from '@/features/core/server/services/auth'
import { createIfNotExists } from '@/features/core/server/services/mongoose'
import type {
  PurchasedProduct,
  StripeDatabaseAdapters,
  TeamDocument,
} from '@/features/core/server/types'
import mongoose, { InferSchemaType } from 'mongoose'

export const createStripeDatabaseAdapters = (
  MongooseUser: mongoose.Model<InferSchemaType<typeof coreUserSchema>>,
  Team: mongoose.Model<InferSchemaType<typeof teamSchema>>,
  onUserCreation?: (email: string, name: string) => Promise<void>,
) => {
  const getUserFn: StripeDatabaseAdapters['getUserFn'] = async () => {
    const session = await auth()
    if (
      session &&
      'user' in session &&
      !session?.user?.email &&
      !session?.user?.provider
    ) {
      throw new Error('email or provider is missing')
    }

    const { email, name } =
      (session && 'user' in session && session?.user) || {}
    if (!email) {
      throw new Error('email is missing')
    }
    const { doc: user } = await createIfNotExists(
      MongooseUser,
      { email },
      {
        email,
        name,
        authProvider: session!.user!.provider,
        registrationDate: new Date(),
      },
      async (newUser) => {
        await onUserCreation?.(newUser.email, `${newUser.name}`)
      },
    )

    return user!
  }

  const getUserByIdFn: StripeDatabaseAdapters['getUserByIdFn'] = async (
    userId: string,
  ) => {
    return MongooseUser.findById(userId)
  }

  const getTeamFn: StripeDatabaseAdapters['getTeamFn'] = async () => {
    const user = await getUserFn()
    if (!user?.teamId) {
      console.log('getTeamFn: User has no teamId. Creating new team.')
      const newTeamId = new mongoose.Types.ObjectId()
      const name = `${user.email}'s Team`
      const { doc: newTeam, created } = await createIfNotExists(
        Team,
        { name },
        {
          name,
        },
      )

      user.teamId = newTeam._id
      await user.save()

      if (created) {
        console.log(
          'getTeamFn: New team created and linked to user:',
          newTeam._id,
        )
      } else {
        console.log(
          'getTeamFn: Existing team reused (unexpected path):',
          newTeam._id,
        )
      }

      return newTeam
    }

    const team = await Team.findById(user.teamId)

    return team as TeamDocument
  }

  const getTeamByStripeCustomerIdFn: StripeDatabaseAdapters['getTeamByStripeCustomerIdFn'] =
    async (customerId: string) =>
      await Team.findOne({ stripeCustomerId: customerId })

  const getTeamByIdFn: StripeDatabaseAdapters['getTeamByIdFn'] = async (
    teamId: any,
  ) => {
    return Team.findById(teamId)
  }

  const updateTeamSubscriptionFn: StripeDatabaseAdapters['updateTeamSubscriptionFn'] =
    async (teamId: any, subscriptionData) => {
      const team = await Team.findById(teamId)
      if (!team) {
        console.error(
          'updateTeamSubscriptionFn: Team not found for ID:',
          teamId,
        )
        return
      }

      if (subscriptionData.stripeCustomerId !== undefined)
        team.stripeCustomerId = subscriptionData.stripeCustomerId
      if (subscriptionData.stripeSubscriptionId !== undefined)
        team.stripeSubscriptionId = subscriptionData.stripeSubscriptionId
      if (subscriptionData.planName !== undefined)
        team.planName = subscriptionData.planName
      if (subscriptionData.subscriptionStatus !== undefined)
        team.subscriptionStatus = subscriptionData.subscriptionStatus

      if (subscriptionData.addPurchasedProduct) {
        const newProduct = subscriptionData.addPurchasedProduct
        const existingProductIndex = team.purchasedProducts.findIndex(
          (p) => p.stripeSessionId === newProduct.stripeSessionId,
        )

        if (existingProductIndex > -1) {
          // Update existing product
          const existingProduct = team.purchasedProducts[existingProductIndex]
          existingProduct.productId = newProduct.productId
          existingProduct.couponId = newProduct.couponId
          if (newProduct.purchaseDate) {
            existingProduct.purchaseDate = newProduct.purchaseDate
          }

          console.log(
            'updateTeamSubscriptionFn: Updated existing purchased product:',
            newProduct,
          )
        } else {
          team.purchasedProducts.push(newProduct as PurchasedProduct)
          console.log(
            'updateTeamSubscriptionFn: Added new purchased product:',
            newProduct,
          )
        }
      }

      if (subscriptionData.removePurchasedProductId) {
        team.purchasedProducts.pull({
          productId: subscriptionData.removePurchasedProductId,
        } as any)
        console.log(
          'updateTeamSubscriptionFn: Removed purchased product with ID:',
          subscriptionData.removePurchasedProductId,
        )
      }

      await team.save()
      console.log('updateTeamSubscriptionFn: Team updated successfully.')
      console.log('  Stripe Customer ID:', team.stripeCustomerId)
      console.log('  Subscription Status:', team.subscriptionStatus)
      console.log('  Purchased Products:', team.purchasedProducts)
    }

  return {
    getUserFn,
    getUserByIdFn,
    getTeamFn,
    getTeamByStripeCustomerIdFn,
    updateTeamSubscriptionFn,
    getTeamByIdFn,
  }
}
