import { SupportedFeature } from '@/features'
import config from '@/features/core/config'
import NextAuth, { NextAuthResult } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import GoogleProvider from 'next-auth/providers/google'

let AuthInstance: NextAuthResult

export function createAuthForFeature(feature: SupportedFeature) {
  const realAuth = NextAuth({
    providers: [
      GoogleProvider({
        clientId: config.googleId,
        clientSecret: config.googleSecret,
        redirectProxyUrl: config.appUrl + 'api/auth',
      }),
      CredentialsProvider({
        name: 'Credentials',
        credentials: {
          email: { label: 'Email', type: 'text' },
          password: { label: 'Password', type: 'password' },
        },
        async authorize(credentials) {
          if (!credentials?.email || !credentials?.password) return null
          const verificationResponse = await fetch(
            `${config.appUrl}${feature}/auth/verify-credentials`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                email: credentials.email,
                password: credentials.password,
              }),
            },
          )
          if (!verificationResponse.ok) {
            const errorData = await verificationResponse.json()
            console.error('Credential verification failed:', errorData.message)
            return null
          }
          const data = await verificationResponse.json()
          if (data.success && data.user) {
            return {
              id: data.user.id,
              email: data.user.email,
              name: data.user.name,
              provider: 'credentials',
            }
          }
          return null
        },
      }),
    ],
    secret: config.authSecret,
    trustHost: true,
    callbacks: {
      async jwt({ token, user }) {
        if (user) {
          token.id = (user as any).id
          token.provider = (user as any).provider
          if (
            !token.provider &&
            user.email &&
            user.email.includes('@') &&
            user.email.split('@')[1] === 'gmail.com'
          ) {
            token.provider = 'google'
          }
        }
        return token
      },
      async session({ session, token }) {
        if (token.id) session.user.id = token.id as string
        if (token.provider) session.user.provider = token.provider as string
        if ((token as any).requestedDeletionAt) {
          session.user.requestedDeletionAt = (token as any).requestedDeletionAt
        }
        return session
      },

      redirect() {
        return `${config.appUrl}${feature}`
      },
    },
    pages: { signIn: `/${feature}/auth/signin` },
  })

  AuthInstance = realAuth

  return realAuth
}

export const getAuthInstance = () => {
  if (AuthInstance) return AuthInstance
  else createAuthForFeature('panel')
  return AuthInstance
}

export const auth = async () => getAuthInstance().auth()
export const getHandlers = async () => getAuthInstance().handlers
