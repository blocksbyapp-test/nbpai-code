import { teamSchema } from '@/features/core/server/models/Team'
import { coreUserSchema } from '@/features/core/server/models/User'
import { HydratedDocument, InferSchemaType } from 'mongoose'

type UserSchema = InferSchemaType<typeof coreUserSchema>
type TeamSchema = InferSchemaType<typeof teamSchema>

export type UserDocument = HydratedDocument<UserSchema>
export type TeamDocument = HydratedDocument<TeamSchema>

export interface PurchasedProduct {
  productId: string
  couponId?: string | null
  purchaseDate?: Date
  stripeSessionId?: string | null
}

export type GetUserFn = () => Promise<UserDocument>
export type getUserByIdFn = (userId: string) => Promise<UserDocument | null>
export type GetTeamFn = () => Promise<TeamDocument>
export type GetTeamByStripeCustomerIdFn = (
  customerId: string,
) => Promise<TeamDocument | null>
export type GetTeamByIdFn = (teamId: any) => Promise<TeamDocument | null>

export type UpdateTeamSubscriptionFn = (
  teamId: any,
  subscriptionData: {
    stripeCustomerId?: string | null
    stripeSubscriptionId?: string | null
    planName?: string | null
    subscriptionStatus?: string
    addPurchasedProduct?: PurchasedProduct
    removePurchasedProductId?: string
  },
) => Promise<void>

export interface StripeDatabaseAdapters {
  getUserFn: GetUserFn
  getUserByIdFn: getUserByIdFn
  getTeamFn: GetTeamFn
  getTeamByStripeCustomerIdFn: GetTeamByStripeCustomerIdFn
  updateTeamSubscriptionFn: UpdateTeamSubscriptionFn
  getTeamByIdFn: GetTeamByIdFn
}
