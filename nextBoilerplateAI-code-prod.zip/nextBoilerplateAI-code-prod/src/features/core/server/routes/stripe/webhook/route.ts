import config from '@/features/core/config'
import {
  getStripeInstance,
  handleSubscriptionChange,
} from '@/features/core/server/stripe'
import { StripeDatabaseAdapters } from '@/features/core/server/types'
import { NextResponse, type NextRequest } from 'next/server'
import Stripe from 'stripe'

async function getProductIdFromCharge(
  charge: Stripe.Charge,
): Promise<string | null> {
  const stripe = getStripeInstance()

  if (!charge.payment_intent) {
    console.warn(
      `Charge ${charge.id} has no payment_intent. Cannot determine product ID.`,
    )
    return null
  }

  const paymentIntentId =
    typeof charge.payment_intent === 'string'
      ? charge.payment_intent
      : charge.payment_intent.id

  const checkoutSessions = await stripe.checkout.sessions.list({
    payment_intent: paymentIntentId,
    limit: 1,
  })

  if (checkoutSessions.data.length > 0) {
    const session = checkoutSessions.data[0]
    const lineItems = await stripe.checkout.sessions.listLineItems(session.id, {
      expand: ['data.price.product'],
    })

    if (lineItems.data.length > 0) {
      const product = lineItems.data[0].price?.product
      if (product && typeof product !== 'string') {
        return product.id
      }
    }
  }

  console.warn(`Could not determine product ID for charge ${charge.id}`)
  return null
}

export const createStripeWebhookRoute = (
  stripeDatabaseAdapters: StripeDatabaseAdapters,
) => ({
  POST: async (request: NextRequest) => {
    const payload = await request.text()
    const signature = request.headers.get('stripe-signature') as string

    let event: Stripe.Event

    try {
      const stripe = getStripeInstance()
      event = stripe.webhooks.constructEvent(
        payload,
        signature,
        config.stripeWebhookSecret,
      )
      console.log(
        `Webhook: Successfully constructed event of type: ${event.type}`,
      )
    } catch (err) {
      console.error('Webhook: Signature verification failed.', err)
      return NextResponse.json(
        { error: 'Webhook signature verification failed.' },
        { status: 400 },
      )
    }

    console.log(`Webhook: Received event type: ${event.type}`)

    switch (event.type) {
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
        const subscription = event.data.object as Stripe.Subscription
        console.log(
          `Webhook: Handling subscription event for subscription ID: ${subscription.id}, status: ${subscription.status}`,
        )
        await handleSubscriptionChange(subscription, stripeDatabaseAdapters)
        console.log('Webhook: Subscription event handled.')
        break
      case 'checkout.session.completed':
        const session = event.data.object as Stripe.Checkout.Session
        console.log('Webhook: Checkout session completed event received.')
        console.log('Webhook: Session mode:', session.mode)

        const lineItems =
          await getStripeInstance().checkout.sessions.listLineItems(
            session.id,
            { expand: ['data.price.product'] },
          )

        const lineItem = lineItems.data[0]
        const product = lineItem?.price?.product as Stripe.Product

        let usedCouponId: string | null = null
        console.log(
          'Webhook: Session in checkout.session.completed:',
          JSON.stringify(session),
        )
        if (
          session.total_details?.amount_discount &&
          session.discounts &&
          session.discounts.length > 0
        ) {
          const discount = session.discounts[0]
          if (
            discount.coupon &&
            typeof discount.coupon === 'object' &&
            'id' in discount.coupon
          ) {
            usedCouponId = discount.coupon.id
            console.log('Webhook: Coupon used for purchase:', usedCouponId)
          }
          if (discount.coupon && typeof discount.coupon === 'string') {
            usedCouponId = discount.coupon
          }
        }

        if (product && session.client_reference_id) {
          const userId = session.client_reference_id
          const user = await stripeDatabaseAdapters.getUserByIdFn(userId)

          if (user) {
            const teamForWebhook = await stripeDatabaseAdapters.getTeamByIdFn(
              user.teamId,
            )

            if (teamForWebhook) {
              console.log(
                'Webhook: Updating team for purchase. Team ID:',
                teamForWebhook._id,
              )
              await stripeDatabaseAdapters.updateTeamSubscriptionFn(
                teamForWebhook._id,
                {
                  stripeCustomerId: session.customer as string,
                  planName: product.name,
                  subscriptionStatus:
                    session.mode === 'payment' ? 'completed' : 'active',
                  addPurchasedProduct: {
                    productId: product.id,
                    couponId: usedCouponId,
                    purchaseDate: new Date(),
                    stripeSessionId: session.id,
                  },
                },
              )
              console.log('Webhook: Team updated for purchase.')
            } else {
              console.error('Webhook: Team not found for user ID:', userId)
            }
          } else {
            console.error(
              'Webhook: User not found for client_reference_id:',
              userId,
            )
          }
        } else {
          console.warn(
            'Webhook: Product or client_reference_id missing for completed session. Session ID:',
            session.id,
          )
        }
        break
      case 'invoice.payment_succeeded':
        console.log(
          'Webhook: Invoice payment succeeded event received. No specific action taken as product provisioning is handled by checkout.session.completed or subscription events.',
        )
        break
      case 'charge.refunded':
        const refundedCharge = event.data.object as Stripe.Charge
        console.log(
          `Webhook: Handling charge.refunded for charge ID: ${refundedCharge.id}`,
        )

        const refundedProductId = await getProductIdFromCharge(refundedCharge)
        if (refundedProductId) {
          const sessionsForCharge =
            await getStripeInstance().checkout.sessions.list({
              payment_intent:
                typeof refundedCharge.payment_intent === 'string'
                  ? refundedCharge.payment_intent
                  : refundedCharge.payment_intent?.id,
              limit: 1,
            })
          const userId = sessionsForCharge.data[0]?.client_reference_id

          if (userId) {
            const user = await stripeDatabaseAdapters.getUserByIdFn(userId)
            if (user) {
              const teamForRefund = await stripeDatabaseAdapters.getTeamByIdFn(
                user.teamId,
              )
              if (teamForRefund) {
                console.log(
                  `Webhook: Revoking product ${refundedProductId} for team ${teamForRefund._id} due to refund.`,
                )
                await stripeDatabaseAdapters.updateTeamSubscriptionFn(
                  teamForRefund._id,
                  {
                    removePurchasedProductId: refundedProductId,
                  },
                )
              } else {
                console.warn(
                  `Webhook: Team not found for user ${userId} during refund handling.`,
                )
              }
            } else {
              console.warn(
                `Webhook: User not found for ID ${userId} during refund handling.`,
              )
            }
          } else {
            console.warn(
              `Webhook: User ID not found for charge ${refundedCharge.id} during refund handling.`,
            )
          }
        } else {
          console.warn(
            `Webhook: Product ID could not be determined for refunded charge ${refundedCharge.id}.`,
          )
        }
        break
      case 'charge.dispute.created':
        const createdDispute = event.data.object as Stripe.Dispute
        console.log(
          `Webhook: Handling charge.dispute.created for dispute ID: ${createdDispute.id}`,
        )

        const disputedCharge = createdDispute.charge as Stripe.Charge
        const disputedProductId = await getProductIdFromCharge(disputedCharge)

        if (disputedProductId) {
          const sessionsForDispute =
            await getStripeInstance().checkout.sessions.list({
              payment_intent:
                typeof disputedCharge.payment_intent === 'string'
                  ? disputedCharge.payment_intent
                  : disputedCharge.payment_intent?.id,
              limit: 1,
            })
          const userId = sessionsForDispute.data[0]?.client_reference_id

          if (userId) {
            const user = await stripeDatabaseAdapters.getUserByIdFn(userId)
            if (user) {
              const teamForDispute = await stripeDatabaseAdapters.getTeamByIdFn(
                user.teamId,
              )
              if (teamForDispute) {
                console.log(
                  `Webhook: Revoking product ${disputedProductId} for team ${teamForDispute._id} due to dispute creation. `,
                )
                await stripeDatabaseAdapters.updateTeamSubscriptionFn(
                  teamForDispute._id,
                  {
                    removePurchasedProductId: disputedProductId,
                  },
                )
              } else {
                console.warn(
                  `Webhook: Team not found for user ${userId} during dispute creation handling.`,
                )
              }
            }
          }
        } else {
          console.warn(
            `Webhook: User ID not found for charge ${disputedCharge.id} during dispute creation handling.`,
          )
        }
        break
      case 'charge.dispute.closed':
        const closedDispute = event.data.object as Stripe.Dispute
        console.log(
          `Webhook: Handling charge.dispute.closed for dispute ID: ${closedDispute.id}, status: ${closedDispute.status}`,
        )

        if (closedDispute.status === 'won') {
          const wonCharge = closedDispute.charge as Stripe.Charge
          const wonProductId = await getProductIdFromCharge(wonCharge)

          if (wonProductId) {
            const sessionsForWonDispute =
              await getStripeInstance().checkout.sessions.list({
                payment_intent:
                  typeof wonCharge.payment_intent === 'string'
                    ? wonCharge.payment_intent
                    : wonCharge.payment_intent?.id,
                limit: 1,
              })
            const userId = sessionsForWonDispute.data[0]?.client_reference_id

            if (userId) {
              const user = await stripeDatabaseAdapters.getUserByIdFn(userId)
              if (user) {
                const teamForWonDispute =
                  await stripeDatabaseAdapters.getTeamByIdFn(user.teamId)
                if (teamForWonDispute) {
                  console.log(
                    `Webhook: Re-enabling product ${wonProductId} for team ${teamForWonDispute._id} as dispute was won.`,
                  )
                  await stripeDatabaseAdapters.updateTeamSubscriptionFn(
                    teamForWonDispute._id,
                    {
                      addPurchasedProduct: {
                        productId: wonProductId,
                        purchaseDate: new Date(),
                        stripeSessionId: sessionsForWonDispute.data[0]?.id,
                      },
                    },
                  )
                } else {
                  console.warn(
                    `Webhook: Team not found for user ${userId} during won dispute handling.`,
                  )
                }
              }
            }
          }
        } else {
          console.warn(
            `Webhook: Product ID could not be determined for dispute ${closedDispute.id}.`,
          )
        }
        break
      default:
        console.log(`Webhook: Unhandled event type ${event.type}`)
    }

    return NextResponse.json({ received: true }, { status: 200 })
  },
})
