import { SupportedFeature } from '@/features'
import config from '@/features/core/config'
import { getStripeInstance } from '@/features/core/server/stripe'
import { StripeDatabaseAdapters } from '@/features/core/server/types'
import { NextResponse, type NextRequest } from 'next/server'
import Stripe from 'stripe'

export const createStripeCheckoutRoute = (
  stripeDatabaseAdapters: StripeDatabaseAdapters,
  feature: SupportedFeature,
) => ({
  GET: async (request: NextRequest) => {
    const searchParams = request.nextUrl.searchParams
    const sessionId = searchParams.get('session_id')

    if (!sessionId) {
      console.log('Checkout Route: No session_id found in URL.')

      return NextResponse.redirect(`${config.appUrl}`)
    }

    try {
      const stripe = getStripeInstance()
      const session = await stripe.checkout.sessions.retrieve(sessionId, {
        expand: [
          'customer',
          'subscription',
          'payment_intent',
          'discounts.coupon',
        ],
      })

      console.log(
        'Checkout Route: Retrieved session:',
        JSON.stringify(session, null, 2),
      )

      let customerId: string
      if (
        session.customer &&
        typeof session.customer === 'object' &&
        'id' in session.customer
      ) {
        customerId = session.customer.id
      } else if (typeof session.customer === 'string') {
        customerId = session.customer
      } else {
        console.error(
          'Checkout Route: Invalid or missing customer data in Stripe session.',
        )
        throw new Error('Invalid or missing customer data in Stripe session.')
      }

      let productId: string | null = null
      let planName: string | null = null
      let subscriptionStatus: string = 'unknown'
      let stripeSubscriptionId: string | null = null

      if (session.mode === 'subscription') {
        const subscription = session.subscription as Stripe.Subscription
        if (!subscription) {
          console.error(
            'Checkout Route: No subscription found for this session in subscription mode.',
          )
          throw new Error(
            'No subscription found for this session in subscription mode.',
          )
        }
        const fullSubscription = await stripe.subscriptions.retrieve(
          subscription.id,
          {
            expand: ['items.data.price.product'],
          },
        )
        const plan = fullSubscription.items.data[0]?.price
        if (!plan) {
          console.error('Checkout Route: No plan found for this subscription.')
          throw new Error('No plan found for this subscription.')
        }
        const product = plan.product as Stripe.Product
        productId = product.id
        planName = product.name
        subscriptionStatus = fullSubscription.status
        stripeSubscriptionId = fullSubscription.id
        console.log(
          "Checkout Route: Session mode is 'subscription'. Product ID:",
          productId,
          'Status:',
          subscriptionStatus,
        )
      } else if (session.mode === 'payment') {
        const lineItems = await stripe.checkout.sessions.listLineItems(
          sessionId,
          {
            expand: ['data.price.product'],
          },
        )

        const lineItem = lineItems.data[0]
        const product = lineItem?.price?.product as Stripe.Product

        if (!product) {
          console.error(
            'Checkout Route: No product found in Checkout Session line items for one-time purchase.',
          )
          throw new Error(
            'No product found in Checkout Session line items for one-time purchase.',
          )
        }
        productId = product.id
        stripeSubscriptionId = null
        console.log(
          "Checkout Route: Session mode is 'payment'. Product ID:",
          productId,
          'Status:',
          subscriptionStatus,
        )
      } else {
        console.error(
          `Checkout Route: Unsupported checkout session mode: ${session.mode}`,
        )
        throw new Error(`Unsupported checkout session mode: ${session.mode}`)
      }

      if (!productId) {
        console.error(
          'Checkout Route: No product ID could be determined from the session.',
        )
        throw new Error('No product ID could be determined from the session.')
      }

      const userId = session.client_reference_id
      if (!userId) {
        console.error(
          "Checkout Route: No user ID found in session's client_reference_id.",
        )
        throw new Error("No user ID found in session's client_reference_id.")
      }

      const user = await stripeDatabaseAdapters.getUserFn()

      if (!user || user._id.toString() !== userId) {
        console.error(
          'Checkout Route: User mismatch or not found for checkout session:',
          userId,
          session.id,
        )
        throw new Error('User not found or mismatch.')
      }
      const team = await stripeDatabaseAdapters.getTeamFn()

      if (!team) {
        console.error('Checkout Route: User is not associated with any team.')
        throw new Error('User is not associated with any team.')
      }

      console.log(
        'Checkout Route: Session in checkout route:',
        JSON.stringify(session),
      )

      // Determine couponId from session if applicable
      let couponId: string | null = null
      if (
        session.total_details?.amount_discount &&
        session.discounts &&
        session.discounts.length > 0
      ) {
        const discount = session.discounts[0]
        if (
          discount.coupon &&
          typeof discount.coupon === 'object' &&
          'id' in discount.coupon
        ) {
          couponId = discount.coupon.id
        }
      }

      console.log('Checkout Route: Attempting to update team subscription.')
      console.log('Team ID:', team._id)
      console.log('Stripe Customer ID to save:', customerId)
      console.log('Stripe Subscription ID to save:', stripeSubscriptionId)
      console.log('Stripe Product ID to save:', productId)
      console.log('Plan Name to save:', planName)
      console.log('Subscription Status to save:', subscriptionStatus)
      console.log('Coupon ID to save:', couponId)

      await stripeDatabaseAdapters.updateTeamSubscriptionFn(team._id, {
        stripeCustomerId: customerId,
        stripeSubscriptionId: stripeSubscriptionId,
        planName: planName,
        subscriptionStatus: subscriptionStatus,
        addPurchasedProduct: {
          productId: productId,
          couponId: couponId,
          purchaseDate: new Date(),
          stripeSessionId: sessionId,
        },
      })

      const updatedTeam = await stripeDatabaseAdapters.getTeamFn()
      console.log('Checkout Route: Updated Team (after update):')
      console.log('  Stripe Customer ID:', updatedTeam?.stripeCustomerId)
      console.log('  Subscription Status:', updatedTeam?.subscriptionStatus)
      console.log('  Purchased Products:', updatedTeam?.purchasedProducts)

      return NextResponse.redirect(
        `${config.appUrl}${feature}/purchase-success?session_id=${sessionId}`,
      )
    } catch (error: any) {
      console.error(
        'Checkout Route: Error handling successful checkout:',
        error,
      )
      return NextResponse.redirect(`${config.appUrl}${feature}`)
    }
  },
})
