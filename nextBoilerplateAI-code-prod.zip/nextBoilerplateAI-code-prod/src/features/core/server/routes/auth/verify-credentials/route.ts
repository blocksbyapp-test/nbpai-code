import { coreUserSchema } from '@/features/core/server/models/User'
import { connectDB } from '@/features/core/server/services/mongoose'
import bcrypt from 'bcrypt'
import mongoose, { InferSchemaType } from 'mongoose'
import { NextResponse } from 'next/server'

export const createVerifyCredentialsRoute = (
  UserModel: mongoose.Model<InferSchemaType<typeof coreUserSchema>>,
) => ({
  POST: async (request: Request) => {
    try {
      await connectDB()
      const { email, password } = await request.json()
      if (!email || !password) {
        return NextResponse.json(
          { success: false, message: 'Email and password are required.' },
          { status: 400 },
        )
      }
      const user = await UserModel.findOne({ email }).select('+password')
      if (!user) {
        return NextResponse.json(
          { success: false, message: 'Invalid credentials.' },
          { status: 401 },
        )
      }
      const isValid =
        user.password && (await bcrypt.compare(password, user.password))
      if (!isValid) {
        return NextResponse.json(
          { success: false, message: 'Invalid credentials.' },
          { status: 401 },
        )
      }
      return NextResponse.json(
        {
          success: true,
          user: { id: user._id.toString(), email: user.email, name: user.name },
        },
        { status: 200 },
      )
    } catch (error) {
      console.error('Error verifying credentials:', error)
      return NextResponse.json(
        { success: false, message: 'Internal server error.' },
        { status: 500 },
      )
    }
  },
})
