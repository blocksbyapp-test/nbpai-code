import type { SupportedFeature } from '@/features'
import config from '@/features/core/config'
import type {
  StripeDatabaseAdapters,
  TeamDocument,
} from '@/features/core/server/types'
import { redirect } from 'next/navigation'
import Stripe from 'stripe'

let stripeInstance: Stripe | null = null

export function getStripeInstance(): Stripe {
  if (!stripeInstance) {
    stripeInstance = new Stripe(config.stripeSecretKey as string, {
      apiVersion: '2025-07-30.basil',
    })
  }
  return stripeInstance
}

export async function getStripePrices() {
  const stripe = getStripeInstance()
  const prices = await stripe.prices.list({
    expand: ['data.product'],
    active: true,
  })

  return prices.data.map((price) => ({
    id: price.id,
    productId:
      typeof price.product === 'string' ? price.product : price.product.id,
    unitAmount: price.unit_amount,
    currency: price.currency,
    interval: price.recurring?.interval,
    trialPeriodDays: price.recurring?.trial_period_days,
  }))
}

export async function getStripeProducts() {
  const stripe = getStripeInstance()
  const products = await stripe.products.list({
    active: true,
    expand: ['data.default_price'],
  })

  return products.data.map((product) => ({
    id: product.id,
    name: product.name,
    description: product.description,
    defaultPriceId:
      typeof product.default_price === 'string'
        ? product.default_price
        : product.default_price?.id,
  }))
}

export async function getStripeCoupons() {
  const stripe = getStripeInstance()
  const coupons = await stripe.coupons.list({ limit: 100 })
  return coupons.data.map((coupon) => ({
    id: coupon.id,
    name: coupon.name,
    percentOff: coupon.percent_off,
    amountOff: coupon.amount_off,
    currency: coupon.currency,
    duration: coupon.duration,
    durationInMonths: coupon.duration_in_months,
    maxRedemptions: coupon.max_redemptions,
    redeemBy: coupon.redeem_by ? new Date(coupon.redeem_by * 1000) : null,
    timesRedeemed: coupon.times_redeemed,
    valid: coupon.valid,
  }))
}

export async function createCheckoutSession(
  team: TeamDocument | null,
  priceId: string,
  userId: any,
  adapters: StripeDatabaseAdapters,
  feature: SupportedFeature,
  couponId?: string | null,
): Promise<string> {
  if (!team) {
    console.log(
      'createCheckoutSession: No team provided, redirecting to signin.',
    )
    redirect(
      `${config.appUrl}${feature}/auth/signin?redirect=checkout&priceId=${priceId}`,
    )
  }

  const stripe = getStripeInstance()

  let currentStripeCustomerId = team.stripeCustomerId
  if (!currentStripeCustomerId) {
    console.log(
      'createCheckoutSession: No existing Stripe customer ID found for team. Creating a new one.',
    )
    const customer = await stripe.customers.create({
      email: (await adapters.getUserFn()).email,
      name: (await adapters.getUserFn()).name || team.name,
      metadata: {
        teamId: team._id.toString(),
        userId: userId.toString(),
      },
    })
    currentStripeCustomerId = customer.id
    console.log(
      'createCheckoutSession: New Stripe customer created with ID:',
      currentStripeCustomerId,
    )

    await adapters.updateTeamSubscriptionFn(team._id, {
      stripeCustomerId: currentStripeCustomerId,
      stripeSubscriptionId: team.stripeSubscriptionId,
      planName: team.planName,
      subscriptionStatus: `${team.subscriptionStatus}`,
    })
    console.log(
      'createCheckoutSession: Team updated with new Stripe customer ID.',
    )
    team.stripeCustomerId = currentStripeCustomerId
  } else {
    console.log(
      'createCheckoutSession: Using existing Stripe customer ID:',
      currentStripeCustomerId,
    )
  }

  const price = await stripe.prices.retrieve(priceId)
  console.log(
    'createCheckoutSession: Retrieved price details for price ID:',
    price.id,
    'Type:',
    price.type,
  )

  const sessionConfig: Stripe.Checkout.SessionCreateParams = {
    invoice_creation: {
      enabled: true,
    },
    payment_method_types: ['card'],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    success_url: `${config.appUrl}${feature}/public/stripe/checkout?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${config.appUrl}${feature}`,
    customer: currentStripeCustomerId,
    client_reference_id: userId.toString(),
  }

  if (couponId) {
    sessionConfig.discounts = [{ coupon: couponId }]
    console.log('createCheckoutSession: Applying coupon:', couponId)
  } else {
    sessionConfig.allow_promotion_codes = true
  }

  if (price.type === 'recurring') {
    sessionConfig.mode = 'subscription'
    console.log(
      "createCheckoutSession: Setting session mode to 'subscription'.",
    )
    if (price.recurring?.trial_period_days) {
      sessionConfig.subscription_data = {
        trial_period_days: price.recurring.trial_period_days,
      }
      console.log(
        'createCheckoutSession: Trial period days set:',
        price.recurring.trial_period_days,
      )
    }
  } else {
    sessionConfig.mode = 'payment'
    console.log(
      "createCheckoutSession: Setting session mode to 'payment' (one-time purchase).",
    )
  }

  const session = await stripe.checkout.sessions.create(sessionConfig)
  console.log(
    'createCheckoutSession: Stripe checkout session created. URL:',
    session.url,
  )

  return session.url!
}

export async function handleSubscriptionChange(
  subscription: Stripe.Subscription,
  adapters: StripeDatabaseAdapters,
) {
  const stripe = getStripeInstance()
  const customerId = subscription.customer as string
  const subscriptionId = subscription.id
  const status = subscription.status

  console.log(
    `handleSubscriptionChange: Processing subscription ID: ${subscriptionId}, Customer ID: ${customerId}, Status: ${status}`,
  )

  const team = await adapters.getTeamByStripeCustomerIdFn(customerId)

  if (!team) {
    console.error(
      'handleSubscriptionChange: Team not found for Stripe customer:',
      customerId,
    )
    return
  }

  if (status === 'active' || status === 'trialing') {
    const plan = subscription.items.data[0]?.price
    const productId =
      typeof plan?.product === 'string' ? plan.product : plan?.product?.id

    if (!plan || !productId) {
      console.error(
        'handleSubscriptionChange: Plan or Product ID missing for active/trialing subscription.',
        { subscriptionId, plan },
      )
      return
    }

    const product = await stripe.products.retrieve(productId)
    if (!product) {
      console.error(
        'handleSubscriptionChange: Product details not found for product ID:',
        productId,
      )
      return
    }

    console.log(
      'handleSubscriptionChange: Updating team subscription to active/trialing.',
    )
    console.log('  Team ID:', team._id)
    console.log('  Stripe Subscription ID:', subscriptionId)
    console.log('  Plan Name:', product.name)
    console.log('  Subscription Status:', status)

    await adapters.updateTeamSubscriptionFn(team._id, {
      stripeSubscriptionId: subscriptionId,
      planName: product.name,
      subscriptionStatus: status,
    })

    const updatedTeam = await adapters.getTeamByStripeCustomerIdFn(customerId)
    console.log('handleSubscriptionChange: Updated Team (after webhook):')
    console.log('  Stripe Customer ID:', updatedTeam?.stripeCustomerId)
    console.log('  Subscription Status:', updatedTeam?.subscriptionStatus)
  } else if (
    status === 'canceled' ||
    status === 'unpaid' ||
    status === 'incomplete_expired'
  ) {
    console.log(
      `handleSubscriptionChange: Cancelling/Unpaying subscription. Team ID: ${team._id}, Status: ${status}`,
    )
    await adapters.updateTeamSubscriptionFn(team._id, {
      stripeSubscriptionId: null,
      planName: null,
      subscriptionStatus: status,
    })
    console.log(
      'handleSubscriptionChange: Team subscription status updated to cancelled/unpaid.',
    )
  } else {
    console.log(
      `handleSubscriptionChange: Unhandled subscription status: ${status} for subscription ID: ${subscriptionId}.`,
    )
  }
}
