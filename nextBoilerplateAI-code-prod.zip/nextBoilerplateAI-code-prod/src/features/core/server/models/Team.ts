import mongoose from 'mongoose'

export const teamSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    stripeCustomerId: { type: String, unique: true, sparse: true },
    stripeSubscriptionId: { type: String, sparse: true },
    planName: { type: String },
    subscriptionStatus: { type: String },
    purchasedProducts: [
      {
        stripeSessionId: { type: String, required: true },
        productId: { type: String, required: true },
        couponId: { type: String, sparse: true },
        purchaseDate: { type: Date, default: Date.now },
      },
    ],
  },
  {
    timestamps: true,
  },
)
