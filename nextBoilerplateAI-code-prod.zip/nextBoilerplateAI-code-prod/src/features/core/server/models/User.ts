import { genSalt, hash } from 'bcrypt'
import mongoose from 'mongoose'
export const coreUserFields = {
  authProvider: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  name: { type: String },
  password: { type: String, select: false },
  salt: { type: String, select: false },
  teamId: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
  registrationDate: { type: Date },
}

export const coreUserSchema = new mongoose.Schema(coreUserFields, {
  timestamps: true,
})

export const addPasswordHashingToUserSchema = (
  schema: typeof coreUserSchema,
) => {
  schema.pre('save', async function (next) {
    if (this.isModified('password')) {
      const salt = await genSalt(10)
      this.salt = salt
      this.password = (await hash(`${this.password}`, salt)) || this.password
    }
    next()
  })
}
